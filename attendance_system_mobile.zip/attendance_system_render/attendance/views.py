from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .early_warning import EarlyWarningSystem, run_daily_warning_check
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.core.paginator import Paginator
from django.db.models import Q, Count
from django.utils import timezone
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.core.exceptions import ValidationError
from datetime import datetime, date, timedelta
import json
import pandas as pd
from io import BytesIO

from .models import (
    User, School, Grade, Subject, Classroom, Teacher, Student,
    AttendanceSession, AttendanceRecord, AttendanceReport, Notification
)


def login_view(request):
    """صفحة تسجيل الدخول"""
    if request.user.is_authenticated:
        return redirect('dashboard')
    
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            next_url = request.GET.get('next', 'dashboard')
            return redirect(next_url)
        else:
            messages.error(request, 'اسم المستخدم أو كلمة المرور غير صحيحة')
    
    return render(request, 'attendance/login.html')


@login_required
def logout_view(request):
    """تسجيل الخروج"""
    logout(request)
    messages.success(request, 'تم تسجيل الخروج بنجاح')
    return redirect('login')


@login_required
def dashboard(request):
    """لوحة التحكم الرئيسية مخصصة حسب دور المستخدم"""
    user = request.user
    context = {
        'user': user,
        'today': date.today(),
    }
    
    # لوحة تحكم الإدارة والمديرين
    if user.role in ['admin', 'manager']:
        # إحصائيات عامة
        total_students = Student.objects.filter(is_active=True).count()
        total_teachers = Teacher.objects.count()
        total_classrooms = Classroom.objects.count()
        today_sessions = AttendanceSession.objects.filter(date=date.today()).count()
        
        # الجداول النشطة اليوم
        from .models import Schedule, ScheduleSlot
        today_schedules = ScheduleSlot.objects.filter(
            schedule__is_active=True
        ).count()
        
        # بيانات الرسوم البيانية
        thirty_days_ago = date.today() - timedelta(days=30)
        attendance_stats = AttendanceRecord.objects.filter(
            session__date__gte=thirty_days_ago
        ).values('status').annotate(count=Count('id'))
        
        attendance_data = {
            'present': 0,
            'absent': 0,
            'late': 0,
            'excused': 0
        }
        
        for stat in attendance_stats:
            attendance_data[stat['status']] = stat['count']
        
        # إحصائيات الحضور حسب الفصول
        classroom_stats = AttendanceRecord.objects.filter(
            session__date__gte=thirty_days_ago,
            status='present'
        ).values('student__classroom__name').annotate(
            count=Count('id')
        ).order_by('-count')[:10]
        
        # اتجاه الحضور الأسبوعي
        weekly_attendance = []
        for i in range(7):
            week_start = date.today() - timedelta(weeks=i+1)
            week_end = week_start + timedelta(days=6)
            
            week_present = AttendanceRecord.objects.filter(
                session__date__range=[week_start, week_end],
                status='present'
            ).count()
            
            weekly_attendance.append({
                'week': f'الأسبوع {i+1}',
                'count': week_present
            })
        
        weekly_attendance.reverse()
        
        context.update({
            'total_students': total_students,
            'total_teachers': total_teachers,
            'total_classrooms': total_classrooms,
            'today_sessions': today_sessions,
            'today_schedules': today_schedules,
            'attendance_data': attendance_data,
            'classroom_stats': list(classroom_stats),
            'weekly_attendance': weekly_attendance,
            'dashboard_type': 'admin'
        })
    
    # لوحة تحكم المعلمين
    elif user.role == 'teacher':
        try:
            teacher = Teacher.objects.get(user=user)
            
            # إحصائيات المعلم
            my_classrooms = teacher.classrooms.all()
            my_subjects = teacher.subjects.all()
            my_students = Student.objects.filter(classroom__in=my_classrooms)
            
            # جدول اليوم
            from .models import ScheduleSlot
            today_slots = ScheduleSlot.objects.filter(
                teacher=teacher,
                time_slot__day_of_week=date.today().weekday(),
                schedule__is_active=True
            ).order_by('time_slot__start_time')
            
            # الحصة التالية
            from datetime import datetime
            current_time = datetime.now().time()
            next_slot = today_slots.filter(time_slot__start_time__gt=current_time).first()
            
            # إحصائيات حضور طلاب المعلم (آخر 30 يوم)
            thirty_days_ago = date.today() - timedelta(days=30)
            my_attendance_stats = AttendanceRecord.objects.filter(
                student__in=my_students,
                session__date__gte=thirty_days_ago
            ).values('status').annotate(count=Count('id'))
            
            teacher_attendance_data = {
                'present': 0,
                'absent': 0,
                'late': 0,
                'excused': 0
            }
            
            for stat in my_attendance_stats:
                teacher_attendance_data[stat['status']] = stat['count']
            
            # الطلاب الذين يحتاجون متابعة (غياب أكثر من 20%)
            students_need_attention = []
            for student in my_students:
                total_sessions = AttendanceRecord.objects.filter(
                    student=student,
                    session__date__gte=thirty_days_ago
                ).count()
                
                if total_sessions > 0:
                    absent_count = AttendanceRecord.objects.filter(
                        student=student,
                        session__date__gte=thirty_days_ago,
                        status='absent'
                    ).count()
                    
                    absence_rate = (absent_count / total_sessions) * 100
                    if absence_rate > 20:
                        students_need_attention.append({
                            'student': student,
                            'absence_rate': round(absence_rate, 1)
                        })
            
            context.update({
                'teacher': teacher,
                'my_classrooms': my_classrooms,
                'my_subjects': my_subjects,
                'my_students_count': my_students.count(),
                'today_slots': today_slots,
                'next_slot': next_slot,
                'teacher_attendance_data': teacher_attendance_data,
                'students_need_attention': students_need_attention[:5],
                'dashboard_type': 'teacher'
            })
            
        except Teacher.DoesNotExist:
            context['error'] = 'لم يتم العثور على بيانات المعلم'
    
    # لوحة تحكم الطلاب
    elif user.role == 'student':
        try:
            student = Student.objects.get(user=user)
            
            # جدول الطالب اليوم
            from .models import ScheduleSlot
            today_slots = ScheduleSlot.objects.filter(
                classroom=student.classroom,
                time_slot__day_of_week=date.today().weekday(),
                schedule__is_active=True
            ).order_by('time_slot__start_time')
            
            # الحصة التالية
            from datetime import datetime
            current_time = datetime.now().time()
            next_slot = today_slots.filter(time_slot__start_time__gt=current_time).first()
            
            # إحصائيات الحضور الشخصية (آخر 30 يوم)
            thirty_days_ago = date.today() - timedelta(days=30)
            my_attendance = AttendanceRecord.objects.filter(
                student=student,
                session__date__gte=thirty_days_ago
            )
            
            total_sessions = my_attendance.count()
            present_count = my_attendance.filter(status='present').count()
            absent_count = my_attendance.filter(status='absent').count()
            late_count = my_attendance.filter(status='late').count()
            
            attendance_rate = (present_count / total_sessions * 100) if total_sessions > 0 else 0
            
            # آخر 5 سجلات حضور
            recent_attendance = my_attendance.order_by('-session__date')[:5]
            
            # هدف الحضور (90%)
            attendance_goal = 90
            goal_progress = min(attendance_rate, attendance_goal)
            
            context.update({
                'student': student,
                'today_slots': today_slots,
                'next_slot': next_slot,
                'total_sessions': total_sessions,
                'present_count': present_count,
                'absent_count': absent_count,
                'late_count': late_count,
                'attendance_rate': round(attendance_rate, 1),
                'recent_attendance': recent_attendance,
                'attendance_goal': attendance_goal,
                'goal_progress': round(goal_progress, 1),
                'dashboard_type': 'student'
            })
            
        except Student.DoesNotExist:
            context['error'] = 'لم يتم العثور على بيانات الطالب'
    
    # لوحة تحكم أولياء الأمور
    elif user.role == 'parent':
        # البحث عن الأبناء المرتبطين بولي الأمر
        children = Student.objects.filter(parent_email=user.email, is_active=True)
        
        children_data = []
        for child in children:
            # جدول الطفل اليوم
            from .models import ScheduleSlot
            child_today_slots = ScheduleSlot.objects.filter(
                classroom=child.classroom,
                time_slot__day_of_week=date.today().weekday(),
                schedule__is_active=True
            ).order_by('time_slot__start_time')
            
            # إحصائيات الحضور (آخر 30 يوم)
            thirty_days_ago = date.today() - timedelta(days=30)
            child_attendance = AttendanceRecord.objects.filter(
                student=child,
                session__date__gte=thirty_days_ago
            )
            
            total_sessions = child_attendance.count()
            present_count = child_attendance.filter(status='present').count()
            attendance_rate = (present_count / total_sessions * 100) if total_sessions > 0 else 0
            
            # تحديد حالة التنبيه
            alert_level = 'success'
            if attendance_rate < 70:
                alert_level = 'danger'
            elif attendance_rate < 80:
                alert_level = 'warning'
            
            children_data.append({
                'child': child,
                'today_slots': child_today_slots,
                'total_sessions': total_sessions,
                'present_count': present_count,
                'attendance_rate': round(attendance_rate, 1),
                'alert_level': alert_level
            })
        
        context.update({
            'children': children_data,
            'children_count': len(children_data),
            'dashboard_type': 'parent'
        })
    
    return render(request, 'attendance/dashboard.html', context)


@login_required
def student_list(request):
    """قائمة الطلاب"""
    if request.user.role not in ['admin', 'manager', 'teacher']:
        messages.error(request, 'ليس لديك صلاحية للوصول لهذه الصفحة')
        return redirect('dashboard')
    
    # معالجة إضافة طالب جديد
    if request.method == 'POST':
        try:
            # إنشاء مستخدم جديد
            user = User.objects.create_user(
                username=request.POST.get('student_id'),
                email=request.POST.get('email'),
                first_name=request.POST.get('first_name'),
                last_name=request.POST.get('last_name'),
                role='student'
            )
            user.set_password('123456')  # كلمة مرور افتراضية
            user.save()
            
            # إنشاء طالب
            student = Student.objects.create(
                user=user,
                student_id=request.POST.get('student_id'),
                classroom_id=request.POST.get('classroom'),
                enrollment_date=request.POST.get('enrollment_date'),
                phone=request.POST.get('phone', '')
            )
            
            messages.success(request, f'تم إضافة الطالب {user.first_name} {user.last_name} بنجاح')
            return redirect('student_list')
            
        except Exception as e:
            messages.error(request, f'حدث خطأ أثناء إضافة الطالب: {str(e)}')
    
    students = Student.objects.filter(is_active=True).select_related(
        'user', 'classroom', 'parent'
    ).order_by('classroom__name', 'user__first_name')
    
    # البحث
    search_query = request.GET.get('search', '')
    if search_query:
        students = students.filter(
            Q(user__first_name__icontains=search_query) |
            Q(user__last_name__icontains=search_query) |
            Q(student_id__icontains=search_query)
        )
    
    # التصفية حسب الفصل
    classroom_filter = request.GET.get('classroom', '')
    if classroom_filter:
        students = students.filter(classroom_id=classroom_filter)
    
    # التقسيم إلى صفحات
    paginator = Paginator(students, 20)
    page_number = request.GET.get('page')
    students_page = paginator.get_page(page_number)
    
    classrooms = Classroom.objects.all().order_by('grade__level', 'name')
    
    context = {
        'students': students_page,
        'classrooms': classrooms,
        'search_query': search_query,
        'classroom_filter': classroom_filter,
        'today': date.today(),
    }
    
    return render(request, 'attendance/student_list.html', context)



@login_required
def attendance_session_list(request):
    """قائمة جلسات الحضور"""
    user = request.user
    
    # معالجة إضافة جلسة جديدة
    if request.method == 'POST' and user.role in ['admin', 'manager', 'teacher']:
        try:
            classroom = get_object_or_404(Classroom, id=request.POST.get('classroom'))
            subject = get_object_or_404(Subject, id=request.POST.get('subject'))
            
            # تحديد المعلم
            if user.role == 'teacher':
                teacher = user.teacher_profile
            else:
                # للمدير، يمكن تعيين أي معلم، أو المعلم الأساسي للمادة
                teacher = subject.teachers.first() or Teacher.objects.first()
            
            session = AttendanceSession.objects.create(
                classroom=classroom,
                subject=subject,
                teacher=teacher,
                date=request.POST.get('date'),
                start_time=request.POST.get('start_time'),
                end_time=request.POST.get('end_time'),
                session_type=request.POST.get('session_type', 'regular'),
                notes=request.POST.get('notes', ''),
                created_by=user
            )
            
            messages.success(request, f'تم إنشاء جلسة الحضور بنجاح')
            return redirect('session_detail', session_id=session.id)
            
        except Exception as e:
            messages.error(request, f'حدث خطأ أثناء إنشاء الجلسة: {str(e)}')
    
    sessions = AttendanceSession.objects.select_related(
        'classroom', 'subject', 'teacher__user'
    ).order_by('-date', '-start_time')
    
    # تصفية حسب دور المستخدم
    if user.role == 'teacher':
        try:
            teacher = user.teacher_profile
            sessions = sessions.filter(teacher=teacher)
        except:
            sessions = sessions.none()
    elif user.role == 'student':
        try:
            student = user.student_profile
            sessions = sessions.filter(classroom=student.classroom)
        except:
            sessions = sessions.none()
    elif user.role not in ['admin', 'manager']:
        messages.error(request, 'ليس لديك صلاحية للوصول لهذه الصفحة')
        return redirect('dashboard')
    
    # التصفية حسب التاريخ
    date_filter = request.GET.get('date', '')
    if date_filter:
        sessions = sessions.filter(date=date_filter)
    
    # التصفية حسب الفصل
    classroom_filter = request.GET.get('classroom', '')
    if classroom_filter:
        sessions = sessions.filter(classroom_id=classroom_filter)
    
    # التقسيم إلى صفحات
    paginator = Paginator(sessions, 15)
    page_number = request.GET.get('page')
    sessions_page = paginator.get_page(page_number)
    
    classrooms = Classroom.objects.all().order_by('grade__level', 'name')
    subjects = Subject.objects.all().order_by('name')
    
    context = {
        'sessions': sessions_page,
        'classrooms': classrooms,
        'subjects': subjects,
        'date_filter': date_filter,
        'classroom_filter': classroom_filter,
        'today': date.today(),
    }
    
    return render(request, 'attendance/session_list.html', context)


@login_required
def attendance_session_detail(request, session_id):
    """تفاصيل جلسة الحضور"""
    session = get_object_or_404(AttendanceSession, id=session_id)
    user = request.user
    
    # التحقق من الصلاحيات
    if user.role == 'teacher' and session.teacher.user != user:
        messages.error(request, 'ليس لديك صلاحية للوصول لهذه الجلسة')
        return redirect('attendance_sessions')
    elif user.role == 'student':
        try:
            student = user.student_profile
            if session.classroom != student.classroom:
                messages.error(request, 'ليس لديك صلاحية للوصول لهذه الجلسة')
                return redirect('attendance_sessions')
        except:
            messages.error(request, 'ليس لديك صلاحية للوصول لهذه الجلسة')
            return redirect('dashboard')
    elif user.role not in ['admin', 'manager', 'teacher', 'student']:
        messages.error(request, 'ليس لديك صلاحية للوصول لهذه الصفحة')
        return redirect('dashboard')
    
    # جلب سجلات الحضور
    attendance_records = AttendanceRecord.objects.filter(
        session=session
    ).select_related('student__user').order_by('student__user__first_name')
    
    context = {
        'session': session,
        'attendance_records': attendance_records,
        'can_edit': user.role in ['admin', 'manager', 'teacher'] and 
                   (user.role != 'teacher' or session.teacher.user == user),
    }
    
    return render(request, 'attendance/session_detail.html', context)


@login_required
def take_attendance(request, session_id):
    """تسجيل الحضور"""
    session = get_object_or_404(AttendanceSession, id=session_id)
    user = request.user
    
    # التحقق من الصلاحيات
    if user.role not in ['admin', 'manager', 'teacher']:
        messages.error(request, 'ليس لديك صلاحية لتسجيل الحضور')
        return redirect('dashboard')
    
    if user.role == 'teacher' and session.teacher.user != user:
        messages.error(request, 'ليس لديك صلاحية لتسجيل الحضور لهذه الجلسة')
        return redirect('attendance_sessions')
    
    # جلب طلاب الفصل
    students = Student.objects.filter(
        classroom=session.classroom, is_active=True
    ).select_related('user').order_by('user__first_name')
    
    # جلب سجلات الحضور الموجودة
    existing_records = {
        record.student_id: record for record in 
        AttendanceRecord.objects.filter(session=session)
    }
    
    if request.method == 'POST':
        # معالجة تسجيل الحضور
        for student in students:
            status = request.POST.get(f'status_{student.id}', 'present')
            arrival_time = request.POST.get(f'arrival_time_{student.id}', '')
            notes = request.POST.get(f'notes_{student.id}', '')
            
            # تحويل وقت الوصول
            arrival_time_obj = None
            if arrival_time:
                try:
                    arrival_time_obj = datetime.strptime(arrival_time, '%H:%M').time()
                except:
                    pass
            
            # إنشاء أو تحديث سجل الحضور
            record, created = AttendanceRecord.objects.get_or_create(
                session=session,
                student=student,
                defaults={
                    'status': status,
                    'arrival_time': arrival_time_obj,
                    'notes': notes,
                    'recorded_by': user,
                }
            )
            
            if not created:
                record.status = status
                record.arrival_time = arrival_time_obj
                record.notes = notes
                record.recorded_by = user
                record.save()
        
        # تحديث حالة الجلسة
        session.is_completed = True
        session.save()
        
        messages.success(request, 'تم حفظ الحضور بنجاح')
        return redirect('session_detail', session_id=session.id)
    
    context = {
        'session': session,
        'students': students,
        'existing_records': existing_records,
    }
    
    return render(request, 'attendance/take_attendance.html', context)


@login_required
def attendance_reports(request):
    """تقارير الحضور"""
    if request.user.role not in ['admin', 'manager', 'teacher']:
        messages.error(request, 'ليس لديك صلاحية للوصول لهذه الصفحة')
        return redirect('dashboard')
    
    reports = AttendanceReport.objects.select_related(
        'generated_by', 'classroom', 'subject', 'student'
    ).order_by('-created_at')
    
    # التصفية حسب نوع التقرير
    report_type = request.GET.get('type', '')
    if report_type:
        reports = reports.filter(report_type=report_type)
    
    # التقسيم إلى صفحات
    paginator = Paginator(reports, 15)
    page_number = request.GET.get('page')
    reports_page = paginator.get_page(page_number)
    
    context = {
        'reports': reports_page,
        'report_type': report_type,
    }
    
    return render(request, 'attendance/reports.html', context)


@login_required
def profile_view(request):
    """صفحة الملف الشخصي"""
    user = request.user
    
    context = {
        'user': user,
    }
    
    # إضافة معلومات إضافية حسب دور المستخدم
    if user.role == 'teacher':
        try:
            context['teacher'] = user.teacher_profile
        except:
            pass
    elif user.role == 'student':
        try:
            context['student'] = user.student_profile
        except:
            pass
    
    return render(request, 'attendance/profile.html', context)


@login_required
def notifications_view(request):
    """صفحة الإشعارات"""
    notifications = Notification.objects.filter(
        recipient=request.user
    ).order_by('-created_at')
    
    # تحديد الإشعارات غير المقروءة كمقروءة
    unread_notifications = notifications.filter(is_read=False)
    unread_notifications.update(is_read=True)
    
    # التقسيم إلى صفحات
    paginator = Paginator(notifications, 20)
    page_number = request.GET.get('page')
    notifications_page = paginator.get_page(page_number)
    
    context = {
        'notifications': notifications_page,
    }
    
    return render(request, 'attendance/notifications.html', context)


@login_required
@require_http_methods(["POST"])
def import_students_excel(request):
    """استيراد الطلاب من ملف Excel"""
    if request.user.role not in ['admin', 'manager']:
        return JsonResponse({'success': False, 'message': 'ليس لديك صلاحية لهذا الإجراء'})
    
    if 'excel_file' not in request.FILES:
        return JsonResponse({'success': False, 'message': 'لم يتم رفع أي ملف'})
    
    excel_file = request.FILES['excel_file']
    
    try:
        # قراءة ملف Excel
        df = pd.read_excel(excel_file)
        
        # التحقق من وجود الأعمدة المطلوبة
        required_columns = ['الاسم الأول', 'الاسم الأخير', 'رقم الطالب', 'البريد الإلكتروني', 'الفصل']
        missing_columns = [col for col in required_columns if col not in df.columns]
        
        if missing_columns:
            return JsonResponse({
                'success': False, 
                'message': f'الأعمدة التالية مفقودة: {", ".join(missing_columns)}'
            })
        
        success_count = 0
        error_count = 0
        errors = []
        
        for index, row in df.iterrows():
            try:
                # البحث عن الفصل
                classroom = Classroom.objects.filter(name=row['الفصل']).first()
                if not classroom:
                    errors.append(f'الصف {index + 2}: الفصل "{row["الفصل"]}" غير موجود')
                    error_count += 1
                    continue
                
                # التحقق من عدم وجود الطالب مسبقاً
                if User.objects.filter(username=row['رقم الطالب']).exists():
                    errors.append(f'الصف {index + 2}: رقم الطالب "{row["رقم الطالب"]}" موجود مسبقاً')
                    error_count += 1
                    continue
                
                # إنشاء المستخدم
                user = User.objects.create_user(
                    username=row['رقم الطالب'],
                    email=row['البريد الإلكتروني'],
                    first_name=row['الاسم الأول'],
                    last_name=row['الاسم الأخير'],
                    role='student'
                )
                user.set_password('123456')  # كلمة مرور افتراضية
                user.save()
                
                # إنشاء الطالب
                Student.objects.create(
                    user=user,
                    student_id=row['رقم الطالب'],
                    classroom=classroom,
                    enrollment_date=date.today(),
                    phone=row.get('رقم الهاتف', '')
                )
                
                success_count += 1
                
            except Exception as e:
                errors.append(f'الصف {index + 2}: {str(e)}')
                error_count += 1
        
        message = f'تم استيراد {success_count} طالب بنجاح'
        if error_count > 0:
            message += f'، فشل في استيراد {error_count} طالب'
        
        return JsonResponse({
            'success': True,
            'message': message,
            'success_count': success_count,
            'error_count': error_count,
            'errors': errors[:10]  # أول 10 أخطاء فقط
        })
        
    except Exception as e:
        return JsonResponse({'success': False, 'message': f'خطأ في قراءة الملف: {str(e)}'})


@login_required
def export_students_excel(request):
    """تصدير الطلاب إلى ملف Excel"""
    if request.user.role not in ['admin', 'manager', 'teacher']:
        messages.error(request, 'ليس لديك صلاحية لهذا الإجراء')
        return redirect('student_list')
    
    # جلب بيانات الطلاب
    students = Student.objects.filter(is_active=True).select_related(
        'user', 'classroom', 'parent'
    ).order_by('classroom__name', 'user__first_name')
    
    # إنشاء DataFrame
    data = []
    for student in students:
        data.append({
            'رقم الطالب': student.student_id,
            'الاسم الأول': student.user.first_name,
            'الاسم الأخير': student.user.last_name,
            'البريد الإلكتروني': student.user.email,
            'الفصل': student.classroom.name,
            'الصف الدراسي': student.classroom.grade.name,
            'رقم الهاتف': student.phone,
            'تاريخ التسجيل': student.enrollment_date.strftime('%Y-%m-%d'),
            'ولي الأمر': f'{student.parent.first_name} {student.parent.last_name}' if student.parent else '',
            'الحالة': 'نشط' if student.is_active else 'غير نشط'
        })
    
    df = pd.DataFrame(data)
    
    # إنشاء ملف Excel
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='الطلاب', index=False)
    
    output.seek(0)
    
    # إرجاع الملف
    response = HttpResponse(
        output.getvalue(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = f'attachment; filename="students_{date.today()}.xlsx"'
    
    return response


@login_required
def get_subjects_by_classroom(request):
    """جلب المواد حسب الفصل (AJAX)"""
    classroom_id = request.GET.get('classroom_id')
    if not classroom_id:
        return JsonResponse({'subjects': []})
    
    try:
        classroom = Classroom.objects.get(id=classroom_id)
        subjects = Subject.objects.filter(grade=classroom.grade).values('id', 'name', 'code')
        return JsonResponse({'subjects': list(subjects)})
    except Classroom.DoesNotExist:
        return JsonResponse({'subjects': []})


@login_required
def attendance_statistics(request):
    """إحصائيات الحضور"""
    if request.user.role not in ['admin', 'manager', 'teacher']:
        messages.error(request, 'ليس لديك صلاحية للوصول لهذه الصفحة')
        return redirect('dashboard')
    
    # إحصائيات عامة
    total_students = Student.objects.filter(is_active=True).count()
    total_sessions = AttendanceSession.objects.count()
    completed_sessions = AttendanceSession.objects.filter(is_completed=True).count()
    
    # إحصائيات الحضور لهذا الأسبوع
    week_start = date.today() - timedelta(days=date.today().weekday())
    week_records = AttendanceRecord.objects.filter(
        session__date__gte=week_start
    ).values('status').annotate(count=Count('id'))
    
    week_stats = {record['status']: record['count'] for record in week_records}
    
    # إحصائيات الحضور لهذا الشهر
    month_start = date.today().replace(day=1)
    month_records = AttendanceRecord.objects.filter(
        session__date__gte=month_start
    ).values('status').annotate(count=Count('id'))
    
    month_stats = {record['status']: record['count'] for record in month_records}
    
    context = {
        'total_students': total_students,
        'total_sessions': total_sessions,
        'completed_sessions': completed_sessions,
        'week_stats': week_stats,
        'month_stats': month_stats,
    }
    
    return render(request, 'attendance/statistics.html', context)




@login_required
def search_students_ajax(request):
    """البحث في الطلاب عبر AJAX"""
    if request.user.role not in ['admin', 'manager', 'teacher']:
        return JsonResponse({'error': 'ليس لديك صلاحية لهذا الإجراء'}, status=403)
    
    query = request.GET.get('q', '').strip()
    classroom_id = request.GET.get('classroom', '')
    status = request.GET.get('status', '')
    
    # البدء بجميع الطلاب النشطين
    students = Student.objects.filter(is_active=True).select_related(
        'user', 'classroom', 'classroom__grade', 'parent'
    )
    
    # تطبيق البحث النصي
    if query:
        students = students.filter(
            Q(user__first_name__icontains=query) |
            Q(user__last_name__icontains=query) |
            Q(student_id__icontains=query) |
            Q(user__email__icontains=query) |
            Q(phone__icontains=query)
        )
    
    # تطبيق تصفية الفصل
    if classroom_id:
        students = students.filter(classroom_id=classroom_id)
    
    # تطبيق تصفية الحالة
    if status == 'active':
        students = students.filter(is_active=True)
    elif status == 'inactive':
        students = students.filter(is_active=False)
    
    # ترتيب النتائج
    students = students.order_by('classroom__name', 'user__first_name')
    
    # تحويل النتائج إلى JSON
    results = []
    for student in students[:50]:  # أول 50 نتيجة فقط
        results.append({
            'id': student.id,
            'name': f"{student.user.first_name} {student.user.last_name}",
            'student_id': student.student_id,
            'email': student.user.email,
            'classroom': student.classroom.name,
            'grade': student.classroom.grade.name,
            'phone': '',  # حقل غير موجود في النموذج
            'parent': f"{student.parent.first_name} {student.parent.last_name}" if student.parent else '',
            'parent_phone': '',  # حقل غير موجود في النموذج
            'enrollment_date': student.enrollment_date.strftime('%Y-%m-%d'),
            'is_active': student.is_active,
        })
    
    return JsonResponse({
        'results': results,
        'total_count': students.count(),
        'showing_count': len(results)
    })


@login_required
def filter_students_ajax(request):
    """تصفية الطلاب عبر AJAX"""
    if request.user.role not in ['admin', 'manager', 'teacher']:
        return JsonResponse({'error': 'ليس لديك صلاحية لهذا الإجراء'}, status=403)
    
    # جلب معايير التصفية
    classroom_id = request.GET.get('classroom', '')
    grade_id = request.GET.get('grade', '')
    status = request.GET.get('status', '')
    has_parent = request.GET.get('has_parent', '')
    
    # البدء بجميع الطلاب
    students = Student.objects.select_related(
        'user', 'classroom', 'classroom__grade', 'parent'
    )
    
    # تطبيق التصفيات
    if classroom_id:
        students = students.filter(classroom_id=classroom_id)
    
    if grade_id:
        students = students.filter(classroom__grade_id=grade_id)
    
    if status == 'active':
        students = students.filter(is_active=True)
    elif status == 'inactive':
        students = students.filter(is_active=False)
    
    if has_parent == 'yes':
        students = students.filter(parent__isnull=False)
    elif has_parent == 'no':
        students = students.filter(parent__isnull=True)
    
    # إحصائيات التصفية
    total_count = students.count()
    active_count = students.filter(is_active=True).count()
    inactive_count = students.filter(is_active=False).count()
    
    # تجميع حسب الفصول
    classroom_stats = students.values(
        'classroom__name', 'classroom__id'
    ).annotate(
        count=Count('id')
    ).order_by('classroom__name')
    
    return JsonResponse({
        'total_count': total_count,
        'active_count': active_count,
        'inactive_count': inactive_count,
        'classroom_stats': list(classroom_stats)
    })


@login_required
@require_http_methods(["POST"])
def delete_student(request, student_id):
    """حذف طالب"""
    if request.user.role not in ['admin', 'manager']:
        messages.error(request, 'ليس لديك صلاحية لهذا الإجراء')
        return redirect('student_list')
    
    try:
        student = Student.objects.get(id=student_id)
        student_name = f"{student.user.first_name} {student.user.last_name}"
        
        # حذف المستخدم (سيحذف الطالب تلقائياً بسبب CASCADE)
        student.user.delete()
        
        messages.success(request, f'تم حذف الطالب {student_name} بنجاح')
    except Student.DoesNotExist:
        messages.error(request, 'الطالب غير موجود')
    except Exception as e:
        messages.error(request, f'حدث خطأ أثناء الحذف: {str(e)}')
    
    return redirect('student_list')



@login_required
def advanced_reports(request):
    """صفحة التقارير المتقدمة"""
    if request.user.role not in ['admin', 'manager', 'teacher']:
        messages.error(request, 'ليس لديك صلاحية للوصول لهذه الصفحة')
        return redirect('dashboard')
    
    # جلب البيانات الأساسية للفلاتر
    classrooms = Classroom.objects.all().order_by('name')
    subjects = Subject.objects.all().order_by('name')
    grades = Grade.objects.all().order_by('name')
    
    # إحصائيات سريعة
    total_students = Student.objects.filter(is_active=True).count()
    total_sessions = AttendanceSession.objects.count()
    completed_sessions = AttendanceSession.objects.filter(is_completed=True).count()
    
    # معدل الحضور العام
    total_records = AttendanceRecord.objects.count()
    present_records = AttendanceRecord.objects.filter(status='present').count()
    overall_attendance_rate = (present_records / total_records * 100) if total_records > 0 else 0
    
    context = {
        'classrooms': classrooms,
        'subjects': subjects,
        'grades': grades,
        'total_students': total_students,
        'total_sessions': total_sessions,
        'completed_sessions': completed_sessions,
        'overall_attendance_rate': round(overall_attendance_rate, 2),
    }
    
    return render(request, 'attendance/advanced_reports.html', context)


@login_required
def generate_custom_report(request):
    """إنشاء تقرير مخصص"""
    if request.user.role not in ['admin', 'manager', 'teacher']:
        return JsonResponse({'error': 'ليس لديك صلاحية لهذا الإجراء'}, status=403)
    
    if request.method != 'POST':
        return JsonResponse({'error': 'طريقة غير مدعومة'}, status=405)
    
    try:
        # جلب معايير التقرير
        report_type = request.POST.get('report_type', 'attendance_summary')
        date_from = request.POST.get('date_from')
        date_to = request.POST.get('date_to')
        classroom_ids = request.POST.getlist('classrooms')
        subject_ids = request.POST.getlist('subjects')
        student_ids = request.POST.getlist('students')
        
        # تحويل التواريخ
        date_from_obj = datetime.strptime(date_from, '%Y-%m-%d').date() if date_from else None
        date_to_obj = datetime.strptime(date_to, '%Y-%m-%d').date() if date_to else None
        
        # إنشاء التقرير حسب النوع
        if report_type == 'attendance_summary':
            report_data = generate_attendance_summary_report(
                date_from_obj, date_to_obj, classroom_ids, subject_ids, student_ids
            )
        elif report_type == 'student_detailed':
            report_data = generate_student_detailed_report(
                date_from_obj, date_to_obj, classroom_ids, subject_ids, student_ids
            )
        elif report_type == 'classroom_comparison':
            report_data = generate_classroom_comparison_report(
                date_from_obj, date_to_obj, classroom_ids, subject_ids
            )
        elif report_type == 'attendance_trends':
            report_data = generate_attendance_trends_report(
                date_from_obj, date_to_obj, classroom_ids, subject_ids
            )
        else:
            return JsonResponse({'error': 'نوع تقرير غير مدعوم'}, status=400)
        
        return JsonResponse({
            'success': True,
            'report_data': report_data,
            'report_type': report_type
        })
        
    except Exception as e:
        return JsonResponse({'error': f'خطأ في إنشاء التقرير: {str(e)}'}, status=500)


def generate_attendance_summary_report(date_from, date_to, classroom_ids, subject_ids, student_ids):
    """إنشاء تقرير ملخص الحضور"""
    # بناء الاستعلام الأساسي
    sessions = AttendanceSession.objects.filter(is_completed=True)
    
    if date_from:
        sessions = sessions.filter(date__gte=date_from)
    if date_to:
        sessions = sessions.filter(date__lte=date_to)
    if classroom_ids:
        sessions = sessions.filter(classroom_id__in=classroom_ids)
    if subject_ids:
        sessions = sessions.filter(subject_id__in=subject_ids)
    
    # جلب سجلات الحضور
    records = AttendanceRecord.objects.filter(session__in=sessions)
    if student_ids:
        records = records.filter(student_id__in=student_ids)
    
    # حساب الإحصائيات
    total_records = records.count()
    present_count = records.filter(status='present').count()
    absent_count = records.filter(status='absent').count()
    late_count = records.filter(status='late').count()
    excused_count = records.filter(status='excused').count()
    
    attendance_rate = (present_count / total_records * 100) if total_records > 0 else 0
    
    # إحصائيات حسب الفصل
    classroom_stats = records.values(
        'student__classroom__name'
    ).annotate(
        total=Count('id'),
        present=Count('id', filter=Q(status='present')),
        absent=Count('id', filter=Q(status='absent')),
        late=Count('id', filter=Q(status='late')),
        excused=Count('id', filter=Q(status='excused'))
    ).order_by('student__classroom__name')
    
    # إحصائيات حسب المادة
    subject_stats = records.values(
        'session__subject__name'
    ).annotate(
        total=Count('id'),
        present=Count('id', filter=Q(status='present')),
        absent=Count('id', filter=Q(status='absent'))
    ).order_by('session__subject__name')
    
    # إحصائيات يومية
    daily_stats = records.values(
        'session__date'
    ).annotate(
        total=Count('id'),
        present=Count('id', filter=Q(status='present')),
        absent=Count('id', filter=Q(status='absent'))
    ).order_by('session__date')
    
    return {
        'summary': {
            'total_records': total_records,
            'present_count': present_count,
            'absent_count': absent_count,
            'late_count': late_count,
            'excused_count': excused_count,
            'attendance_rate': round(attendance_rate, 2)
        },
        'classroom_stats': list(classroom_stats),
        'subject_stats': list(subject_stats),
        'daily_stats': list(daily_stats),
        'period': {
            'from': date_from.strftime('%Y-%m-%d') if date_from else None,
            'to': date_to.strftime('%Y-%m-%d') if date_to else None
        }
    }


def generate_student_detailed_report(date_from, date_to, classroom_ids, subject_ids, student_ids):
    """إنشاء تقرير مفصل للطلاب"""
    students = Student.objects.filter(is_active=True)
    
    if classroom_ids:
        students = students.filter(classroom_id__in=classroom_ids)
    if student_ids:
        students = students.filter(id__in=student_ids)
    
    student_data = []
    
    for student in students:
        # جلب سجلات الطالب
        records = AttendanceRecord.objects.filter(student=student)
        
        if date_from:
            records = records.filter(session__date__gte=date_from)
        if date_to:
            records = records.filter(session__date__lte=date_to)
        if subject_ids:
            records = records.filter(session__subject_id__in=subject_ids)
        
        total_sessions = records.count()
        present_sessions = records.filter(status='present').count()
        absent_sessions = records.filter(status='absent').count()
        late_sessions = records.filter(status='late').count()
        excused_sessions = records.filter(status='excused').count()
        
        attendance_rate = (present_sessions / total_sessions * 100) if total_sessions > 0 else 0
        
        # آخر 10 سجلات
        recent_records = records.select_related(
            'session__subject', 'session__classroom'
        ).order_by('-session__date')[:10]
        
        student_data.append({
            'student': {
                'id': student.id,
                'name': f"{student.user.first_name} {student.user.last_name}",
                'student_id': student.student_id,
                'classroom': student.classroom.name,
                'email': student.user.email
            },
            'stats': {
                'total_sessions': total_sessions,
                'present_sessions': present_sessions,
                'absent_sessions': absent_sessions,
                'late_sessions': late_sessions,
                'excused_sessions': excused_sessions,
                'attendance_rate': round(attendance_rate, 2)
            },
            'recent_records': [
                {
                    'date': record.session.date.strftime('%Y-%m-%d'),
                    'subject': record.session.subject.name,
                    'status': record.status,
                    'arrival_time': record.arrival_time.strftime('%H:%M') if record.arrival_time else None,
                    'notes': record.notes
                }
                for record in recent_records
            ]
        })
    
    return {
        'students': student_data,
        'total_students': len(student_data)
    }


def generate_classroom_comparison_report(date_from, date_to, classroom_ids, subject_ids):
    """إنشاء تقرير مقارنة الفصول"""
    classrooms = Classroom.objects.all()
    
    if classroom_ids:
        classrooms = classrooms.filter(id__in=classroom_ids)
    
    comparison_data = []
    
    for classroom in classrooms:
        # جلب سجلات الفصل
        records = AttendanceRecord.objects.filter(student__classroom=classroom)
        
        if date_from:
            records = records.filter(session__date__gte=date_from)
        if date_to:
            records = records.filter(session__date__lte=date_to)
        if subject_ids:
            records = records.filter(session__subject_id__in=subject_ids)
        
        total_records = records.count()
        present_count = records.filter(status='present').count()
        absent_count = records.filter(status='absent').count()
        late_count = records.filter(status='late').count()
        
        attendance_rate = (present_count / total_records * 100) if total_records > 0 else 0
        
        # عدد الطلاب النشطين
        active_students = Student.objects.filter(
            classroom=classroom, is_active=True
        ).count()
        
        comparison_data.append({
            'classroom': {
                'id': classroom.id,
                'name': classroom.name,
                'grade': classroom.grade.name,
                'capacity': classroom.capacity,
                'active_students': active_students
            },
            'stats': {
                'total_records': total_records,
                'present_count': present_count,
                'absent_count': absent_count,
                'late_count': late_count,
                'attendance_rate': round(attendance_rate, 2)
            }
        })
    
    # ترتيب حسب معدل الحضور
    comparison_data.sort(key=lambda x: x['stats']['attendance_rate'], reverse=True)
    
    return {
        'classrooms': comparison_data,
        'total_classrooms': len(comparison_data)
    }


def generate_attendance_trends_report(date_from, date_to, classroom_ids, subject_ids):
    """إنشاء تقرير اتجاهات الحضور"""
    # تحديد الفترة الزمنية
    if not date_from:
        date_from = date.today() - timedelta(days=30)
    if not date_to:
        date_to = date.today()
    
    # إنشاء قائمة بجميع التواريخ في الفترة
    date_range = []
    current_date = date_from
    while current_date <= date_to:
        date_range.append(current_date)
        current_date += timedelta(days=1)
    
    # جلب البيانات اليومية
    daily_data = []
    for single_date in date_range:
        records = AttendanceRecord.objects.filter(session__date=single_date)
        
        if classroom_ids:
            records = records.filter(student__classroom_id__in=classroom_ids)
        if subject_ids:
            records = records.filter(session__subject_id__in=subject_ids)
        
        total = records.count()
        present = records.filter(status='present').count()
        absent = records.filter(status='absent').count()
        
        attendance_rate = (present / total * 100) if total > 0 else 0
        
        daily_data.append({
            'date': single_date.strftime('%Y-%m-%d'),
            'total': total,
            'present': present,
            'absent': absent,
            'attendance_rate': round(attendance_rate, 2)
        })
    
    # حساب الاتجاه العام
    rates = [day['attendance_rate'] for day in daily_data if day['total'] > 0]
    if len(rates) > 1:
        # حساب الاتجاه باستخدام الانحدار الخطي البسيط
        x = list(range(len(rates)))
        y = rates
        
        n = len(x)
        sum_x = sum(x)
        sum_y = sum(y)
        sum_xy = sum(x[i] * y[i] for i in range(n))
        sum_x2 = sum(x[i] ** 2 for i in range(n))
        
        slope = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x ** 2)
        trend = 'تصاعدي' if slope > 0.1 else 'تنازلي' if slope < -0.1 else 'مستقر'
    else:
        trend = 'غير محدد'
    
    # إحصائيات أسبوعية
    weekly_data = []
    current_week_start = date_from
    while current_week_start <= date_to:
        week_end = min(current_week_start + timedelta(days=6), date_to)
        
        week_records = AttendanceRecord.objects.filter(
            session__date__gte=current_week_start,
            session__date__lte=week_end
        )
        
        if classroom_ids:
            week_records = week_records.filter(student__classroom_id__in=classroom_ids)
        if subject_ids:
            week_records = week_records.filter(session__subject_id__in=subject_ids)
        
        total = week_records.count()
        present = week_records.filter(status='present').count()
        
        weekly_data.append({
            'week_start': current_week_start.strftime('%Y-%m-%d'),
            'week_end': week_end.strftime('%Y-%m-%d'),
            'total': total,
            'present': present,
            'attendance_rate': round((present / total * 100) if total > 0 else 0, 2)
        })
        
        current_week_start += timedelta(days=7)
    
    return {
        'daily_data': daily_data,
        'weekly_data': weekly_data,
        'trend': trend,
        'period': {
            'from': date_from.strftime('%Y-%m-%d'),
            'to': date_to.strftime('%Y-%m-%d'),
            'days': len(date_range)
        }
    }


@login_required
def export_report(request, format):
    """تصدير التقرير بصيغ مختلفة"""
    if request.user.role not in ['admin', 'manager', 'teacher']:
        messages.error(request, 'ليس لديك صلاحية لهذا الإجراء')
        return redirect('advanced_reports')
    
    # جلب بيانات التقرير من الجلسة
    report_data = request.session.get('last_report_data')
    if not report_data:
        messages.error(request, 'لا توجد بيانات تقرير للتصدير')
        return redirect('advanced_reports')
    
    if format == 'pdf':
        return export_report_pdf(report_data)
    elif format == 'excel':
        return export_report_excel(report_data)
    elif format == 'csv':
        return export_report_csv(report_data)
    else:
        messages.error(request, 'صيغة تصدير غير مدعومة')
        return redirect('advanced_reports')


def export_report_pdf(report_data):
    """تصدير التقرير كـ PDF"""
    from reportlab.lib.pagesizes import letter, A4
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.lib import colors
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="attendance_report_{date.today()}.pdf"'
    
    doc = SimpleDocTemplate(response, pagesize=A4)
    elements = []
    
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=18,
        spaceAfter=30,
        alignment=1  # Center alignment
    )
    
    # عنوان التقرير
    title = Paragraph("تقرير الحضور والغياب", title_style)
    elements.append(title)
    elements.append(Spacer(1, 12))
    
    # معلومات التقرير
    if 'period' in report_data:
        period_info = f"الفترة: من {report_data['period'].get('from', 'غير محدد')} إلى {report_data['period'].get('to', 'غير محدد')}"
        period_para = Paragraph(period_info, styles['Normal'])
        elements.append(period_para)
        elements.append(Spacer(1, 12))
    
    # إضافة البيانات حسب نوع التقرير
    if 'summary' in report_data:
        # تقرير الملخص
        summary_data = [
            ['المؤشر', 'القيمة'],
            ['إجمالي السجلات', str(report_data['summary']['total_records'])],
            ['الحضور', str(report_data['summary']['present_count'])],
            ['الغياب', str(report_data['summary']['absent_count'])],
            ['التأخير', str(report_data['summary']['late_count'])],
            ['معدل الحضور', f"{report_data['summary']['attendance_rate']}%"]
        ]
        
        summary_table = Table(summary_data)
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 14),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(summary_table)
    
    doc.build(elements)
    return response


def export_report_excel(report_data):
    """تصدير التقرير كـ Excel"""
    import openpyxl
    from openpyxl.styles import Font, Alignment, PatternFill
    
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "تقرير الحضور"
    
    # تنسيق العنوان
    title_font = Font(size=16, bold=True)
    header_font = Font(size=12, bold=True)
    header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
    
    # عنوان التقرير
    ws['A1'] = 'تقرير الحضور والغياب'
    ws['A1'].font = title_font
    ws['A1'].alignment = Alignment(horizontal='center')
    ws.merge_cells('A1:F1')
    
    row = 3
    
    # معلومات الفترة
    if 'period' in report_data:
        ws[f'A{row}'] = 'فترة التقرير:'
        ws[f'B{row}'] = f"من {report_data['period'].get('from', 'غير محدد')} إلى {report_data['period'].get('to', 'غير محدد')}"
        row += 2
    
    # بيانات الملخص
    if 'summary' in report_data:
        ws[f'A{row}'] = 'ملخص الإحصائيات'
        ws[f'A{row}'].font = header_font
        row += 1
        
        summary_headers = ['المؤشر', 'القيمة']
        for col, header in enumerate(summary_headers, 1):
            cell = ws.cell(row=row, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
        
        row += 1
        
        summary_data = [
            ['إجمالي السجلات', report_data['summary']['total_records']],
            ['الحضور', report_data['summary']['present_count']],
            ['الغياب', report_data['summary']['absent_count']],
            ['التأخير', report_data['summary']['late_count']],
            ['معدل الحضور', f"{report_data['summary']['attendance_rate']}%"]
        ]
        
        for data_row in summary_data:
            for col, value in enumerate(data_row, 1):
                ws.cell(row=row, column=col, value=value)
            row += 1
    
    # حفظ الملف
    output = BytesIO()
    wb.save(output)
    output.seek(0)
    
    response = HttpResponse(
        output.getvalue(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response['Content-Disposition'] = f'attachment; filename="attendance_report_{date.today()}.xlsx"'
    
    return response


def export_report_csv(report_data):
    """تصدير التقرير كـ CSV"""
    import csv
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="attendance_report_{date.today()}.csv"'
    
    writer = csv.writer(response)
    
    # عنوان التقرير
    writer.writerow(['تقرير الحضور والغياب'])
    writer.writerow([])
    
    # معلومات الفترة
    if 'period' in report_data:
        writer.writerow(['فترة التقرير:', f"من {report_data['period'].get('from', 'غير محدد')} إلى {report_data['period'].get('to', 'غير محدد')}"])
        writer.writerow([])
    
    # بيانات الملخص
    if 'summary' in report_data:
        writer.writerow(['ملخص الإحصائيات'])
        writer.writerow(['المؤشر', 'القيمة'])
        writer.writerow(['إجمالي السجلات', report_data['summary']['total_records']])
        writer.writerow(['الحضور', report_data['summary']['present_count']])
        writer.writerow(['الغياب', report_data['summary']['absent_count']])
        writer.writerow(['التأخير', report_data['summary']['late_count']])
        writer.writerow(['معدل الحضور', f"{report_data['summary']['attendance_rate']}%"])
    
    return response


@login_required
def attendance_analytics(request):
    """صفحة التحليلات المتقدمة"""
    if request.user.role not in ['admin', 'manager']:
        messages.error(request, 'ليس لديك صلاحية للوصول لهذه الصفحة')
        return redirect('dashboard')
    
    # إحصائيات متقدمة للتحليلات
    context = {
        'page_title': 'التحليلات المتقدمة',
    }
    
    return render(request, 'attendance/analytics.html', context)



# =================== وظائف إدارة المعلمين ===================

@login_required
def teacher_list(request):
    """صفحة قائمة المعلمين مع البحث والتصفية"""
    if request.user.role not in ['admin', 'manager']:
        messages.error(request, 'ليس لديك صلاحية للوصول لهذه الصفحة')
        return redirect('dashboard')
    
    # جلب جميع المعلمين مع معلوماتهم
    teachers = Teacher.objects.select_related('user').prefetch_related(
        'subjects', 'classrooms'
    ).all()
    
    # إحصائيات سريعة
    total_teachers = teachers.count()
    active_teachers = teachers.filter(user__is_active=True).count()
    inactive_teachers = total_teachers - active_teachers
    
    # جلب جميع المواد والفصول للفلاتر
    subjects = Subject.objects.all()
    classrooms = Classroom.objects.all()
    
    context = {
        'page_title': 'قائمة المعلمين',
        'teachers': teachers[:50],  # عرض أول 50 معلم
        'total_teachers': total_teachers,
        'active_teachers': active_teachers,
        'inactive_teachers': inactive_teachers,
        'subjects': subjects,
        'classrooms': classrooms,
    }
    
    return render(request, 'attendance/teacher_list.html', context)


@login_required
def add_teacher(request):
    """إضافة معلم جديد"""
    if request.user.role not in ['admin', 'manager']:
        messages.error(request, 'ليس لديك صلاحية لإضافة معلم')
        return redirect('teacher_list')
    
    if request.method == 'POST':
        try:
            # إنشاء حساب المستخدم
            username = request.POST.get('username')
            email = request.POST.get('email')
            password = request.POST.get('password')
            first_name = request.POST.get('first_name')
            last_name = request.POST.get('last_name')
            
            # التحقق من عدم وجود المستخدم
            if User.objects.filter(username=username).exists():
                messages.error(request, 'اسم المستخدم موجود بالفعل')
                return redirect('add_teacher')
            
            if User.objects.filter(email=email).exists():
                messages.error(request, 'البريد الإلكتروني موجود بالفعل')
                return redirect('add_teacher')
            
            # إنشاء المستخدم
            user = User.objects.create_user(
                username=username,
                email=email,
                password=password,
                first_name=first_name,
                last_name=last_name,
                role='teacher'
            )
            
            # إنشاء ملف المعلم
            teacher = Teacher.objects.create(
                user=user,
                school=request.user.teacher.school if hasattr(request.user, 'teacher') else None,
                employee_id=request.POST.get('employee_id'),
                phone=request.POST.get('phone'),
                address=request.POST.get('address'),
                hire_date=request.POST.get('hire_date') or timezone.now().date(),
                specialization=request.POST.get('specialization', ''),
                qualification=request.POST.get('qualification', ''),
                years_of_experience=int(request.POST.get('years_of_experience', 0)),
                is_active=True
            )
            
            # ربط المواد المحددة
            subject_ids = request.POST.getlist('subjects')
            if subject_ids:
                subjects = Subject.objects.filter(id__in=subject_ids)
                teacher.subjects.set(subjects)
            
            # ربط الفصول المحددة
            classroom_ids = request.POST.getlist('classrooms')
            if classroom_ids:
                classrooms = Classroom.objects.filter(id__in=classroom_ids)
                teacher.classrooms.set(classrooms)
            
            messages.success(request, f'تم إضافة المعلم {user.get_full_name()} بنجاح')
            return redirect('teacher_list')
            
        except Exception as e:
            messages.error(request, f'حدث خطأ أثناء إضافة المعلم: {str(e)}')
            return redirect('add_teacher')
    
    # جلب المواد والفصول للنموذج
    subjects = Subject.objects.all()
    classrooms = Classroom.objects.all()
    
    context = {
        'page_title': 'إضافة معلم جديد',
        'subjects': subjects,
        'classrooms': classrooms,
    }
    
    return render(request, 'attendance/add_teacher.html', context)


@login_required
def edit_teacher(request, teacher_id):
    """تعديل بيانات معلم"""
    if request.user.role not in ['admin', 'manager']:
        messages.error(request, 'ليس لديك صلاحية لتعديل بيانات المعلم')
        return redirect('teacher_list')
    
    teacher = get_object_or_404(Teacher, id=teacher_id)
    
    if request.method == 'POST':
        try:
            # تحديث بيانات المستخدم
            user = teacher.user
            user.first_name = request.POST.get('first_name')
            user.last_name = request.POST.get('last_name')
            user.email = request.POST.get('email')
            
            # تحديث كلمة المرور إذا تم إدخالها
            new_password = request.POST.get('password')
            if new_password:
                user.set_password(new_password)
            
            user.save()
            
            # تحديث بيانات المعلم
            teacher.employee_id = request.POST.get('employee_id')
            teacher.phone = request.POST.get('phone')
            teacher.address = request.POST.get('address')
            teacher.specialization = request.POST.get('specialization', '')
            teacher.qualification = request.POST.get('qualification', '')
            teacher.years_of_experience = int(request.POST.get('years_of_experience', 0))
            teacher.is_active = request.POST.get('is_active') == 'on'
            
            if request.POST.get('hire_date'):
                teacher.hire_date = request.POST.get('hire_date')
            
            teacher.save()
            
            # تحديث المواد
            subject_ids = request.POST.getlist('subjects')
            if subject_ids:
                subjects = Subject.objects.filter(id__in=subject_ids)
                teacher.subjects.set(subjects)
            else:
                teacher.subjects.clear()
            
            # تحديث الفصول
            classroom_ids = request.POST.getlist('classrooms')
            if classroom_ids:
                classrooms = Classroom.objects.filter(id__in=classroom_ids)
                teacher.classrooms.set(classrooms)
            else:
                teacher.classrooms.clear()
            
            messages.success(request, f'تم تحديث بيانات المعلم {user.get_full_name()} بنجاح')
            return redirect('teacher_list')
            
        except Exception as e:
            messages.error(request, f'حدث خطأ أثناء تحديث بيانات المعلم: {str(e)}')
    
    # جلب المواد والفصول للنموذج
    subjects = Subject.objects.all()
    classrooms = Classroom.objects.all()
    
    context = {
        'page_title': 'تعديل بيانات المعلم',
        'teacher': teacher,
        'subjects': subjects,
        'classrooms': classrooms,
        'teacher_subjects': list(teacher.subjects.values_list('id', flat=True)),
        'teacher_classrooms': list(teacher.classrooms.values_list('id', flat=True)),
    }
    
    return render(request, 'attendance/edit_teacher.html', context)


@login_required
def delete_teacher(request, teacher_id):
    """حذف معلم"""
    if request.user.role not in ['admin', 'manager']:
        return JsonResponse({'success': False, 'message': 'ليس لديك صلاحية لحذف المعلم'})
    
    try:
        teacher = get_object_or_404(Teacher, id=teacher_id)
        teacher_name = teacher.user.get_full_name()
        
        # حذف المعلم والمستخدم المرتبط به
        user = teacher.user
        teacher.delete()
        user.delete()
        
        return JsonResponse({
            'success': True, 
            'message': f'تم حذف المعلم {teacher_name} بنجاح'
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False, 
            'message': f'حدث خطأ أثناء حذف المعلم: {str(e)}'
        })


@login_required
def import_teachers_excel(request):
    """استيراد المعلمين من ملف Excel"""
    if request.user.role not in ['admin', 'manager']:
        messages.error(request, 'ليس لديك صلاحية لاستيراد المعلمين')
        return redirect('teacher_list')
    
    if request.method == 'POST' and request.FILES.get('excel_file'):
        try:
            import pandas as pd
            
            excel_file = request.FILES['excel_file']
            df = pd.read_excel(excel_file)
            
            # التحقق من وجود الأعمدة المطلوبة
            required_columns = ['الاسم الأول', 'الاسم الأخير', 'اسم المستخدم', 'البريد الإلكتروني', 'رقم الموظف']
            missing_columns = [col for col in required_columns if col not in df.columns]
            
            if missing_columns:
                messages.error(request, f'الأعمدة التالية مفقودة في الملف: {", ".join(missing_columns)}')
                return redirect('teacher_list')
            
            success_count = 0
            error_count = 0
            errors = []
            
            for index, row in df.iterrows():
                try:
                    # التحقق من عدم وجود المستخدم
                    username = str(row['اسم المستخدم']).strip()
                    email = str(row['البريد الإلكتروني']).strip()
                    
                    if User.objects.filter(username=username).exists():
                        errors.append(f'الصف {index + 2}: اسم المستخدم {username} موجود بالفعل')
                        error_count += 1
                        continue
                    
                    if User.objects.filter(email=email).exists():
                        errors.append(f'الصف {index + 2}: البريد الإلكتروني {email} موجود بالفعل')
                        error_count += 1
                        continue
                    
                    # إنشاء المستخدم
                    user = User.objects.create_user(
                        username=username,
                        email=email,
                        password='123456',  # كلمة مرور افتراضية
                        first_name=str(row['الاسم الأول']).strip(),
                        last_name=str(row['الاسم الأخير']).strip(),
                        role='teacher'
                    )
                    
                    # إنشاء ملف المعلم
                    Teacher.objects.create(
                        user=user,
                        school=request.user.teacher.school if hasattr(request.user, 'teacher') else None,
                        employee_id=str(row['رقم الموظف']).strip(),
                        phone=str(row.get('الهاتف', '')).strip(),
                        address=str(row.get('العنوان', '')).strip(),
                        specialization=str(row.get('التخصص', '')).strip(),
                        qualification=str(row.get('المؤهل', '')).strip(),
                        years_of_experience=int(row.get('سنوات الخبرة', 0)),
                        hire_date=timezone.now().date(),
                        is_active=True
                    )
                    
                    success_count += 1
                    
                except Exception as e:
                    errors.append(f'الصف {index + 2}: {str(e)}')
                    error_count += 1
            
            # رسائل النتائج
            if success_count > 0:
                messages.success(request, f'تم استيراد {success_count} معلم بنجاح')
            
            if error_count > 0:
                messages.warning(request, f'فشل في استيراد {error_count} معلم')
                for error in errors[:5]:  # عرض أول 5 أخطاء
                    messages.error(request, error)
            
        except Exception as e:
            messages.error(request, f'حدث خطأ أثناء قراءة الملف: {str(e)}')
    
    return redirect('teacher_list')


@login_required
def export_teachers_excel(request):
    """تصدير المعلمين إلى ملف Excel"""
    if request.user.role not in ['admin', 'manager']:
        messages.error(request, 'ليس لديك صلاحية لتصدير المعلمين')
        return redirect('teacher_list')
    
    try:
        import pandas as pd
        from io import BytesIO
        
        # جلب بيانات المعلمين
        teachers = Teacher.objects.select_related('user').prefetch_related('subjects', 'classrooms').all()
        
        data = []
        for teacher in teachers:
            data.append({
                'رقم الموظف': teacher.employee_id,
                'الاسم الأول': teacher.user.first_name,
                'الاسم الأخير': teacher.user.last_name,
                'اسم المستخدم': teacher.user.username,
                'البريد الإلكتروني': teacher.user.email,
                'الهاتف': teacher.phone,
                'العنوان': teacher.address,
                'التخصص': teacher.specialization,
                'المؤهل': teacher.qualification,
                'سنوات الخبرة': teacher.years_of_experience,
                'تاريخ التوظيف': teacher.hire_date.strftime('%Y-%m-%d') if teacher.hire_date else '',
                'الحالة': 'نشط' if teacher.is_active else 'غير نشط',
                'المواد': ', '.join([subject.name for subject in teacher.subjects.all()]),
                'الفصول': ', '.join([classroom.name for classroom in teacher.classrooms.all()]),
            })
        
        df = pd.DataFrame(data)
        
        # إنشاء ملف Excel
        output = BytesIO()
        with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
            df.to_excel(writer, sheet_name='المعلمين', index=False)
            
            # تنسيق الملف
            workbook = writer.book
            worksheet = writer.sheets['المعلمين']
            
            # تنسيق العناوين
            header_format = workbook.add_format({
                'bold': True,
                'text_wrap': True,
                'valign': 'top',
                'fg_color': '#D7E4BC',
                'border': 1
            })
            
            for col_num, value in enumerate(df.columns.values):
                worksheet.write(0, col_num, value, header_format)
                worksheet.set_column(col_num, col_num, 15)
        
        output.seek(0)
        
        response = HttpResponse(
            output.read(),
            content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        response['Content-Disposition'] = f'attachment; filename="teachers_{timezone.now().date()}.xlsx"'
        
        return response
        
    except Exception as e:
        messages.error(request, f'حدث خطأ أثناء تصدير الملف: {str(e)}')
        return redirect('teacher_list')


@login_required
def assign_teacher_subjects(request, teacher_id):
    """ربط المعلم بالمواد"""
    if request.user.role not in ['admin', 'manager']:
        return JsonResponse({'success': False, 'message': 'ليس لديك صلاحية لتعديل تخصيص المواد'})
    
    teacher = get_object_or_404(Teacher, id=teacher_id)
    
    if request.method == 'POST':
        try:
            subject_ids = request.POST.getlist('subjects')
            if subject_ids:
                subjects = Subject.objects.filter(id__in=subject_ids)
                teacher.subjects.set(subjects)
                
                return JsonResponse({
                    'success': True,
                    'message': f'تم تحديث مواد المعلم {teacher.user.get_full_name()} بنجاح'
                })
            else:
                teacher.subjects.clear()
                return JsonResponse({
                    'success': True,
                    'message': 'تم إلغاء جميع المواد للمعلم'
                })
                
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': f'حدث خطأ: {str(e)}'
            })
    
    return JsonResponse({'success': False, 'message': 'طلب غير صحيح'})


@login_required
def assign_teacher_classrooms(request, teacher_id):
    """ربط المعلم بالفصول"""
    if request.user.role not in ['admin', 'manager']:
        return JsonResponse({'success': False, 'message': 'ليس لديك صلاحية لتعديل تخصيص الفصول'})
    
    teacher = get_object_or_404(Teacher, id=teacher_id)
    
    if request.method == 'POST':
        try:
            classroom_ids = request.POST.getlist('classrooms')
            if classroom_ids:
                classrooms = Classroom.objects.filter(id__in=classroom_ids)
                teacher.classrooms.set(classrooms)
                
                return JsonResponse({
                    'success': True,
                    'message': f'تم تحديث فصول المعلم {teacher.user.get_full_name()} بنجاح'
                })
            else:
                teacher.classrooms.clear()
                return JsonResponse({
                    'success': True,
                    'message': 'تم إلغاء جميع الفصول للمعلم'
                })
                
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': f'حدث خطأ: {str(e)}'
            })
    
    return JsonResponse({'success': False, 'message': 'طلب غير صحيح'})


# =================== AJAX endpoints للمعلمين ===================

@login_required
def search_teachers_ajax(request):
    """البحث في المعلمين عبر AJAX"""
    if request.user.role not in ['admin', 'manager']:
        return JsonResponse({'success': False, 'message': 'ليس لديك صلاحية'})
    
    query = request.GET.get('q', '').strip()
    
    if len(query) < 2:
        return JsonResponse({'success': False, 'message': 'يجب أن يكون البحث أكثر من حرفين'})
    
    # البحث في المعلمين
    teachers = Teacher.objects.select_related('user').prefetch_related('subjects', 'classrooms').filter(
        Q(user__first_name__icontains=query) |
        Q(user__last_name__icontains=query) |
        Q(user__username__icontains=query) |
        Q(user__email__icontains=query) |
        Q(employee_id__icontains=query) |
        Q(phone__icontains=query) |
        Q(specialization__icontains=query)
    )[:50]
    
    # تحويل النتائج إلى JSON
    results = []
    for teacher in teachers:
        results.append({
            'id': teacher.id,
            'name': teacher.user.get_full_name(),
            'username': teacher.user.username,
            'email': teacher.user.email,
            'employee_id': teacher.employee_id,
            'phone': teacher.phone,
            'specialization': teacher.specialization,
            'qualification': teacher.qualification,
            'years_of_experience': teacher.years_of_experience,
            'is_active': teacher.is_active,
            'subjects': [{'id': s.id, 'name': s.name} for s in teacher.subjects.all()],
            'classrooms': [{'id': c.id, 'name': c.name} for c in teacher.classrooms.all()],
            'hire_date': teacher.hire_date.strftime('%Y-%m-%d') if teacher.hire_date else '',
        })
    
    return JsonResponse({
        'success': True,
        'results': results,
        'count': len(results)
    })


@login_required
def filter_teachers_ajax(request):
    """تصفية المعلمين عبر AJAX"""
    if request.user.role not in ['admin', 'manager']:
        return JsonResponse({'success': False, 'message': 'ليس لديك صلاحية'})
    
    # معايير التصفية
    subject_id = request.GET.get('subject')
    classroom_id = request.GET.get('classroom')
    status = request.GET.get('status')
    specialization = request.GET.get('specialization')
    
    # بناء الاستعلام
    teachers = Teacher.objects.select_related('user').prefetch_related('subjects', 'classrooms').all()
    
    if subject_id:
        teachers = teachers.filter(subjects__id=subject_id)
    
    if classroom_id:
        teachers = teachers.filter(classrooms__id=classroom_id)
    
    if status == 'active':
        teachers = teachers.filter(is_active=True)
    elif status == 'inactive':
        teachers = teachers.filter(is_active=False)
    
    if specialization:
        teachers = teachers.filter(specialization__icontains=specialization)
    
    teachers = teachers.distinct()[:50]
    
    # إحصائيات
    total_count = teachers.count()
    active_count = teachers.filter(is_active=True).count()
    inactive_count = total_count - active_count
    
    # تحويل النتائج إلى JSON
    results = []
    for teacher in teachers:
        results.append({
            'id': teacher.id,
            'name': teacher.user.get_full_name(),
            'username': teacher.user.username,
            'email': teacher.user.email,
            'employee_id': teacher.employee_id,
            'phone': teacher.phone,
            'specialization': teacher.specialization,
            'qualification': teacher.qualification,
            'years_of_experience': teacher.years_of_experience,
            'is_active': teacher.is_active,
            'subjects': [{'id': s.id, 'name': s.name} for s in teacher.subjects.all()],
            'classrooms': [{'id': c.id, 'name': c.name} for c in teacher.classrooms.all()],
            'hire_date': teacher.hire_date.strftime('%Y-%m-%d') if teacher.hire_date else '',
        })
    
    return JsonResponse({
        'success': True,
        'results': results,
        'statistics': {
            'total': total_count,
            'active': active_count,
            'inactive': inactive_count,
        }
    })


@login_required
def get_teacher_subjects(request, teacher_id):
    """جلب مواد معلم معين"""
    teacher = get_object_or_404(Teacher, id=teacher_id)
    subjects = [{'id': s.id, 'name': s.name} for s in teacher.subjects.all()]
    
    return JsonResponse({
        'success': True,
        'subjects': subjects
    })


@login_required
def get_teacher_classrooms(request, teacher_id):
    """جلب فصول معلم معين"""
    teacher = get_object_or_404(Teacher, id=teacher_id)
    classrooms = [{'id': c.id, 'name': c.name} for c in teacher.classrooms.all()]
    
    return JsonResponse({
        'success': True,
        'classrooms': classrooms
    })



# =================== نظام التقارير المتكامل ===================

from .models import ReportTemplate, ScheduledReport, ReportExecution, UserReportPreference, ReportComment
from datetime import timedelta
import json

@login_required
def admin_reports(request):
    """تقارير الإدارة الشاملة"""
    if request.user.role not in ['admin', 'manager']:
        messages.error(request, 'ليس لديك صلاحية للوصول لتقارير الإدارة')
        return redirect('dashboard')
    
    # إحصائيات عامة للمدرسة
    total_students = Student.objects.count()
    total_teachers = Teacher.objects.count()
    total_classrooms = Classroom.objects.count()
    total_subjects = Subject.objects.count()
    
    # إحصائيات الحضور العامة
    today = timezone.now().date()
    last_30_days = today - timedelta(days=30)
    
    recent_sessions = AttendanceSession.objects.filter(
        date__gte=last_30_days
    ).count()
    
    recent_records = AttendanceRecord.objects.filter(
        session__date__gte=last_30_days
    )
    
    total_records = recent_records.count()
    present_records = recent_records.filter(status='present').count()
    absent_records = recent_records.filter(status='absent').count()
    late_records = recent_records.filter(status='late').count()
    
    attendance_rate = (present_records / total_records * 100) if total_records > 0 else 0
    
    # إحصائيات المعلمين
    active_teachers = Teacher.objects.filter(user__is_active=True).count()
    # teachers_with_sessions = Teacher.objects.filter(
    #     subjects__attendancesession__date__gte=last_30_days
    # ).distinct().count()
    teachers_with_sessions = 0  # مؤقتاً حتى يتم إصلاح العلاقات
    
    # إحصائيات الفصول
    # classrooms_with_sessions = Classroom.objects.filter(
    #     attendancesession__date__gte=last_30_days
    # ).distinct().count()
    classrooms_with_sessions = 0  # مؤقتاً
    
    # أفضل وأسوأ الفصول من ناحية الحضور
    classroom_stats = []
    # مؤقتاً - سيتم إضافة الإحصائيات لاحقاً
    
    # إحصائيات المواد
    subject_stats = []
    # مؤقتاً - سيتم إضافة الإحصائيات لاحقاً
    
    # إحصائيات يومية للأسبوع الماضي
    daily_stats = []
    # مؤقتاً - سيتم إضافة الإحصائيات لاحقاً
    
    # قوالب التقارير المتاحة للإدارة
    # admin_templates = ReportTemplate.objects.filter(
    #     target_roles__contains=['admin'],
    #     is_active=True
    # )
    admin_templates = []  # مؤقتاً حتى يتم إنشاء نموذج ReportTemplate
    
    context = {
        'page_title': 'تقارير الإدارة',
        'total_students': total_students,
        'total_teachers': total_teachers,
        'total_classrooms': total_classrooms,
        'total_subjects': total_subjects,
        'recent_sessions': recent_sessions,
        'total_records': total_records,
        'present_records': present_records,
        'absent_records': absent_records,
        'late_records': late_records,
        'attendance_rate': round(attendance_rate, 2),
        'active_teachers': active_teachers,
        'teachers_with_sessions': teachers_with_sessions,
        'classrooms_with_sessions': classrooms_with_sessions,
        'classroom_stats': classroom_stats[:10],  # أفضل 10 فصول
        'subject_stats': subject_stats[:10],  # أفضل 10 مواد
        'daily_stats': daily_stats,
        'admin_templates': admin_templates,
    }
    
    return render(request, 'attendance/reports/admin_reports.html', context)


@login_required
def teacher_reports(request):
    """تقارير المعلمين"""
    if request.user.role != 'teacher':
        messages.error(request, 'ليس لديك صلاحية للوصول لتقارير المعلمين')
        return redirect('dashboard')
    
    try:
        teacher = request.user.teacher
    except:
        messages.error(request, 'لم يتم العثور على ملف المعلم')
        return redirect('dashboard')
    
    # الفصول والمواد المخصصة للمعلم
    teacher_classrooms = teacher.classrooms.all()
    teacher_subjects = teacher.subjects.all()
    
    # إحصائيات المعلم
    today = timezone.now().date()
    last_30_days = today - timedelta(days=30)
    
    # جلسات المعلم
    teacher_sessions = AttendanceSession.objects.filter(
        teacher=teacher,
        date__gte=last_30_days
    )
    
    total_sessions = teacher_sessions.count()
    
    # سجلات الحضور لطلاب المعلم
    teacher_records = AttendanceRecord.objects.filter(
        session__teacher=teacher,
        session__date__gte=last_30_days
    )
    
    total_records = teacher_records.count()
    present_records = teacher_records.filter(status='present').count()
    absent_records = teacher_records.filter(status='absent').count()
    late_records = teacher_records.filter(status='late').count()
    
    attendance_rate = (present_records / total_records * 100) if total_records > 0 else 0
    
    # إحصائيات الفصول
    classroom_stats = []
    for classroom in teacher_classrooms:
        classroom_records = AttendanceRecord.objects.filter(
            session__classroom=classroom,
            session__teacher=teacher,
            session__date__gte=last_30_days
        )
        total = classroom_records.count()
        present = classroom_records.filter(status='present').count()
        rate = (present / total * 100) if total > 0 else 0
        
        classroom_stats.append({
            'classroom': classroom,
            'total_records': total,
            'present_records': present,
            'attendance_rate': round(rate, 2)
        })
    
    # إحصائيات المواد
    subject_stats = []
    for subject in teacher_subjects:
        subject_records = AttendanceRecord.objects.filter(
            session__subject=subject,
            session__teacher=teacher,
            session__date__gte=last_30_days
        )
        total = subject_records.count()
        present = subject_records.filter(status='present').count()
        rate = (present / total * 100) if total > 0 else 0
        
        subject_stats.append({
            'subject': subject,
            'total_records': total,
            'present_records': present,
            'attendance_rate': round(rate, 2)
        })
    
    # الطلاب الأكثر غياباً
    absent_students = []
    for classroom in teacher_classrooms:
        for student in classroom.students.all():
            student_records = AttendanceRecord.objects.filter(
                student=student,
                session__teacher=teacher,
                session__date__gte=last_30_days
            )
            total = student_records.count()
            absent = student_records.filter(status='absent').count()
            absent_rate = (absent / total * 100) if total > 0 else 0
            
            if absent_rate > 20:  # الطلاب الذين غابوا أكثر من 20%
                absent_students.append({
                    'student': student,
                    'total_records': total,
                    'absent_records': absent,
                    'absent_rate': round(absent_rate, 2)
                })
    
    absent_students.sort(key=lambda x: x['absent_rate'], reverse=True)
    
    # قوالب التقارير المتاحة للمعلمين
    teacher_templates = ReportTemplate.objects.filter(
        target_roles__contains=['teacher'],
        is_active=True
    )
    
    context = {
        'page_title': 'تقارير المعلم',
        'teacher': teacher,
        'teacher_classrooms': teacher_classrooms,
        'teacher_subjects': teacher_subjects,
        'total_sessions': total_sessions,
        'total_records': total_records,
        'present_records': present_records,
        'absent_records': absent_records,
        'late_records': late_records,
        'attendance_rate': round(attendance_rate, 2),
        'classroom_stats': classroom_stats,
        'subject_stats': subject_stats,
        'absent_students': absent_students[:10],  # أكثر 10 طلاب غياباً
        'teacher_templates': teacher_templates,
    }
    
    return render(request, 'attendance/reports/teacher_reports.html', context)


@login_required
def student_reports(request):
    """تقارير الطلاب"""
    if request.user.role != 'student':
        messages.error(request, 'ليس لديك صلاحية للوصول لتقارير الطلاب')
        return redirect('dashboard')
    
    try:
        student = request.user.student
    except:
        messages.error(request, 'لم يتم العثور على ملف الطالب')
        return redirect('dashboard')
    
    # إحصائيات الطالب
    today = timezone.now().date()
    last_30_days = today - timedelta(days=30)
    
    # سجلات حضور الطالب
    student_records = AttendanceRecord.objects.filter(
        student=student,
        session__date__gte=last_30_days
    )
    
    total_records = student_records.count()
    present_records = student_records.filter(status='present').count()
    absent_records = student_records.filter(status='absent').count()
    late_records = student_records.filter(status='late').count()
    excused_records = student_records.filter(status='excused').count()
    
    attendance_rate = (present_records / total_records * 100) if total_records > 0 else 0
    
    # إحصائيات حسب المادة
    subject_stats = []
    subjects = Subject.objects.filter(
        attendancesession__attendancerecord__student=student,
        attendancesession__date__gte=last_30_days
    ).distinct()
    
    for subject in subjects:
        subject_records = student_records.filter(session__subject=subject)
        total = subject_records.count()
        present = subject_records.filter(status='present').count()
        rate = (present / total * 100) if total > 0 else 0
        
        subject_stats.append({
            'subject': subject,
            'total_records': total,
            'present_records': present,
            'attendance_rate': round(rate, 2)
        })
    
    # إحصائيات يومية للأسبوع الماضي
    daily_stats = []
    for i in range(7):
        date = today - timedelta(days=i)
        day_records = student_records.filter(session__date=date)
        total = day_records.count()
        present = day_records.filter(status='present').count()
        
        daily_stats.append({
            'date': date,
            'total_sessions': total,
            'attended_sessions': present,
            'attendance_rate': (present / total * 100) if total > 0 else 0
        })
    
    daily_stats.reverse()
    
    # آخر 10 سجلات حضور
    recent_records = student_records.order_by('-session__date', '-session__start_time')[:10]
    
    # قوالب التقارير المتاحة للطلاب
    student_templates = ReportTemplate.objects.filter(
        target_roles__contains=['student'],
        is_active=True
    )
    
    context = {
        'page_title': 'تقاريري الشخصية',
        'student': student,
        'total_records': total_records,
        'present_records': present_records,
        'absent_records': absent_records,
        'late_records': late_records,
        'excused_records': excused_records,
        'attendance_rate': round(attendance_rate, 2),
        'subject_stats': subject_stats,
        'daily_stats': daily_stats,
        'recent_records': recent_records,
        'student_templates': student_templates,
    }
    
    return render(request, 'attendance/reports/student_reports.html', context)


@login_required
def parent_reports(request):
    """تقارير أولياء الأمور"""
    if request.user.role != 'parent':
        messages.error(request, 'ليس لديك صلاحية للوصول لتقارير أولياء الأمور')
        return redirect('dashboard')
    
    # جلب الأبناء المرتبطين بولي الأمر
    children = Student.objects.filter(parent_email=request.user.email)
    
    if not children.exists():
        messages.warning(request, 'لم يتم العثور على أبناء مرتبطين بحسابك')
        return redirect('dashboard')
    
    # إحصائيات شاملة لجميع الأبناء
    today = timezone.now().date()
    last_30_days = today - timedelta(days=30)
    
    children_stats = []
    total_all_records = 0
    total_all_present = 0
    
    for child in children:
        child_records = AttendanceRecord.objects.filter(
            student=child,
            session__date__gte=last_30_days
        )
        
        total = child_records.count()
        present = child_records.filter(status='present').count()
        absent = child_records.filter(status='absent').count()
        late = child_records.filter(status='late').count()
        excused = child_records.filter(status='excused').count()
        
        attendance_rate = (present / total * 100) if total > 0 else 0
        
        # آخر 5 سجلات للطفل
        recent_records = child_records.order_by('-session__date', '-session__start_time')[:5]
        
        children_stats.append({
            'child': child,
            'total_records': total,
            'present_records': present,
            'absent_records': absent,
            'late_records': late,
            'excused_records': excused,
            'attendance_rate': round(attendance_rate, 2),
            'recent_records': recent_records,
        })
        
        total_all_records += total
        total_all_present += present
    
    # معدل الحضور العام لجميع الأبناء
    overall_attendance_rate = (total_all_present / total_all_records * 100) if total_all_records > 0 else 0
    
    # التنبيهات (الأطفال الذين لديهم غياب مرتفع)
    alerts = []
    for child_stat in children_stats:
        if child_stat['attendance_rate'] < 80:  # أقل من 80%
            alerts.append({
                'child': child_stat['child'],
                'message': f"معدل حضور منخفض: {child_stat['attendance_rate']}%",
                'type': 'warning'
            })
        
        if child_stat['absent_records'] > 5:  # أكثر من 5 أيام غياب
            alerts.append({
                'child': child_stat['child'],
                'message': f"غياب متكرر: {child_stat['absent_records']} يوم",
                'type': 'danger'
            })
    
    # قوالب التقارير المتاحة لأولياء الأمور
    parent_templates = ReportTemplate.objects.filter(
        target_roles__contains=['parent'],
        is_active=True
    )
    
    context = {
        'page_title': 'تقارير أولياء الأمور',
        'children': children,
        'children_stats': children_stats,
        'total_all_records': total_all_records,
        'total_all_present': total_all_present,
        'overall_attendance_rate': round(overall_attendance_rate, 2),
        'alerts': alerts,
        'parent_templates': parent_templates,
    }
    
    return render(request, 'attendance/reports/parent_reports.html', context)


@login_required
def report_templates(request):
    """إدارة قوالب التقارير"""
    if request.user.role not in ['admin', 'manager']:
        messages.error(request, 'ليس لديك صلاحية لإدارة قوالب التقارير')
        return redirect('dashboard')
    
    templates = ReportTemplate.objects.all().order_by('-created_at')
    
    context = {
        'page_title': 'قوالب التقارير',
        'templates': templates,
    }
    
    return render(request, 'attendance/reports/report_templates.html', context)


@login_required
def execute_report(request, template_id):
    """تنفيذ تقرير"""
    template = get_object_or_404(ReportTemplate, id=template_id)
    
    # التحقق من الصلاحيات
    if request.user.role not in template.target_roles:
        messages.error(request, 'ليس لديك صلاحية لتنفيذ هذا التقرير')
        return redirect('dashboard')
    
    if request.method == 'POST':
        try:
            # إنشاء سجل تنفيذ
            execution = ReportExecution.objects.create(
                template=template,
                executed_by=request.user,
                filters_used=json.loads(request.POST.get('filters', '{}')),
                date_range={
                    'start_date': request.POST.get('start_date'),
                    'end_date': request.POST.get('end_date')
                },
                status='running'
            )
            
            # هنا يمكن إضافة منطق تنفيذ التقرير الفعلي
            # مثل جمع البيانات وإنشاء الملف
            
            execution.status = 'completed'
            execution.records_count = 100  # مثال
            execution.save()
            
            messages.success(request, 'تم تنفيذ التقرير بنجاح')
            return redirect('view_report_execution', execution_id=execution.id)
            
        except Exception as e:
            messages.error(request, f'حدث خطأ أثناء تنفيذ التقرير: {str(e)}')
    
    context = {
        'page_title': f'تنفيذ تقرير: {template.name}',
        'template': template,
    }
    
    return render(request, 'attendance/reports/execute_report.html', context)


@login_required
def view_report_execution(request, execution_id):
    """عرض نتيجة تنفيذ تقرير"""
    execution = get_object_or_404(ReportExecution, id=execution_id)
    
    # التحقق من الصلاحيات
    if execution.executed_by != request.user and request.user.role not in ['admin', 'manager']:
        messages.error(request, 'ليس لديك صلاحية لعرض هذا التقرير')
        return redirect('dashboard')
    
    context = {
        'page_title': f'تقرير: {execution.template.name}',
        'execution': execution,
    }
    
    return render(request, 'attendance/reports/view_execution.html', context)


@login_required
def report_preferences(request):
    """تفضيلات المستخدم للتقارير"""
    preferences, created = UserReportPreference.objects.get_or_create(
        user=request.user
    )
    
    if request.method == 'POST':
        preferences.default_date_range = request.POST.get('default_date_range')
        preferences.preferred_export_format = request.POST.get('preferred_export_format')
        preferences.email_reports = request.POST.get('email_reports') == 'on'
        preferences.notification_frequency = request.POST.get('notification_frequency')
        preferences.save()
        
        messages.success(request, 'تم حفظ تفضيلاتك بنجاح')
        return redirect('report_preferences')
    
    context = {
        'page_title': 'تفضيلات التقارير',
        'preferences': preferences,
    }
    
    return render(request, 'attendance/reports/preferences.html', context)


# ===== وظائف نظام الجداول الدراسية =====

from .models import (Schedule, ScheduleSlot, TimeSlot, ScheduleTemplate, 
                    ScheduleConflict, UserSchedulePreference)
from datetime import datetime, timedelta
import json

@login_required
def schedule_list(request):
    """عرض قائمة الجداول الدراسية"""
    from .models import Teacher, Classroom, Subject, ScheduleSlot
    
    # جلب البيانات الأساسية
    teachers = Teacher.objects.select_related('user').all()
    classrooms = Classroom.objects.all()
    subjects = Subject.objects.all()
    
    # جلب الجداول والحصص
    schedules = Schedule.objects.filter(is_active=True).order_by('-created_at')
    schedule_slots = ScheduleSlot.objects.select_related(
        'teacher__user', 'subject', 'classroom'
    ).all()
    
    # إحصائيات الحصص
    total_slots = schedule_slots.count()
    scheduled_slots = schedule_slots.filter(
        teacher__isnull=False, 
        subject__isnull=False, 
        classroom__isnull=False
    ).count()
    empty_slots = total_slots - scheduled_slots
    conflicts_count = 0  # سيتم حسابها لاحقاً
    
    # تنظيم البيانات حسب الأيام
    days_map = {
        1: {'name': 'الأحد', 'slots': []},
        2: {'name': 'الاثنين', 'slots': []},
        3: {'name': 'الثلاثاء', 'slots': []},
        4: {'name': 'الأربعاء', 'slots': []},
        5: {'name': 'الخميس', 'slots': []},
    }
    
    # تجميع الحصص حسب الأيام
    for slot in schedule_slots:
        day = slot.day_of_week
        if day in days_map:
            days_map[day]['slots'].append(slot)
    
    # إحصائيات سريعة للجداول
    total_schedules = schedules.count()
    active_schedules = schedules.filter(is_active=True).count()
    current_schedules = schedules.filter(
        start_date__lte=timezone.now().date(),
        end_date__gte=timezone.now().date()
    ).count()
    
    context = {
        'schedules': schedules,
        'teachers': teachers,
        'classrooms': classrooms,
        'subjects': subjects,
        'schedule_data': days_map,
        'total_slots': total_slots,
        'scheduled_slots': scheduled_slots,
        'empty_slots': empty_slots,
        'conflicts_count': conflicts_count,
        'total_schedules': total_schedules,
        'active_schedules': active_schedules,
        'current_schedules': current_schedules,
    }
    
    return render(request, 'attendance/schedules/schedule_list.html', context)

@login_required
def create_schedule(request):
    """إنشاء جدول دراسي جديد"""
    if request.method == 'POST':
        try:
            schedule = Schedule.objects.create(
                name=request.POST.get('name'),
                description=request.POST.get('description', ''),
                schedule_type=request.POST.get('schedule_type', 'weekly'),
                academic_year=request.POST.get('academic_year'),
                semester=request.POST.get('semester'),
                start_date=request.POST.get('start_date'),
                end_date=request.POST.get('end_date'),
                created_by=request.user
            )
            
            messages.success(request, f'تم إنشاء الجدول "{schedule.name}" بنجاح')
            return redirect('schedule_detail', schedule_id=schedule.id)
            
        except Exception as e:
            messages.error(request, f'حدث خطأ أثناء إنشاء الجدول: {str(e)}')
    
    # جلب البيانات المطلوبة للنموذج
    current_year = timezone.now().year
    academic_years = [f"{current_year-1}-{current_year}", f"{current_year}-{current_year+1}"]
    
    context = {
        'academic_years': academic_years,
    }
    
    return render(request, 'attendance/schedules/create_schedule.html', context)

@login_required
def schedule_detail(request, schedule_id):
    """تفاصيل الجدول الدراسي"""
    schedule = get_object_or_404(Schedule, id=schedule_id)
    
    # جلب الحصص مرتبة حسب اليوم والوقت
    slots = ScheduleSlot.objects.filter(
        schedule=schedule, 
        is_active=True
    ).select_related('time_slot', 'subject', 'teacher', 'classroom').order_by(
        'day_of_week', 'time_slot__order'
    )
    
    # تنظيم الحصص في جدول أسبوعي
    weekly_schedule = {}
    time_slots = TimeSlot.objects.filter(is_active=True).order_by('order')
    
    for day in range(1, 8):  # الأحد إلى السبت
        weekly_schedule[day] = {}
        for time_slot in time_slots:
            slot = slots.filter(day_of_week=day, time_slot=time_slot).first()
            weekly_schedule[day][time_slot.id] = slot
    
    # إحصائيات الجدول
    total_slots = slots.count()
    unique_teachers = slots.values('teacher').distinct().count()
    unique_classrooms = slots.values('classroom').distinct().count()
    unique_subjects = slots.values('subject').distinct().count()
    
    # التضاربات
    conflicts = ScheduleConflict.objects.filter(
        schedule=schedule, 
        is_resolved=False
    ).order_by('-detected_at')
    
    context = {
        'schedule': schedule,
        'weekly_schedule': weekly_schedule,
        'time_slots': time_slots,
        'days_of_week': ScheduleSlot.DAYS_OF_WEEK,
        'total_slots': total_slots,
        'unique_teachers': unique_teachers,
        'unique_classrooms': unique_classrooms,
        'unique_subjects': unique_subjects,
        'conflicts': conflicts,
    }
    
    return render(request, 'attendance/schedules/schedule_detail.html', context)

@login_required
def my_schedule(request):
    """جدولي الشخصي حسب دور المستخدم"""
    user_role = request.user.role
    
    if user_role == 'teacher':
        return teacher_schedule(request, request.user.teacher.id)
    elif user_role == 'student':
        return student_schedule(request, request.user.student.id)
    elif user_role == 'parent':
        return parent_schedule(request)
    else:
        # للإدارة - عرض جميع الجداول النشطة
        return redirect('schedule_list')

@login_required
def teacher_schedule(request, teacher_id):
    """جدول المعلم"""
    teacher = get_object_or_404(Teacher, id=teacher_id)
    
    # التحقق من الصلاحية
    if request.user.role == 'teacher' and request.user.teacher.id != teacher_id:
        messages.error(request, 'ليس لديك صلاحية لعرض هذا الجدول')
        return redirect('my_schedule')
    
    # جلب الحصص الحالية للمعلم
    current_date = timezone.now().date()
    slots = ScheduleSlot.objects.filter(
        teacher=teacher,
        schedule__is_active=True,
        schedule__start_date__lte=current_date,
        schedule__end_date__gte=current_date,
        is_active=True
    ).select_related('time_slot', 'subject', 'classroom', 'schedule').order_by(
        'day_of_week', 'time_slot__order'
    )
    
    # تنظيم الجدول الأسبوعي
    weekly_schedule = {}
    time_slots = TimeSlot.objects.filter(is_active=True).order_by('order')
    
    for day in range(1, 8):
        weekly_schedule[day] = {}
        for time_slot in time_slots:
            slot = slots.filter(day_of_week=day, time_slot=time_slot).first()
            weekly_schedule[day][time_slot.id] = slot
    
    # إحصائيات المعلم
    total_weekly_hours = sum([slot.time_slot.duration_minutes for slot in slots]) / 60
    unique_subjects = slots.values('subject').distinct().count()
    unique_classrooms = slots.values('classroom').distinct().count()
    
    # الحصص اليوم
    today = timezone.now().weekday() + 2  # تحويل إلى نظام الأحد=1
    if today > 7:
        today = 1
    today_slots = slots.filter(day_of_week=today).order_by('time_slot__order')
    
    context = {
        'teacher': teacher,
        'weekly_schedule': weekly_schedule,
        'time_slots': time_slots,
        'days_of_week': ScheduleSlot.DAYS_OF_WEEK,
        'total_weekly_hours': total_weekly_hours,
        'unique_subjects': unique_subjects,
        'unique_classrooms': unique_classrooms,
        'today_slots': today_slots,
    }
    
    return render(request, 'attendance/schedules/teacher_schedule.html', context)

@login_required
def student_schedule(request, student_id):
    """جدول الطالب"""
    student = get_object_or_404(Student, id=student_id)
    
    # التحقق من الصلاحية
    if request.user.role == 'student' and request.user.student.id != student_id:
        messages.error(request, 'ليس لديك صلاحية لعرض هذا الجدول')
        return redirect('my_schedule')
    
    # جلب الحصص للفصل الذي ينتمي إليه الطالب
    current_date = timezone.now().date()
    slots = ScheduleSlot.objects.filter(
        classroom=student.classroom,
        schedule__is_active=True,
        schedule__start_date__lte=current_date,
        schedule__end_date__gte=current_date,
        is_active=True
    ).select_related('time_slot', 'subject', 'teacher', 'schedule').order_by(
        'day_of_week', 'time_slot__order'
    )
    
    # تنظيم الجدول الأسبوعي
    weekly_schedule = {}
    time_slots = TimeSlot.objects.filter(is_active=True).order_by('order')
    
    for day in range(1, 8):
        weekly_schedule[day] = {}
        for time_slot in time_slots:
            slot = slots.filter(day_of_week=day, time_slot=time_slot).first()
            weekly_schedule[day][time_slot.id] = slot
    
    # إحصائيات الطالب
    total_weekly_hours = sum([slot.time_slot.duration_minutes for slot in slots]) / 60
    unique_subjects = slots.values('subject').distinct().count()
    unique_teachers = slots.values('teacher').distinct().count()
    
    # الحصص اليوم
    today = timezone.now().weekday() + 2
    if today > 7:
        today = 1
    today_slots = slots.filter(day_of_week=today).order_by('time_slot__order')
    
    # الحصة التالية
    now = timezone.now().time()
    next_slot = today_slots.filter(time_slot__start_time__gt=now).first()
    
    context = {
        'student': student,
        'weekly_schedule': weekly_schedule,
        'time_slots': time_slots,
        'days_of_week': ScheduleSlot.DAYS_OF_WEEK,
        'total_weekly_hours': total_weekly_hours,
        'unique_subjects': unique_subjects,
        'unique_teachers': unique_teachers,
        'today_slots': today_slots,
        'next_slot': next_slot,
    }
    
    return render(request, 'attendance/schedules/student_schedule.html', context)

@login_required
def parent_schedule(request):
    """جداول أبناء ولي الأمر"""
    if request.user.role != 'parent':
        messages.error(request, 'ليس لديك صلاحية لعرض هذه الصفحة')
        return redirect('dashboard')
    
    # جلب جميع الأبناء
    children = Student.objects.filter(parent=request.user)
    children_schedules = []
    
    current_date = timezone.now().date()
    
    for child in children:
        # جلب جدول كل طفل
        slots = ScheduleSlot.objects.filter(
            classroom=child.classroom,
            schedule__is_active=True,
            schedule__start_date__lte=current_date,
            schedule__end_date__gte=current_date,
            is_active=True
        ).select_related('time_slot', 'subject', 'teacher').order_by(
            'day_of_week', 'time_slot__order'
        )
        
        # تنظيم الجدول الأسبوعي
        weekly_schedule = {}
        time_slots = TimeSlot.objects.filter(is_active=True).order_by('order')
        
        for day in range(1, 8):
            weekly_schedule[day] = {}
            for time_slot in time_slots:
                slot = slots.filter(day_of_week=day, time_slot=time_slot).first()
                weekly_schedule[day][time_slot.id] = slot
        
        # الحصص اليوم
        today = timezone.now().weekday() + 2
        if today > 7:
            today = 1
        today_slots = slots.filter(day_of_week=today).order_by('time_slot__order')
        
        children_schedules.append({
            'child': child,
            'weekly_schedule': weekly_schedule,
            'today_slots': today_slots,
            'total_weekly_hours': sum([slot.time_slot.duration_minutes for slot in slots]) / 60,
        })
    
    time_slots = TimeSlot.objects.filter(is_active=True).order_by('order')
    
    context = {
        'children_schedules': children_schedules,
        'time_slots': time_slots,
        'days_of_week': ScheduleSlot.DAYS_OF_WEEK,
    }
    
    return render(request, 'attendance/schedules/parent_schedule.html', context)

@login_required
def add_schedule_slot(request, schedule_id):
    """إضافة حصة جديدة للجدول"""
    schedule = get_object_or_404(Schedule, id=schedule_id)
    
    if request.method == 'POST':
        try:
            # التحقق من عدم وجود تضارب
            day_of_week = int(request.POST.get('day_of_week'))
            time_slot_id = int(request.POST.get('time_slot'))
            teacher_id = int(request.POST.get('teacher'))
            classroom_id = int(request.POST.get('classroom'))
            
            # فحص تضارب المعلم
            teacher_conflict = ScheduleSlot.objects.filter(
                schedule=schedule,
                day_of_week=day_of_week,
                time_slot_id=time_slot_id,
                teacher_id=teacher_id,
                is_active=True
            ).exists()
            
            # فحص تضارب الفصل
            classroom_conflict = ScheduleSlot.objects.filter(
                schedule=schedule,
                day_of_week=day_of_week,
                time_slot_id=time_slot_id,
                classroom_id=classroom_id,
                is_active=True
            ).exists()
            
            if teacher_conflict:
                messages.error(request, 'المعلم محجوز في هذا الوقت')
                return redirect('schedule_detail', schedule_id=schedule_id)
            
            if classroom_conflict:
                messages.error(request, 'الفصل محجوز في هذا الوقت')
                return redirect('schedule_detail', schedule_id=schedule_id)
            
            # إنشاء الحصة
            slot = ScheduleSlot.objects.create(
                schedule=schedule,
                day_of_week=day_of_week,
                time_slot_id=time_slot_id,
                subject_id=request.POST.get('subject'),
                teacher_id=teacher_id,
                classroom_id=classroom_id,
                room_number=request.POST.get('room_number', ''),
                notes=request.POST.get('notes', '')
            )
            
            messages.success(request, 'تم إضافة الحصة بنجاح')
            return redirect('schedule_detail', schedule_id=schedule_id)
            
        except Exception as e:
            messages.error(request, f'حدث خطأ أثناء إضافة الحصة: {str(e)}')
    
    # جلب البيانات للنموذج
    time_slots = TimeSlot.objects.filter(is_active=True).order_by('order')
    subjects = Subject.objects.filter(is_active=True)
    teachers = Teacher.objects.filter(user__is_active=True)
    classrooms = Classroom.objects.filter(is_active=True)
    
    context = {
        'schedule': schedule,
        'time_slots': time_slots,
        'subjects': subjects,
        'teachers': teachers,
        'classrooms': classrooms,
        'days_of_week': ScheduleSlot.DAYS_OF_WEEK,
    }
    
    return render(request, 'attendance/schedules/add_schedule_slot.html', context)

@login_required
def time_slot_list(request):
    """إدارة الفترات الزمنية"""
    time_slots = TimeSlot.objects.filter(is_active=True).order_by('order')
    
    if request.method == 'POST':
        try:
            TimeSlot.objects.create(
                name=request.POST.get('name'),
                start_time=request.POST.get('start_time'),
                end_time=request.POST.get('end_time'),
                duration_minutes=int(request.POST.get('duration_minutes')),
                is_break=request.POST.get('is_break') == 'on',
                order=int(request.POST.get('order', 1))
            )
            messages.success(request, 'تم إضافة الفترة الزمنية بنجاح')
        except Exception as e:
            messages.error(request, f'حدث خطأ: {str(e)}')
        
        return redirect('time_slot_list')
    
    context = {
        'time_slots': time_slots,
    }
    
    return render(request, 'attendance/schedules/time_slot_list.html', context)

# AJAX endpoints للجداول
@login_required
def get_schedule_data(request, schedule_id):
    """جلب بيانات الجدول بصيغة JSON"""
    schedule = get_object_or_404(Schedule, id=schedule_id)
    
    slots = ScheduleSlot.objects.filter(
        schedule=schedule,
        is_active=True
    ).select_related('time_slot', 'subject', 'teacher', 'classroom')
    
    schedule_data = []
    for slot in slots:
        schedule_data.append({
            'id': slot.id,
            'day_of_week': slot.day_of_week,
            'day_name': slot.get_day_of_week_display(),
            'time_slot': {
                'id': slot.time_slot.id,
                'name': slot.time_slot.name,
                'start_time': slot.time_slot.start_time.strftime('%H:%M'),
                'end_time': slot.time_slot.end_time.strftime('%H:%M'),
            },
            'subject': {
                'id': slot.subject.id,
                'name': slot.subject.name,
            },
            'teacher': {
                'id': slot.teacher.id,
                'name': slot.teacher.user.get_full_name(),
            },
            'classroom': {
                'id': slot.classroom.id,
                'name': slot.classroom.name,
            },
            'room_number': slot.room_number,
            'notes': slot.notes,
        })
    
    return JsonResponse({
        'schedule': {
            'id': schedule.id,
            'name': schedule.name,
            'academic_year': schedule.academic_year,
            'semester': schedule.semester,
        },
        'slots': schedule_data
    })

@login_required
def get_available_teachers(request):
    """جلب المعلمين المتاحين في وقت معين"""
    day_of_week = request.GET.get('day_of_week')
    time_slot_id = request.GET.get('time_slot_id')
    schedule_id = request.GET.get('schedule_id')
    
    if not all([day_of_week, time_slot_id, schedule_id]):
        return JsonResponse({'error': 'معاملات مفقودة'}, status=400)
    
    # المعلمين المحجوزين في هذا الوقت
    busy_teachers = ScheduleSlot.objects.filter(
        schedule_id=schedule_id,
        day_of_week=day_of_week,
        time_slot_id=time_slot_id,
        is_active=True
    ).values_list('teacher_id', flat=True)
    
    # المعلمين المتاحين
    available_teachers = Teacher.objects.filter(
        user__is_active=True
    ).exclude(id__in=busy_teachers)
    
    teachers_data = []
    for teacher in available_teachers:
        teachers_data.append({
            'id': teacher.id,
            'name': teacher.user.get_full_name(),
            'specialization': teacher.specialization,
        })
    
    return JsonResponse({'teachers': teachers_data})

@login_required
def get_available_classrooms(request):
    """جلب الفصول المتاحة في وقت معين"""
    day_of_week = request.GET.get('day_of_week')
    time_slot_id = request.GET.get('time_slot_id')
    schedule_id = request.GET.get('schedule_id')
    
    if not all([day_of_week, time_slot_id, schedule_id]):
        return JsonResponse({'error': 'معاملات مفقودة'}, status=400)
    
    # الفصول المحجوزة في هذا الوقت
    busy_classrooms = ScheduleSlot.objects.filter(
        schedule_id=schedule_id,
        day_of_week=day_of_week,
        time_slot_id=time_slot_id,
        is_active=True
    ).values_list('classroom_id', flat=True)
    
    # الفصول المتاحة
    available_classrooms = Classroom.objects.filter(
        is_active=True
    ).exclude(id__in=busy_classrooms)
    
    classrooms_data = []
    for classroom in available_classrooms:
        classrooms_data.append({
            'id': classroom.id,
            'name': classroom.name,
            'grade': classroom.grade.name,
            'capacity': classroom.capacity,
        })
    
    return JsonResponse({'classrooms': classrooms_data})

@login_required
def export_schedule_pdf(request, schedule_id):
    """تصدير الجدول إلى PDF"""
    schedule = get_object_or_404(Schedule, id=schedule_id)
    
    # سيتم تطوير منطق تصدير PDF لاحقاً
    messages.info(request, 'سيتم تطوير ميزة تصدير PDF قريباً')
    return redirect('schedule_detail', schedule_id=schedule_id)

@login_required
def schedule_preferences(request):
    """تفضيلات الجداول للمستخدم"""
    preferences, created = UserSchedulePreference.objects.get_or_create(
        user=request.user
    )
    
    if request.method == 'POST':
        try:
            preferences.default_view = request.POST.get('default_view', 'weekly')
            preferences.show_room_numbers = request.POST.get('show_room_numbers') == 'on'
            preferences.show_teacher_names = request.POST.get('show_teacher_names') == 'on'
            preferences.show_break_times = request.POST.get('show_break_times') == 'on'
            preferences.email_notifications = request.POST.get('email_notifications') == 'on'
            preferences.schedule_reminders = request.POST.get('schedule_reminders') == 'on'
            preferences.reminder_minutes = int(request.POST.get('reminder_minutes', 15))
            preferences.save()
            
            messages.success(request, 'تم حفظ التفضيلات بنجاح')
        except Exception as e:
            messages.error(request, f'حدث خطأ أثناء حفظ التفضيلات: {str(e)}')
        
        return redirect('schedule_preferences')
    
    context = {
        'preferences': preferences,
    }
    
    return render(request, 'attendance/schedules/schedule_preferences.html', context)

# وظائف إضافية للجداول (ستتم إضافتها لاحقاً)
@login_required
def edit_schedule(request, schedule_id):
    """تعديل الجدول الدراسي"""
    messages.info(request, 'سيتم تطوير ميزة تعديل الجدول قريباً')
    return redirect('schedule_detail', schedule_id=schedule_id)

@login_required
def delete_schedule(request, schedule_id):
    """حذف الجدول الدراسي"""
    messages.info(request, 'سيتم تطوير ميزة حذف الجدول قريباً')
    return redirect('schedule_list')

@login_required
def copy_schedule(request, schedule_id):
    """نسخ الجدول الدراسي"""
    messages.info(request, 'سيتم تطوير ميزة نسخ الجدول قريباً')
    return redirect('schedule_detail', schedule_id=schedule_id)

@login_required
def schedule_slots(request, schedule_id):
    """إدارة حصص الجدول"""
    return redirect('schedule_detail', schedule_id=schedule_id)

@login_required
def edit_schedule_slot(request, slot_id):
    """تعديل حصة في الجدول"""
    messages.info(request, 'سيتم تطوير ميزة تعديل الحصة قريباً')
    slot = get_object_or_404(ScheduleSlot, id=slot_id)
    return redirect('schedule_detail', schedule_id=slot.schedule.id)

@login_required
def delete_schedule_slot(request, slot_id):
    """حذف حصة من الجدول"""
    slot = get_object_or_404(ScheduleSlot, id=slot_id)
    schedule_id = slot.schedule.id
    slot.delete()
    messages.success(request, 'تم حذف الحصة بنجاح')
    return redirect('schedule_detail', schedule_id=schedule_id)

@login_required
def create_time_slot(request):
    """إنشاء فترة زمنية جديدة"""
    return redirect('time_slot_list')

@login_required
def edit_time_slot(request, slot_id):
    """تعديل فترة زمنية"""
    messages.info(request, 'سيتم تطوير ميزة تعديل الفترة الزمنية قريباً')
    return redirect('time_slot_list')

@login_required
def delete_time_slot(request, slot_id):
    """حذف فترة زمنية"""
    time_slot = get_object_or_404(TimeSlot, id=slot_id)
    time_slot.delete()
    messages.success(request, 'تم حذف الفترة الزمنية بنجاح')
    return redirect('time_slot_list')

@login_required
def classroom_schedule(request, classroom_id):
    """جدول الفصل الدراسي"""
    messages.info(request, 'سيتم تطوير ميزة جدول الفصل قريباً')
    return redirect('schedule_list')

@login_required
def get_schedule_conflicts(request, schedule_id):
    """جلب تضاربات الجدول"""
    return JsonResponse({'conflicts': []})

@login_required
def update_schedule_slot_ajax(request):
    """تحديث حصة عبر AJAX"""
    return JsonResponse({'success': False, 'message': 'سيتم تطوير هذه الميزة قريباً'})

@login_required
def export_schedule_excel(request, schedule_id):
    """تصدير الجدول إلى Excel"""
    messages.info(request, 'سيتم تطوير ميزة تصدير Excel قريباً')
    return redirect('schedule_detail', schedule_id=schedule_id)

@login_required
def export_my_schedule_pdf(request):
    """تصدير جدولي الشخصي إلى PDF"""
    messages.info(request, 'سيتم تطوير ميزة تصدير الجدول الشخصي قريباً')
    return redirect('my_schedule')

@login_required
def schedule_template_list(request):
    """قائمة قوالب الجداول"""
    messages.info(request, 'سيتم تطوير ميزة قوالب الجداول قريباً')
    return redirect('schedule_list')

@login_required
def create_schedule_template(request):
    """إنشاء قالب جدول جديد"""
    messages.info(request, 'سيتم تطوير ميزة إنشاء قوالب الجداول قريباً')
    return redirect('schedule_list')

@login_required
def apply_schedule_template(request, template_id):
    """تطبيق قالب جدول"""
    messages.info(request, 'سيتم تطوير ميزة تطبيق قوالب الجداول قريباً')
    return redirect('schedule_list')



# ==================== نظام الإنذار المبكر ====================

@login_required
def early_warning_dashboard(request):
    """لوحة تحكم نظام الإنذار المبكر"""
    if request.user.role not in ['admin', 'manager', 'teacher']:
        messages.error(request, 'ليس لديك صلاحية للوصول إلى هذه الصفحة.')
        return redirect('dashboard')
    
    try:
        ews = EarlyWarningSystem()
        
        # جلب الطلاب المعرضين للخطر
        at_risk_students = ews.get_at_risk_students(limit=50)
        
        # إحصائيات عامة
        total_students = Student.objects.filter(is_active=True).count()
        critical_count = len([s for s in at_risk_students if s['priority'] == 'critical'])
        high_count = len([s for s in at_risk_students if s['priority'] == 'high'])
        medium_count = len([s for s in at_risk_students if s['priority'] == 'medium'])
        
        # تجميع البيانات حسب الفصول
        classroom_stats = {}
        for student_analysis in at_risk_students:
            classroom = student_analysis['student'].classroom
            if classroom.name not in classroom_stats:
                classroom_stats[classroom.name] = {
                    'total': 0,
                    'critical': 0,
                    'high': 0,
                    'medium': 0
                }
            classroom_stats[classroom.name]['total'] += 1
            classroom_stats[classroom.name][student_analysis['priority']] += 1
        
        context = {
            'at_risk_students': at_risk_students,
            'total_students': total_students,
            'total_at_risk': len(at_risk_students),
            'critical_count': critical_count,
            'high_count': high_count,
            'medium_count': medium_count,
            'classroom_stats': classroom_stats,
            'warning_levels': EarlyWarningSystem.WARNING_LEVELS,
        }
        
        return render(request, 'attendance/early_warning/dashboard.html', context)
        
    except Exception as e:
        messages.error(request, f'حدث خطأ في تحميل لوحة التحكم: {str(e)}')
        return redirect('dashboard')

@login_required
def student_risk_analysis(request, student_id):
    """تحليل مفصل لمخاطر طالب معين"""
    if request.user.role not in ['admin', 'manager', 'teacher', 'parent']:
        messages.error(request, 'ليس لديك صلاحية للوصول إلى هذه الصفحة.')
        return redirect('dashboard')
    
    try:
        student = get_object_or_404(Student, id=student_id, is_active=True)
        
        # التحقق من الصلاحيات
        if request.user.role == 'teacher':
            # المعلم يمكنه رؤية طلاب فصوله فقط
            teacher_classrooms = request.user.teacher_profile.classrooms.all()
            if student.classroom not in teacher_classrooms:
                messages.error(request, 'ليس لديك صلاحية لعرض بيانات هذا الطالب.')
                return redirect('early_warning_dashboard')
        elif request.user.role == 'parent':
            # ولي الأمر يمكنه رؤية أطفاله فقط
            if student.parent != request.user:
                messages.error(request, 'ليس لديك صلاحية لعرض بيانات هذا الطالب.')
                return redirect('dashboard')
        
        ews = EarlyWarningSystem()
        analysis = ews.analyze_student_risk(student)
        
        if not analysis:
            messages.error(request, 'لا يمكن تحليل بيانات هذا الطالب.')
            return redirect('early_warning_dashboard')
        
        # جلب سجل الحضور الأخير
        recent_records = AttendanceRecord.objects.filter(
            student=student,
            session__date__gte=timezone.now().date() - timedelta(days=30)
        ).select_related('session').order_by('-session__date')[:20]
        
        context = {
            'student': student,
            'analysis': analysis,
            'recent_records': recent_records,
            'warning_levels': EarlyWarningSystem.WARNING_LEVELS,
        }
        
        return render(request, 'attendance/early_warning/student_analysis.html', context)
        
    except Exception as e:
        messages.error(request, f'حدث خطأ في تحليل بيانات الطالب: {str(e)}')
        return redirect('early_warning_dashboard')

@login_required
def send_warning_notification(request, student_id):
    """إرسال تنبيه لطالب معين"""
    if request.user.role not in ['admin', 'manager', 'teacher']:
        messages.error(request, 'ليس لديك صلاحية لإرسال التنبيهات.')
        return redirect('dashboard')
    
    try:
        student = get_object_or_404(Student, id=student_id, is_active=True)
        
        ews = EarlyWarningSystem()
        analysis = ews.analyze_student_risk(student)
        
        if analysis and ews.send_warning_notifications(analysis):
            messages.success(request, f'تم إرسال التنبيه بنجاح للطالب {student.user.get_full_name()}')
        else:
            messages.error(request, 'فشل في إرسال التنبيه.')
        
        return redirect('student_risk_analysis', student_id=student_id)
        
    except Exception as e:
        messages.error(request, f'حدث خطأ في إرسال التنبيه: {str(e)}')
        return redirect('early_warning_dashboard')

@login_required
def run_warning_check(request):
    """تشغيل فحص التحذيرات يدوياً"""
    if request.user.role not in ['admin', 'manager']:
        messages.error(request, 'ليس لديك صلاحية لتشغيل فحص التحذيرات.')
        return redirect('dashboard')
    
    try:
        notifications_sent = run_daily_warning_check()
        messages.success(request, f'تم تشغيل فحص التحذيرات بنجاح. تم إرسال {notifications_sent} تنبيه.')
        
    except Exception as e:
        messages.error(request, f'حدث خطأ في تشغيل فحص التحذيرات: {str(e)}')
    
    return redirect('early_warning_dashboard')

@login_required
def early_warning_api(request):
    """API لجلب بيانات الإنذار المبكر"""
    if request.user.role not in ['admin', 'manager', 'teacher']:
        return JsonResponse({'error': 'غير مصرح'}, status=403)
    
    try:
        ews = EarlyWarningSystem()
        
        # جلب الطلاب المعرضين للخطر
        at_risk_students = ews.get_at_risk_students(limit=20)
        
        # تحويل البيانات لـ JSON
        students_data = []
        for analysis in at_risk_students:
            student = analysis['student']
            students_data.append({
                'id': student.id,
                'name': student.user.get_full_name(),
                'student_id': student.student_id,
                'classroom': student.classroom.name,
                'monthly_rate': analysis['monthly_rate'],
                'weekly_rate': analysis['weekly_rate'],
                'warning_level': analysis['warning_level'],
                'priority': analysis['priority'],
                'consecutive_absences': analysis['consecutive_absences'],
                'trend': analysis['trend'],
                'last_attendance': analysis['last_attendance'].strftime('%Y-%m-%d') if analysis['last_attendance'] else None,
                'recommendations': analysis['recommendations']
            })
        
        return JsonResponse({
            'success': True,
            'students': students_data,
            'total_count': len(students_data)
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)

@login_required
def classroom_warning_stats(request, classroom_id):
    """إحصائيات التحذيرات لفصل معين"""
    if request.user.role not in ['admin', 'manager', 'teacher']:
        return JsonResponse({'error': 'غير مصرح'}, status=403)
    
    try:
        classroom = get_object_or_404(Classroom, id=classroom_id)
        
        # التحقق من صلاحية المعلم
        if request.user.role == 'teacher':
            teacher_classrooms = request.user.teacher_profile.classrooms.all()
            if classroom not in teacher_classrooms:
                return JsonResponse({'error': 'غير مصرح لهذا الفصل'}, status=403)
        
        ews = EarlyWarningSystem()
        at_risk_students = ews.get_at_risk_students(classroom=classroom)
        
        # تجميع الإحصائيات
        stats = {
            'total_students': classroom.students.filter(is_active=True).count(),
            'at_risk_count': len(at_risk_students),
            'critical_count': len([s for s in at_risk_students if s['priority'] == 'critical']),
            'high_count': len([s for s in at_risk_students if s['priority'] == 'high']),
            'medium_count': len([s for s in at_risk_students if s['priority'] == 'medium']),
            'average_attendance': sum([s['monthly_rate'] for s in at_risk_students]) / len(at_risk_students) if at_risk_students else 100
        }
        
        return JsonResponse({
            'success': True,
            'classroom': classroom.name,
            'stats': stats
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)



@login_required
def export_schedules(request):
    """تصدير الجداول الدراسية إلى Excel"""
    from django.http import HttpResponse
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    
    try:
        # إنشاء ملف Excel جديد
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "الجداول الدراسية"
        
        # تنسيق الخلايا
        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
        
        # العناوين
        headers = [
            'اليوم', 'وقت البداية', 'وقت النهاية', 'المادة', 
            'المعلم', 'الفصل', 'الصف', 'عدد الطلاب'
        ]
        
        # كتابة العناوين
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal='center', vertical='center')
            cell.border = border
        
        # جلب البيانات
        from .models import ScheduleSlot
        schedule_slots = ScheduleSlot.objects.select_related(
            'teacher__user', 'subject', 'classroom', 'time_slot'
        ).filter(
            teacher__isnull=False,
            subject__isnull=False,
            classroom__isnull=False
        ).order_by('day_of_week', 'time_slot__start_time')
        
        # ترجمة أيام الأسبوع
        days_translation = {
            1: 'الأحد',
            2: 'الاثنين', 
            3: 'الثلاثاء',
            4: 'الأربعاء',
            5: 'الخميس',
            6: 'الجمعة',
            7: 'السبت'
        }
        
        # كتابة البيانات
        row = 2
        for slot in schedule_slots:
            # عدد الطلاب في الفصل
            student_count = slot.classroom.students.count() if hasattr(slot.classroom, 'students') else 0
            
            data = [
                days_translation.get(slot.day_of_week, str(slot.day_of_week)),
                slot.time_slot.start_time.strftime('%H:%M') if slot.time_slot and slot.time_slot.start_time else '',
                slot.time_slot.end_time.strftime('%H:%M') if slot.time_slot and slot.time_slot.end_time else '',
                slot.subject.name if slot.subject else '',
                slot.teacher.user.get_full_name() if slot.teacher else '',
                slot.classroom.name if slot.classroom else '',
                slot.classroom.grade.name if slot.classroom and hasattr(slot.classroom, 'grade') else '',
                student_count
            ]
            
            for col, value in enumerate(data, 1):
                cell = ws.cell(row=row, column=col, value=value)
                cell.border = border
                cell.alignment = Alignment(horizontal='center', vertical='center')
            
            row += 1
        
        # تعديل عرض الأعمدة
        for col in range(1, len(headers) + 1):
            ws.column_dimensions[get_column_letter(col)].width = 15
        
        # إعداد الاستجابة
        response = HttpResponse(
            content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        response['Content-Disposition'] = 'attachment; filename="الجداول_الدراسية.xlsx"'
        
        # حفظ الملف
        wb.save(response)
        return response
        
    except Exception as e:
        from django.contrib import messages
        messages.error(request, f'خطأ في تصدير الجداول: {str(e)}')
        return redirect('schedule_list')



@login_required
def teacher_edit(request, teacher_id):
    """تعديل بيانات المعلم"""
    if request.user.role not in ['admin', 'manager']:
        messages.error(request, 'ليس لديك صلاحية لتعديل بيانات المعلمين')
        return redirect('teacher_list')
    
    teacher = get_object_or_404(Teacher, id=teacher_id)
    
    if request.method == 'POST':
        try:
            # تحديث بيانات المستخدم
            user = teacher.user
            user.first_name = request.POST.get('first_name', '').strip()
            user.last_name = request.POST.get('last_name', '').strip()
            user.email = request.POST.get('email', '').strip()
            user.is_active = request.POST.get('is_active') == 'on'
            
            # تحديث كلمة المرور إذا تم إدخالها
            new_password = request.POST.get('password', '').strip()
            if new_password:
                user.set_password(new_password)
            
            user.save()
            
            # تحديث بيانات المعلم
            teacher.employee_id = request.POST.get('employee_id', '').strip()
            teacher.qualification = request.POST.get('qualification', '').strip()
            teacher.hire_date = request.POST.get('hire_date') or None
            teacher.salary = request.POST.get('salary') or None
            teacher.save()
            
            # تحديث المواد
            subject_ids = request.POST.getlist('subjects')
            teacher.subjects.set(Subject.objects.filter(id__in=subject_ids))
            
            # تحديث الفصول
            classroom_ids = request.POST.getlist('classrooms')
            teacher.classrooms.set(Classroom.objects.filter(id__in=classroom_ids))
            
            messages.success(request, f'تم تحديث بيانات المعلم {user.get_full_name()} بنجاح')
            return redirect('teacher_list')
            
        except Exception as e:
            messages.error(request, f'حدث خطأ أثناء تحديث البيانات: {str(e)}')
    
    # جلب البيانات للعرض
    subjects = Subject.objects.all()
    classrooms = Classroom.objects.all()
    
    context = {
        'page_title': f'تعديل المعلم - {teacher.user.get_full_name()}',
        'teacher': teacher,
        'subjects': subjects,
        'classrooms': classrooms,
    }
    
    return render(request, 'attendance/teacher_edit.html', context)


@login_required
def teacher_detail(request, teacher_id):
    """تفاصيل المعلم"""
    if request.user.role not in ['admin', 'manager', 'teacher']:
        messages.error(request, 'ليس لديك صلاحية لعرض تفاصيل المعلمين')
        return redirect('dashboard')
    
    teacher = get_object_or_404(Teacher, id=teacher_id)
    
    # التحقق من الصلاحيات - المعلم يمكنه رؤية تفاصيله فقط
    if request.user.role == 'teacher' and request.user.teacher != teacher:
        messages.error(request, 'يمكنك عرض تفاصيلك الشخصية فقط')
        return redirect('dashboard')
    
    # إحصائيات المعلم
    today = timezone.now().date()
    last_30_days = today - timedelta(days=30)
    
    # جلسات الحضور
    teacher_sessions = AttendanceSession.objects.filter(
        teacher=teacher,
        date__gte=last_30_days
    ).order_by('-date', '-start_time')
    
    total_sessions = teacher_sessions.count()
    
    # سجلات الحضور للطلاب في جلسات المعلم
    teacher_records = AttendanceRecord.objects.filter(
        session__teacher=teacher,
        session__date__gte=last_30_days
    )
    
    total_records = teacher_records.count()
    present_records = teacher_records.filter(status='present').count()
    absent_records = teacher_records.filter(status='absent').count()
    late_records = teacher_records.filter(status='late').count()
    
    attendance_rate = (present_records / total_records * 100) if total_records > 0 else 0
    
    # إحصائيات حسب المادة
    subject_stats = []
    for subject in teacher.subjects.all():
        subject_records = teacher_records.filter(session__subject=subject)
        subject_total = subject_records.count()
        subject_present = subject_records.filter(status='present').count()
        subject_rate = (subject_present / subject_total * 100) if subject_total > 0 else 0
        
        subject_stats.append({
            'subject': subject,
            'total_records': subject_total,
            'present_records': subject_present,
            'attendance_rate': round(subject_rate, 2)
        })
    
    # إحصائيات حسب الفصل
    classroom_stats = []
    for classroom in teacher.classrooms.all():
        classroom_records = teacher_records.filter(session__classroom=classroom)
        classroom_total = classroom_records.count()
        classroom_present = classroom_records.filter(status='present').count()
        classroom_rate = (classroom_present / classroom_total * 100) if classroom_total > 0 else 0
        
        classroom_stats.append({
            'classroom': classroom,
            'total_records': classroom_total,
            'present_records': classroom_present,
            'attendance_rate': round(classroom_rate, 2)
        })
    
    # آخر 10 جلسات
    recent_sessions = teacher_sessions[:10]
    
    context = {
        'page_title': f'تفاصيل المعلم - {teacher.user.get_full_name()}',
        'teacher': teacher,
        'total_sessions': total_sessions,
        'total_records': total_records,
        'present_records': present_records,
        'absent_records': absent_records,
        'late_records': late_records,
        'attendance_rate': round(attendance_rate, 2),
        'subject_stats': subject_stats,
        'classroom_stats': classroom_stats,
        'recent_sessions': recent_sessions,
    }
    
    return render(request, 'attendance/teacher_detail.html', context)




# ===== دوال إدارة الصلاحيات =====

@login_required
def permissions_dashboard(request):
    """لوحة تحكم الصلاحيات"""
    # إحصائيات عامة
    total_users = User.objects.count()
    total_permissions = 32  # عدد الصلاحيات الافتراضية
    total_roles = 5  # عدد الأدوار الافتراضية
    active_user_permissions = total_users  # جميع المستخدمين لديهم صلاحيات
    
    # أحدث العمليات (مؤقت)
    recent_logs = [
        {
            'timestamp': timezone.now(),
            'action': 'grant',
            'permission': {'name': 'عرض الطلاب'},
            'user': {'first_name': 'أحمد', 'last_name': 'محمد'},
            'performed_by': {'first_name': 'مدير', 'last_name': 'النظام'},
            'get_action_display': lambda: 'منح'
        },
        {
            'timestamp': timezone.now(),
            'action': 'revoke',
            'permission': {'name': 'حذف المستخدمين'},
            'user': {'first_name': 'سارة', 'last_name': 'أحمد'},
            'performed_by': {'first_name': 'مدير', 'last_name': 'النظام'},
            'get_action_display': lambda: 'إلغاء'
        }
    ]
    
    # المستخدمون حسب الأدوار
    users_by_role = {}
    for choice in User.ROLE_CHOICES:
        role_code = choice[0]
        role_name = choice[1]
        count = User.objects.filter(role=role_code).count()
        users_by_role[role_name] = count
    
    context = {
        'total_users': total_users,
        'total_permissions': total_permissions,
        'total_roles': total_roles,
        'active_user_permissions': active_user_permissions,
        'recent_logs': recent_logs,
        'users_by_role': users_by_role,
    }
    
    return render(request, 'attendance/permissions/dashboard.html', context)


@login_required
def users_permissions_list(request):
    """قائمة المستخدمين مع صلاحياتهم"""
    users = User.objects.all().order_by('first_name', 'last_name')
    
    # البحث والتصفية
    search = request.GET.get('search', '')
    role = request.GET.get('role', '')
    
    if search:
        users = users.filter(
            Q(first_name__icontains=search) |
            Q(last_name__icontains=search) |
            Q(username__icontains=search) |
            Q(email__icontains=search)
        )
    
    if role:
        users = users.filter(role=role)
    
    # التصفح
    from django.core.paginator import Paginator
    paginator = Paginator(users, 20)
    page_number = request.GET.get('page')
    users = paginator.get_page(page_number)
    
    context = {
        'users': users,
        'role_choices': User.ROLE_CHOICES,
        'search': search,
        'selected_role': role,
    }
    
    return render(request, 'attendance/permissions/users_permissions_list.html', context)


@login_required
def user_permissions_detail(request, user_id):
    """تفاصيل صلاحيات المستخدم"""
    user = get_object_or_404(User, id=user_id)
    
    # الصلاحيات الافتراضية حسب الدور
    default_permissions = {
        'admin': [
            'عرض المستخدمين', 'إضافة مستخدم', 'تعديل المستخدمين', 'حذف المستخدمين',
            'عرض الطلاب', 'إضافة طالب', 'تعديل الطلاب', 'حذف الطلاب',
            'عرض المعلمين', 'إضافة معلم', 'تعديل المعلمين', 'حذف المعلمين',
            'عرض الحضور', 'تسجيل الحضور', 'تعديل الحضور', 'حذف الحضور',
            'عرض الجداول', 'إضافة جدول', 'تعديل الجداول', 'حذف الجداول',
            'عرض التقارير', 'إنشاء التقارير', 'تصدير التقارير', 'تقارير الإدارة',
            'عرض الإعدادات', 'تعديل الإعدادات', 'إدارة الفترات الزمنية',
            'عرض الصلاحيات', 'منح الصلاحيات', 'إلغاء الصلاحيات', 'إدارة الأدوار',
            'عرض الإنذار المبكر', 'إدارة الإنذار المبكر'
        ],
        'manager': [
            'عرض المستخدمين', 'إضافة مستخدم', 'تعديل المستخدمين',
            'عرض الطلاب', 'إضافة طالب', 'تعديل الطلاب',
            'عرض المعلمين', 'إضافة معلم', 'تعديل المعلمين',
            'عرض الحضور', 'تسجيل الحضور', 'تعديل الحضور',
            'عرض الجداول', 'إضافة جدول', 'تعديل الجداول',
            'عرض التقارير', 'إنشاء التقارير', 'تصدير التقارير', 'تقارير الإدارة',
            'عرض الإعدادات', 'تعديل الإعدادات',
            'عرض الإنذار المبكر', 'إدارة الإنذار المبكر'
        ],
        'teacher': [
            'عرض الطلاب',
            'عرض الحضور', 'تسجيل الحضور',
            'عرض الجداول',
            'عرض التقارير',
            'عرض الإنذار المبكر'
        ],
        'student': [
            'عرض الحضور',
            'عرض الجداول'
        ],
        'parent': [
            'عرض الطلاب',
            'عرض الحضور',
            'عرض الجداول',
            'عرض التقارير'
        ]
    }
    
    user_permissions = default_permissions.get(user.role, [])
    
    # سجل الصلاحيات (مؤقت)
    permission_logs = [
        {
            'timestamp': timezone.now(),
            'action': 'grant',
            'permission': {'name': 'عرض الطلاب'},
            'performed_by': {'first_name': 'مدير', 'last_name': 'النظام'},
            'reason': 'صلاحية افتراضية للدور',
            'get_action_display': lambda: 'منح'
        }
    ]
    
    context = {
        'user': user,
        'user_permissions': user_permissions,
        'permission_logs': permission_logs,
        'permissions_count': len(user_permissions),
    }
    
    return render(request, 'attendance/permissions/user_permissions_detail.html', context)

