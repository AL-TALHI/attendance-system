/**
 * ملف JavaScript للبحث والتصفية المتقدمة
 * نظام إدارة الحضور والغياب
 */

class AdvancedSearch {
    constructor(options = {}) {
        this.searchInput = options.searchInput || '#search';
        this.classroomFilter = options.classroomFilter || '#classroom';
        this.statusFilter = options.statusFilter || '#status';
        this.resultsContainer = options.resultsContainer || '#results-container';
        this.statsContainer = options.statsContainer || '#stats-container';
        this.loadingIndicator = options.loadingIndicator || '#loading-indicator';
        
        this.searchUrl = options.searchUrl || '/api/search-students/';
        this.filterUrl = options.filterUrl || '/api/filter-students/';
        
        this.debounceDelay = options.debounceDelay || 300;
        this.minSearchLength = options.minSearchLength || 2;
        
        this.searchTimeout = null;
        this.currentRequest = null;
        
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.loadSavedFilters();
        this.updateStats();
    }
    
    bindEvents() {
        // البحث الفوري
        $(this.searchInput).on('input', (e) => {
            this.handleSearch(e.target.value);
        });
        
        // تصفية الفصول
        $(this.classroomFilter).on('change', (e) => {
            this.handleFilter();
            this.saveFilters();
        });
        
        // تصفية الحالة
        $(this.statusFilter).on('change', (e) => {
            this.handleFilter();
            this.saveFilters();
        });
        
        // مسح البحث
        $('#clear-search').on('click', () => {
            this.clearSearch();
        });
        
        // حفظ البحث
        $('#save-search').on('click', () => {
            this.saveCurrentSearch();
        });
        
        // تحميل البحث المحفوظ
        $('#load-saved-search').on('change', (e) => {
            this.loadSavedSearch(e.target.value);
        });
    }
    
    handleSearch(query) {
        // إلغاء البحث السابق
        if (this.searchTimeout) {
            clearTimeout(this.searchTimeout);
        }
        
        // إلغاء الطلب السابق
        if (this.currentRequest) {
            this.currentRequest.abort();
        }
        
        // البحث الفوري مع تأخير
        this.searchTimeout = setTimeout(() => {
            if (query.length >= this.minSearchLength || query.length === 0) {
                this.performSearch(query);
            }
        }, this.debounceDelay);
    }
    
    performSearch(query) {
        this.showLoading();
        
        const params = {
            q: query,
            classroom: $(this.classroomFilter).val(),
            status: $(this.statusFilter).val()
        };
        
        this.currentRequest = $.ajax({
            url: this.searchUrl,
            method: 'GET',
            data: params,
            success: (data) => {
                this.displayResults(data.results);
                this.updateResultsStats(data);
                this.hideLoading();
            },
            error: (xhr, status, error) => {
                if (status !== 'abort') {
                    console.error('خطأ في البحث:', error);
                    showError('خطأ في البحث', 'حدث خطأ أثناء البحث. يرجى المحاولة مرة أخرى.');
                }
                this.hideLoading();
            }
        });
    }
    
    handleFilter() {
        this.showLoading();
        
        const params = {
            classroom: $(this.classroomFilter).val(),
            status: $(this.statusFilter).val(),
            has_parent: $('#has-parent-filter').val()
        };
        
        $.ajax({
            url: this.filterUrl,
            method: 'GET',
            data: params,
            success: (data) => {
                this.updateStats(data);
                // إعادة تشغيل البحث مع التصفية الجديدة
                const currentQuery = $(this.searchInput).val();
                if (currentQuery) {
                    this.performSearch(currentQuery);
                } else {
                    // إذا لم يكن هناك بحث، اعرض جميع النتائج المفلترة
                    this.performSearch('');
                }
                this.hideLoading();
            },
            error: (xhr, status, error) => {
                console.error('خطأ في التصفية:', error);
                showError('خطأ في التصفية', 'حدث خطأ أثناء التصفية. يرجى المحاولة مرة أخرى.');
                this.hideLoading();
            }
        });
    }
    
    displayResults(results) {
        const container = $(this.resultsContainer);
        
        if (results.length === 0) {
            container.html(`
                <div class="text-center py-5">
                    <i class="fas fa-search fa-4x text-muted mb-3"></i>
                    <h5 class="text-muted">لا توجد نتائج</h5>
                    <p class="text-muted">لم يتم العثور على أي طلاب بالمعايير المحددة</p>
                </div>
            `);
            return;
        }
        
        let html = `
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>الاسم</th>
                            <th>رقم الطالب</th>
                            <th>الفصل</th>
                            <th>ولي الأمر</th>
                            <th>تاريخ التسجيل</th>
                            <th>الحالة</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
        `;
        
        results.forEach(student => {
            const statusBadge = student.is_active 
                ? '<span class="badge bg-success">نشط</span>'
                : '<span class="badge bg-danger">غير نشط</span>';
            
            html += `
                <tr class="fade-in">
                    <td>
                        <div class="d-flex align-items-center">
                            <div class="avatar-sm bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-2">
                                ${student.name.charAt(0)}
                            </div>
                            <div>
                                <strong>${student.name}</strong>
                                <br>
                                <small class="text-muted">${student.email}</small>
                            </div>
                        </div>
                    </td>
                    <td>
                        <span class="badge bg-info">${student.student_id}</span>
                    </td>
                    <td>
                        <strong>${student.classroom}</strong>
                        <br>
                        <small class="text-muted">${student.grade}</small>
                    </td>
                    <td>
                        ${student.parent ? `
                            ${student.parent}
                            <br>
                            <small class="text-muted">${student.parent_phone}</small>
                        ` : '<span class="text-muted">غير محدد</span>'}
                    </td>
                    <td>${student.enrollment_date}</td>
                    <td>${statusBadge}</td>
                    <td>
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-sm btn-outline-primary" 
                                    data-bs-toggle="tooltip" title="عرض التفاصيل">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-warning" 
                                    data-bs-toggle="tooltip" title="تعديل">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-info" 
                                    data-bs-toggle="tooltip" title="تقرير الحضور">
                                <i class="fas fa-chart-line"></i>
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-danger btn-delete" 
                                    data-bs-toggle="tooltip" title="حذف الطالب"
                                    data-item-name="الطالب ${student.name}"
                                    data-url="/students/delete/${student.id}/">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        });
        
        html += `
                    </tbody>
                </table>
            </div>
        `;
        
        container.html(html);
        
        // تفعيل tooltips
        $('[data-bs-toggle="tooltip"]').tooltip();
    }
    
    updateResultsStats(data) {
        $('#results-count').text(data.showing_count);
        $('#total-count').text(data.total_count);
        
        if (data.showing_count < data.total_count) {
            $('#showing-partial').show();
        } else {
            $('#showing-partial').hide();
        }
    }
    
    updateStats(data = null) {
        if (!data) return;
        
        $('#total-students-stat').text(data.total_count);
        $('#active-students-stat').text(data.active_count);
        $('#inactive-students-stat').text(data.inactive_count);
        
        // تحديث إحصائيات الفصول
        if (data.classroom_stats) {
            let classroomHtml = '';
            data.classroom_stats.forEach(classroom => {
                classroomHtml += `
                    <div class="col-md-4 mb-2">
                        <div class="card card-body py-2">
                            <div class="d-flex justify-content-between">
                                <span>${classroom.classroom__name}</span>
                                <span class="badge bg-primary">${classroom.count}</span>
                            </div>
                        </div>
                    </div>
                `;
            });
            $('#classroom-stats').html(classroomHtml);
        }
    }
    
    showLoading() {
        $(this.loadingIndicator).show();
        $(this.resultsContainer).addClass('opacity-50');
    }
    
    hideLoading() {
        $(this.loadingIndicator).hide();
        $(this.resultsContainer).removeClass('opacity-50');
    }
    
    clearSearch() {
        $(this.searchInput).val('');
        $(this.classroomFilter).val('');
        $(this.statusFilter).val('');
        $('#has-parent-filter').val('');
        
        this.performSearch('');
        this.handleFilter();
        this.clearSavedFilters();
        
        showSuccess('تم مسح البحث', 'تم مسح جميع معايير البحث والتصفية');
    }
    
    saveCurrentSearch() {
        const searchData = {
            query: $(this.searchInput).val(),
            classroom: $(this.classroomFilter).val(),
            status: $(this.statusFilter).val(),
            timestamp: new Date().toISOString(),
            name: prompt('اسم البحث المحفوظ:') || `بحث ${new Date().toLocaleDateString()}`
        };
        
        if (searchData.name) {
            let savedSearches = JSON.parse(localStorage.getItem('savedSearches') || '[]');
            savedSearches.push(searchData);
            
            // الاحتفاظ بآخر 10 عمليات بحث فقط
            if (savedSearches.length > 10) {
                savedSearches = savedSearches.slice(-10);
            }
            
            localStorage.setItem('savedSearches', JSON.stringify(savedSearches));
            this.updateSavedSearchesList();
            
            showSuccess('تم حفظ البحث', `تم حفظ البحث باسم "${searchData.name}"`);
        }
    }
    
    loadSavedSearch(index) {
        const savedSearches = JSON.parse(localStorage.getItem('savedSearches') || '[]');
        if (savedSearches[index]) {
            const searchData = savedSearches[index];
            
            $(this.searchInput).val(searchData.query);
            $(this.classroomFilter).val(searchData.classroom);
            $(this.statusFilter).val(searchData.status);
            
            this.performSearch(searchData.query);
            this.handleFilter();
            
            showInfo('تم تحميل البحث', `تم تحميل البحث المحفوظ "${searchData.name}"`);
        }
    }
    
    updateSavedSearchesList() {
        const savedSearches = JSON.parse(localStorage.getItem('savedSearches') || '[]');
        const select = $('#load-saved-search');
        
        select.empty().append('<option value="">اختر بحث محفوظ...</option>');
        
        savedSearches.forEach((search, index) => {
            select.append(`<option value="${index}">${search.name}</option>`);
        });
    }
    
    saveFilters() {
        const filters = {
            classroom: $(this.classroomFilter).val(),
            status: $(this.statusFilter).val()
        };
        
        localStorage.setItem('studentFilters', JSON.stringify(filters));
    }
    
    loadSavedFilters() {
        const savedFilters = localStorage.getItem('studentFilters');
        if (savedFilters) {
            const filters = JSON.parse(savedFilters);
            $(this.classroomFilter).val(filters.classroom || '');
            $(this.statusFilter).val(filters.status || '');
        }
        
        this.updateSavedSearchesList();
    }
    
    clearSavedFilters() {
        localStorage.removeItem('studentFilters');
    }
}

// تصدير الكلاس للاستخدام العام
window.AdvancedSearch = AdvancedSearch;

