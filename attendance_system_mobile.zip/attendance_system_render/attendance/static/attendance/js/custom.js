/**
 * ملف JavaScript مخصص لنظام إدارة الحضور والغياب
 * يحتوي على الرسائل التفاعلية والوظائف المساعدة
 */

// إعدادات SweetAlert2 الافتراضية
const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
});

// إعدادات الرسائل باللغة العربية
const arabicConfig = {
    confirmButtonText: 'تأكيد',
    cancelButtonText: 'إلغاء',
    denyButtonText: 'رفض',
    validationMessage: 'هذا الحقل مطلوب!'
};

/**
 * عرض رسالة نجاح
 */
function showSuccess(title, text = '') {
    Toast.fire({
        icon: 'success',
        title: title,
        text: text
    });
}

/**
 * عرض رسالة خطأ
 */
function showError(title, text = '') {
    Toast.fire({
        icon: 'error',
        title: title,
        text: text
    });
}

/**
 * عرض رسالة تحذير
 */
function showWarning(title, text = '') {
    Toast.fire({
        icon: 'warning',
        title: title,
        text: text
    });
}

/**
 * عرض رسالة معلومات
 */
function showInfo(title, text = '') {
    Toast.fire({
        icon: 'info',
        title: title,
        text: text
    });
}

/**
 * رسالة تأكيد الحذف
 */
function confirmDelete(title = 'هل أنت متأكد؟', text = 'لن تتمكن من التراجع عن هذا الإجراء!') {
    return Swal.fire({
        title: title,
        text: text,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'نعم، احذف!',
        cancelButtonText: 'إلغاء',
        reverseButtons: true
    });
}

/**
 * رسالة تأكيد عامة
 */
function confirmAction(title, text, confirmText = 'تأكيد') {
    return Swal.fire({
        title: title,
        text: text,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#6c757d',
        confirmButtonText: confirmText,
        cancelButtonText: 'إلغاء',
        reverseButtons: true
    });
}

/**
 * رسالة تحميل
 */
function showLoading(title = 'جاري التحميل...') {
    Swal.fire({
        title: title,
        allowOutsideClick: false,
        allowEscapeKey: false,
        showConfirmButton: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
}

/**
 * إخفاء رسالة التحميل
 */
function hideLoading() {
    Swal.close();
}

/**
 * رسالة إدخال نص
 */
function promptInput(title, inputPlaceholder, inputType = 'text') {
    return Swal.fire({
        title: title,
        input: inputType,
        inputPlaceholder: inputPlaceholder,
        showCancelButton: true,
        confirmButtonText: 'تأكيد',
        cancelButtonText: 'إلغاء',
        inputValidator: (value) => {
            if (!value) {
                return 'يرجى إدخال قيمة!'
            }
        }
    });
}

// معالجة رسائل Django Messages
document.addEventListener('DOMContentLoaded', function() {
    // تحويل رسائل Django إلى SweetAlert2
    const djangoMessages = document.querySelectorAll('.alert');
    djangoMessages.forEach(function(alert) {
        const messageText = alert.textContent.trim();
        const messageType = alert.classList.contains('alert-success') ? 'success' :
                           alert.classList.contains('alert-danger') ? 'error' :
                           alert.classList.contains('alert-warning') ? 'warning' : 'info';
        
        // عرض الرسالة باستخدام SweetAlert2
        Toast.fire({
            icon: messageType,
            title: messageText
        });
        
        // إخفاء الرسالة الأصلية
        alert.style.display = 'none';
    });
});

// معالجة أزرار الحذف
document.addEventListener('DOMContentLoaded', function() {
    // البحث عن جميع أزرار الحذف
    const deleteButtons = document.querySelectorAll('.btn-delete, [data-action="delete"]');
    
    deleteButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const itemName = this.getAttribute('data-item-name') || 'هذا العنصر';
            const deleteUrl = this.getAttribute('href') || this.getAttribute('data-url');
            
            confirmDelete(
                'حذف ' + itemName,
                'هل أنت متأكد من حذف ' + itemName + '؟ لن تتمكن من التراجع عن هذا الإجراء!'
            ).then((result) => {
                if (result.isConfirmed) {
                    showLoading('جاري الحذف...');
                    
                    // إذا كان هناك رابط، انتقل إليه
                    if (deleteUrl) {
                        window.location.href = deleteUrl;
                    } else {
                        // أو أرسل نموذج الحذف
                        const form = this.closest('form');
                        if (form) {
                            form.submit();
                        }
                    }
                }
            });
        });
    });
});

// معالجة النماذج مع رسائل التأكيد
document.addEventListener('DOMContentLoaded', function() {
    const formsWithConfirmation = document.querySelectorAll('[data-confirm]');
    
    formsWithConfirmation.forEach(function(form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const confirmMessage = this.getAttribute('data-confirm');
            const confirmTitle = this.getAttribute('data-confirm-title') || 'تأكيد الإجراء';
            
            confirmAction(confirmTitle, confirmMessage).then((result) => {
                if (result.isConfirmed) {
                    showLoading('جاري المعالجة...');
                    this.submit();
                }
            });
        });
    });
});

// معالجة الأزرار مع رسائل التأكيد
document.addEventListener('DOMContentLoaded', function() {
    const buttonsWithConfirmation = document.querySelectorAll('[data-confirm-action]');
    
    buttonsWithConfirmation.forEach(function(button) {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const confirmMessage = this.getAttribute('data-confirm-action');
            const confirmTitle = this.getAttribute('data-confirm-title') || 'تأكيد الإجراء';
            const actionUrl = this.getAttribute('href') || this.getAttribute('data-url');
            
            confirmAction(confirmTitle, confirmMessage).then((result) => {
                if (result.isConfirmed) {
                    showLoading('جاري المعالجة...');
                    
                    if (actionUrl) {
                        window.location.href = actionUrl;
                    }
                }
            });
        });
    });
});

// وظائف مساعدة للتفاعل مع النماذج
function submitFormWithLoading(formId, loadingMessage = 'جاري الحفظ...') {
    showLoading(loadingMessage);
    document.getElementById(formId).submit();
}

// وظيفة لعرض رسالة نجاح بعد العمليات
function showOperationSuccess(operation, itemName = '') {
    const messages = {
        'create': 'تم إنشاء ' + itemName + ' بنجاح!',
        'update': 'تم تحديث ' + itemName + ' بنجاح!',
        'delete': 'تم حذف ' + itemName + ' بنجاح!',
        'save': 'تم حفظ البيانات بنجاح!',
        'import': 'تم استيراد البيانات بنجاح!',
        'export': 'تم تصدير البيانات بنجاح!'
    };
    
    showSuccess(messages[operation] || 'تم تنفيذ العملية بنجاح!');
}

// تصدير الوظائف للاستخدام العام
window.showSuccess = showSuccess;
window.showError = showError;
window.showWarning = showWarning;
window.showInfo = showInfo;
window.confirmDelete = confirmDelete;
window.confirmAction = confirmAction;
window.showLoading = showLoading;
window.hideLoading = hideLoading;
window.promptInput = promptInput;
window.submitFormWithLoading = submitFormWithLoading;
window.showOperationSuccess = showOperationSuccess;

