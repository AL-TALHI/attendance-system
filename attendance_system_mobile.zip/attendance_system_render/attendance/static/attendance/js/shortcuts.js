/**
 * ملف JavaScript لإدارة اختصارات لوحة المفاتيح
 * نظام إدارة الحضور والغياب
 */

class KeyboardShortcuts {
    constructor() {
        this.shortcuts = new Map();
        this.isEnabled = true;
        this.helpModalId = 'shortcutsHelpModal';
        
        this.init();
    }
    
    init() {
        this.registerDefaultShortcuts();
        this.bindEvents();
        this.createHelpModal();
        this.showWelcomeTooltip();
    }
    
    registerDefaultShortcuts() {
        // اختصارات عامة
        this.register('ctrl+s', () => this.handleSave(), 'حفظ سريع للبيانات');
        this.register('ctrl+n', () => this.handleNew(), 'إضافة عنصر جديد');
        this.register('escape', () => this.handleEscape(), 'إغلاق النوافذ المنبثقة');
        this.register('f2', () => this.handleEdit(), 'تعديل العنصر المحدد');
        this.register('delete', () => this.handleDelete(), 'حذف العنصر المحدد');
        
        // اختصارات البحث
        this.register('ctrl+f', () => this.handleSearch(), 'التركيز على مربع البحث');
        this.register('ctrl+shift+c', () => this.handleClearSearch(), 'مسح البحث');
        this.register('ctrl+shift+s', () => this.handleSaveSearch(), 'حفظ البحث الحالي');
        
        // اختصارات التنقل
        this.register('ctrl+home', () => this.handleHome(), 'العودة للوحة التحكم');
        this.register('alt+1', () => this.handleNavigation('/'), 'لوحة التحكم');
        this.register('alt+2', () => this.handleNavigation('/students/'), 'قائمة الطلاب');
        this.register('alt+3', () => this.handleNavigation('/teachers/'), 'قائمة المعلمين');
        this.register('alt+4', () => this.handleNavigation('/sessions/'), 'جلسات الحضور');
        this.register('alt+5', () => this.handleNavigation('/reports/'), 'التقارير');
        
        // اختصارات المساعدة
        this.register('f1', () => this.showHelp(), 'عرض قائمة الاختصارات');
        this.register('ctrl+shift+?', () => this.showHelp(), 'عرض قائمة الاختصارات');
        
        // اختصارات خاصة بالجداول
        this.register('ctrl+a', () => this.handleSelectAll(), 'تحديد الكل');
        this.register('ctrl+shift+a', () => this.handleDeselectAll(), 'إلغاء تحديد الكل');
        
        // اختصارات التصدير والاستيراد
        this.register('ctrl+e', () => this.handleExport(), 'تصدير البيانات');
        this.register('ctrl+i', () => this.handleImport(), 'استيراد البيانات');
    }
    
    register(combination, callback, description = '') {
        const key = this.normalizeKey(combination);
        this.shortcuts.set(key, {
            callback,
            description,
            combination: combination.toUpperCase()
        });
    }
    
    unregister(combination) {
        const key = this.normalizeKey(combination);
        this.shortcuts.delete(key);
    }
    
    normalizeKey(combination) {
        return combination.toLowerCase()
            .replace(/\s+/g, '')
            .split('+')
            .sort()
            .join('+');
    }
    
    bindEvents() {
        document.addEventListener('keydown', (e) => {
            if (!this.isEnabled) return;
            
            // تجاهل الاختصارات عند الكتابة في حقول النص
            if (this.isTyping(e.target)) {
                // السماح ببعض الاختصارات المهمة حتى أثناء الكتابة
                if (e.key === 'Escape' || (e.ctrlKey && e.key === 's')) {
                    // متابعة معالجة هذه الاختصارات
                } else {
                    return;
                }
            }
            
            const combination = this.getKeyCombination(e);
            const shortcut = this.shortcuts.get(combination);
            
            if (shortcut) {
                e.preventDefault();
                e.stopPropagation();
                
                try {
                    shortcut.callback(e);
                    this.showShortcutFeedback(shortcut.combination, shortcut.description);
                } catch (error) {
                    console.error('خطأ في تنفيذ الاختصار:', error);
                }
            }
        });
    }
    
    getKeyCombination(event) {
        const keys = [];
        
        if (event.ctrlKey) keys.push('ctrl');
        if (event.altKey) keys.push('alt');
        if (event.shiftKey) keys.push('shift');
        if (event.metaKey) keys.push('meta');
        
        const key = event.key.toLowerCase();
        if (key !== 'control' && key !== 'alt' && key !== 'shift' && key !== 'meta') {
            keys.push(key);
        }
        
        return keys.sort().join('+');
    }
    
    isTyping(element) {
        const typingElements = ['input', 'textarea', 'select'];
        const isContentEditable = element.contentEditable === 'true';
        const isTypingElement = typingElements.includes(element.tagName.toLowerCase());
        
        return isContentEditable || isTypingElement;
    }
    
    // معالجات الاختصارات
    handleSave() {
        const saveButton = document.querySelector('button[type="submit"], .btn-save, #save-btn');
        if (saveButton && !saveButton.disabled) {
            saveButton.click();
        } else {
            // محاولة حفظ النموذج النشط
            const activeForm = document.querySelector('form:not([hidden])');
            if (activeForm) {
                const submitEvent = new Event('submit', { bubbles: true, cancelable: true });
                activeForm.dispatchEvent(submitEvent);
            }
        }
    }
    
    handleNew() {
        const newButton = document.querySelector('.btn-success[data-bs-target*="Modal"], #add-btn, .btn-new');
        if (newButton) {
            newButton.click();
        }
    }
    
    handleEscape() {
        // إغلاق النوافذ المنبثقة المفتوحة
        const openModals = document.querySelectorAll('.modal.show');
        openModals.forEach(modal => {
            const modalInstance = bootstrap.Modal.getInstance(modal);
            if (modalInstance) {
                modalInstance.hide();
            }
        });
        
        // إغلاق القوائم المنسدلة
        const openDropdowns = document.querySelectorAll('.dropdown-menu.show');
        openDropdowns.forEach(dropdown => {
            dropdown.classList.remove('show');
        });
        
        // إلغاء التحديد
        this.handleDeselectAll();
    }
    
    handleEdit() {
        const selectedRow = document.querySelector('tr.selected, .card.selected, .list-item.selected');
        if (selectedRow) {
            const editButton = selectedRow.querySelector('.btn-outline-warning, .btn-edit');
            if (editButton) {
                editButton.click();
            }
        }
    }
    
    handleDelete() {
        const selectedRow = document.querySelector('tr.selected, .card.selected, .list-item.selected');
        if (selectedRow) {
            const deleteButton = selectedRow.querySelector('.btn-outline-danger, .btn-delete');
            if (deleteButton) {
                deleteButton.click();
            }
        } else {
            showWarning('لا يوجد عنصر محدد', 'يرجى تحديد عنصر أولاً للحذف');
        }
    }
    
    handleSearch() {
        const searchInput = document.querySelector('#search, input[name="search"], .search-input');
        if (searchInput) {
            searchInput.focus();
            searchInput.select();
        }
    }
    
    handleClearSearch() {
        if (window.advancedSearch && typeof window.advancedSearch.clearSearch === 'function') {
            window.advancedSearch.clearSearch();
        } else {
            const clearButton = document.querySelector('#clear-search, .btn-clear');
            if (clearButton) {
                clearButton.click();
            }
        }
    }
    
    handleSaveSearch() {
        if (window.advancedSearch && typeof window.advancedSearch.saveCurrentSearch === 'function') {
            window.advancedSearch.saveCurrentSearch();
        } else {
            const saveButton = document.querySelector('#save-search, .btn-save-search');
            if (saveButton) {
                saveButton.click();
            }
        }
    }
    
    handleHome() {
        window.location.href = '/';
    }
    
    handleNavigation(url) {
        window.location.href = url;
    }
    
    handleSelectAll() {
        const checkboxes = document.querySelectorAll('input[type="checkbox"]:not([disabled])');
        checkboxes.forEach(checkbox => {
            checkbox.checked = true;
            checkbox.dispatchEvent(new Event('change'));
        });
        
        // تحديد الصفوف
        const rows = document.querySelectorAll('tr, .card, .list-item');
        rows.forEach(row => row.classList.add('selected'));
    }
    
    handleDeselectAll() {
        const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
        checkboxes.forEach(checkbox => {
            checkbox.checked = false;
            checkbox.dispatchEvent(new Event('change'));
        });
        
        // إلغاء تحديد الصفوف
        const selectedRows = document.querySelectorAll('.selected');
        selectedRows.forEach(row => row.classList.remove('selected'));
    }
    
    handleExport() {
        const exportButton = document.querySelector('.btn-info[href*="export"], #export-btn, .btn-export');
        if (exportButton) {
            exportButton.click();
        }
    }
    
    handleImport() {
        const importButton = document.querySelector('.btn-info[data-bs-target*="import"], #import-btn, .btn-import');
        if (importButton) {
            importButton.click();
        }
    }
    
    showShortcutFeedback(combination, description) {
        // إنشاء tooltip مؤقت لإظهار الاختصار المستخدم
        const feedback = document.createElement('div');
        feedback.className = 'shortcut-feedback';
        feedback.innerHTML = `
            <div class="d-flex align-items-center">
                <kbd class="me-2">${combination}</kbd>
                <span>${description}</span>
            </div>
        `;
        
        document.body.appendChild(feedback);
        
        // إزالة التغذية الراجعة بعد ثانيتين
        setTimeout(() => {
            if (feedback.parentNode) {
                feedback.parentNode.removeChild(feedback);
            }
        }, 2000);
    }
    
    showWelcomeTooltip() {
        // عرض tooltip ترحيبي لمرة واحدة
        if (!localStorage.getItem('shortcutsWelcomeShown')) {
            setTimeout(() => {
                showInfo(
                    'اختصارات لوحة المفاتيح متاحة!',
                    'اضغط F1 أو Ctrl+Shift+? لعرض قائمة الاختصارات المتاحة'
                );
                localStorage.setItem('shortcutsWelcomeShown', 'true');
            }, 2000);
        }
    }
    
    createHelpModal() {
        // إنشاء نافذة مساعدة الاختصارات
        const modalHtml = `
            <div class="modal fade" id="${this.helpModalId}" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">
                                <i class="fas fa-keyboard me-2"></i>
                                اختصارات لوحة المفاتيح
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h6 class="text-primary">اختصارات عامة</h6>
                                    <div class="shortcut-list">
                                        ${this.generateShortcutsList(['ctrl+s', 'ctrl+n', 'escape', 'f2', 'delete'])}
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <h6 class="text-success">اختصارات البحث</h6>
                                    <div class="shortcut-list">
                                        ${this.generateShortcutsList(['ctrl+f', 'ctrl+shift+c', 'ctrl+shift+s'])}
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-6">
                                    <h6 class="text-info">اختصارات التنقل</h6>
                                    <div class="shortcut-list">
                                        ${this.generateShortcutsList(['ctrl+home', 'alt+1', 'alt+2', 'alt+3', 'alt+4', 'alt+5'])}
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <h6 class="text-warning">اختصارات أخرى</h6>
                                    <div class="shortcut-list">
                                        ${this.generateShortcutsList(['ctrl+a', 'ctrl+shift+a', 'ctrl+e', 'ctrl+i', 'f1'])}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="enableShortcuts" ${this.isEnabled ? 'checked' : ''}>
                                <label class="form-check-label" for="enableShortcuts">
                                    تفعيل اختصارات لوحة المفاتيح
                                </label>
                            </div>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إغلاق</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        
        // ربط checkbox التفعيل/الإلغاء
        document.getElementById('enableShortcuts').addEventListener('change', (e) => {
            this.isEnabled = e.target.checked;
            localStorage.setItem('shortcutsEnabled', this.isEnabled);
        });
        
        // تحميل حالة التفعيل المحفوظة
        const savedState = localStorage.getItem('shortcutsEnabled');
        if (savedState !== null) {
            this.isEnabled = savedState === 'true';
            document.getElementById('enableShortcuts').checked = this.isEnabled;
        }
    }
    
    generateShortcutsList(keys) {
        return keys.map(key => {
            const shortcut = this.shortcuts.get(key);
            if (shortcut) {
                return `
                    <div class="d-flex justify-content-between align-items-center py-1">
                        <kbd class="shortcut-key">${shortcut.combination}</kbd>
                        <span class="shortcut-desc">${shortcut.description}</span>
                    </div>
                `;
            }
            return '';
        }).join('');
    }
    
    showHelp() {
        const modal = new bootstrap.Modal(document.getElementById(this.helpModalId));
        modal.show();
    }
    
    enable() {
        this.isEnabled = true;
        localStorage.setItem('shortcutsEnabled', 'true');
    }
    
    disable() {
        this.isEnabled = false;
        localStorage.setItem('shortcutsEnabled', 'false');
    }
    
    toggle() {
        this.isEnabled = !this.isEnabled;
        localStorage.setItem('shortcutsEnabled', this.isEnabled);
    }
}

// تهيئة نظام الاختصارات عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    window.keyboardShortcuts = new KeyboardShortcuts();
});

// تصدير الكلاس للاستخدام العام
window.KeyboardShortcuts = KeyboardShortcuts;

