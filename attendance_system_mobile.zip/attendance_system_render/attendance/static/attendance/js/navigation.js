/**
 * ملف JavaScript لتحسين التنقل والقوائم
 * نظام إدارة الحضور والغياب
 */

class NavigationEnhancer {
    constructor() {
        this.currentPage = window.location.pathname;
        this.breadcrumbs = [];
        
        this.init();
    }
    
    init() {
        this.enhanceNavigation();
        this.addBreadcrumbs();
        this.addQuickAccessToolbar();
        this.addPageTransitions();
        this.addActiveStates();
        this.addTooltips();
    }
    
    enhanceNavigation() {
        // إضافة تأثيرات hover للقوائم
        const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
        navLinks.forEach(link => {
            link.addEventListener('mouseenter', (e) => {
                e.target.style.transform = 'translateY(-2px)';
                e.target.style.transition = 'all 0.3s ease';
            });
            
            link.addEventListener('mouseleave', (e) => {
                e.target.style.transform = 'translateY(0)';
            });
        });
        
        // إضافة مؤشر الصفحة النشطة
        this.highlightActivePage();
        
        // إضافة قائمة منسدلة للمستخدم محسنة
        this.enhanceUserDropdown();
    }
    
    highlightActivePage() {
        const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
        navLinks.forEach(link => {
            if (link.getAttribute('href') === this.currentPage) {
                link.classList.add('active');
                link.style.background = 'rgba(255, 255, 255, 0.2)';
                link.style.borderRadius = '6px';
            }
        });
    }
    
    enhanceUserDropdown() {
        const userDropdown = document.querySelector('.dropdown-toggle');
        if (userDropdown) {
            // إضافة أيقونة المستخدم
            const userIcon = document.createElement('i');
            userIcon.className = 'fas fa-user-circle me-2';
            userDropdown.insertBefore(userIcon, userDropdown.firstChild);
            
            // إضافة تأثيرات للقائمة المنسدلة
            const dropdownMenu = document.querySelector('.dropdown-menu');
            if (dropdownMenu) {
                dropdownMenu.style.borderRadius = '12px';
                dropdownMenu.style.boxShadow = '0 8px 25px rgba(0, 0, 0, 0.15)';
                dropdownMenu.style.border = 'none';
                dropdownMenu.style.marginTop = '8px';
            }
        }
    }
    
    addBreadcrumbs() {
        // إنشاء breadcrumbs تلقائياً
        const breadcrumbContainer = document.createElement('nav');
        breadcrumbContainer.setAttribute('aria-label', 'breadcrumb');
        breadcrumbContainer.className = 'breadcrumb-container';
        
        const breadcrumbList = document.createElement('ol');
        breadcrumbList.className = 'breadcrumb';
        
        // تحديد المسار الحالي
        const pathSegments = this.currentPage.split('/').filter(segment => segment);
        const breadcrumbItems = this.generateBreadcrumbs(pathSegments);
        
        breadcrumbItems.forEach((item, index) => {
            const listItem = document.createElement('li');
            listItem.className = 'breadcrumb-item';
            
            if (index === breadcrumbItems.length - 1) {
                listItem.classList.add('active');
                listItem.setAttribute('aria-current', 'page');
                listItem.textContent = item.title;
            } else {
                const link = document.createElement('a');
                link.href = item.url;
                link.textContent = item.title;
                link.className = 'breadcrumb-link';
                listItem.appendChild(link);
            }
            
            breadcrumbList.appendChild(listItem);
        });
        
        breadcrumbContainer.appendChild(breadcrumbList);
        
        // إدراج breadcrumbs في الصفحة
        const mainContent = document.querySelector('main .container-fluid');
        if (mainContent && breadcrumbItems.length > 1) {
            mainContent.insertBefore(breadcrumbContainer, mainContent.firstChild);
        }
    }
    
    generateBreadcrumbs(pathSegments) {
        const breadcrumbs = [
            { title: 'الرئيسية', url: '/' }
        ];
        
        let currentPath = '';
        pathSegments.forEach(segment => {
            currentPath += '/' + segment;
            
            const title = this.getPageTitle(segment);
            if (title) {
                breadcrumbs.push({
                    title: title,
                    url: currentPath
                });
            }
        });
        
        return breadcrumbs;
    }
    
    getPageTitle(segment) {
        const pageTitles = {
            'students': 'الطلاب',
            'teachers': 'المعلمين',
            'sessions': 'جلسات الحضور',
            'reports': 'التقارير',
            'profile': 'الملف الشخصي',
            'notifications': 'الإشعارات',
            'settings': 'الإعدادات',
            'attendance': 'الحضور والغياب',
            'dashboard': 'لوحة التحكم'
        };
        
        return pageTitles[segment] || null;
    }
    
    addQuickAccessToolbar() {
        const toolbar = document.createElement('div');
        toolbar.className = 'quick-access-toolbar';
        toolbar.innerHTML = `
            <button class="quick-access-btn" data-shortcut="F1" title="المساعدة (F1)" onclick="keyboardShortcuts.showHelp()">
                <i class="fas fa-question"></i>
            </button>
            <button class="quick-access-btn" data-shortcut="Ctrl+N" title="إضافة جديد (Ctrl+N)" onclick="keyboardShortcuts.handleNew()">
                <i class="fas fa-plus"></i>
            </button>
            <button class="quick-access-btn" data-shortcut="Ctrl+F" title="البحث (Ctrl+F)" onclick="keyboardShortcuts.handleSearch()">
                <i class="fas fa-search"></i>
            </button>
            <button class="quick-access-btn" data-shortcut="Ctrl+Home" title="الرئيسية (Ctrl+Home)" onclick="keyboardShortcuts.handleHome()">
                <i class="fas fa-home"></i>
            </button>
        `;
        
        document.body.appendChild(toolbar);
        
        // إضافة تأثيرات hover
        const buttons = toolbar.querySelectorAll('.quick-access-btn');
        buttons.forEach(button => {
            button.addEventListener('mouseenter', () => {
                button.style.transform = 'translateY(-4px) scale(1.1)';
            });
            
            button.addEventListener('mouseleave', () => {
                button.style.transform = 'translateY(0) scale(1)';
            });
        });
    }
    
    addPageTransitions() {
        // إضافة تأثيرات انتقالية للصفحات
        document.body.style.opacity = '0';
        document.body.style.transition = 'opacity 0.3s ease-in-out';
        
        window.addEventListener('load', () => {
            document.body.style.opacity = '1';
        });
        
        // تأثيرات للروابط
        const links = document.querySelectorAll('a[href^="/"]');
        links.forEach(link => {
            link.addEventListener('click', (e) => {
                if (e.ctrlKey || e.metaKey || e.shiftKey) return;
                
                const href = link.getAttribute('href');
                if (href && href !== this.currentPage) {
                    e.preventDefault();
                    
                    document.body.style.opacity = '0.7';
                    
                    setTimeout(() => {
                        window.location.href = href;
                    }, 150);
                }
            });
        });
    }
    
    addActiveStates() {
        // إضافة حالات نشطة للعناصر التفاعلية
        const interactiveElements = document.querySelectorAll('button, .btn, .card, .list-group-item');
        
        interactiveElements.forEach(element => {
            element.addEventListener('mousedown', () => {
                element.style.transform = 'scale(0.98)';
            });
            
            element.addEventListener('mouseup', () => {
                element.style.transform = 'scale(1)';
            });
            
            element.addEventListener('mouseleave', () => {
                element.style.transform = 'scale(1)';
            });
        });
    }
    
    addTooltips() {
        // إضافة tooltips للعناصر التي تحتاج توضيح
        const elementsNeedingTooltips = document.querySelectorAll('[data-shortcut]');
        
        elementsNeedingTooltips.forEach(element => {
            const shortcut = element.getAttribute('data-shortcut');
            const currentTitle = element.getAttribute('title') || '';
            
            if (shortcut && !currentTitle.includes(shortcut)) {
                element.setAttribute('title', `${currentTitle} (${shortcut})`);
                element.setAttribute('data-bs-toggle', 'tooltip');
                element.setAttribute('data-bs-placement', 'top');
            }
        });
        
        // تفعيل Bootstrap tooltips
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl, {
                delay: { show: 500, hide: 100 }
            });
        });
    }
    
    addLoadingIndicator() {
        // إضافة مؤشر تحميل عام للصفحة
        const loadingIndicator = document.createElement('div');
        loadingIndicator.id = 'page-loading-indicator';
        loadingIndicator.className = 'page-loading-indicator';
        loadingIndicator.innerHTML = `
            <div class="loading-spinner-large"></div>
            <div class="loading-text">جاري التحميل...</div>
        `;
        
        document.body.appendChild(loadingIndicator);
        
        // إخفاء المؤشر عند اكتمال التحميل
        window.addEventListener('load', () => {
            setTimeout(() => {
                loadingIndicator.style.opacity = '0';
                setTimeout(() => {
                    loadingIndicator.remove();
                }, 300);
            }, 500);
        });
    }
    
    addKeyboardNavigationHints() {
        // إضافة تلميحات التنقل بلوحة المفاتيح
        const hint = document.createElement('div');
        hint.className = 'keyboard-hint';
        hint.innerHTML = `
            <div class="d-flex align-items-center">
                <kbd class="me-2">↑↓</kbd>
                <span>تنقل</span>
                <kbd class="mx-2">Space</kbd>
                <span>تحديد</span>
                <kbd class="mx-2">Esc</kbd>
                <span>إلغاء</span>
            </div>
        `;
        
        document.body.appendChild(hint);
        
        // إظهار التلميح عند استخدام لوحة المفاتيح
        let keyboardUsed = false;
        document.addEventListener('keydown', () => {
            if (!keyboardUsed) {
                keyboardUsed = true;
                document.body.classList.add('keyboard-navigation-active');
            }
        });
        
        document.addEventListener('mousedown', () => {
            if (keyboardUsed) {
                keyboardUsed = false;
                document.body.classList.remove('keyboard-navigation-active');
            }
        });
    }
}

// تهيئة محسن التنقل عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    window.navigationEnhancer = new NavigationEnhancer();
});

// تصدير الكلاس للاستخدام العام
window.NavigationEnhancer = NavigationEnhancer;

