/**
 * ملف JavaScript لإدارة تحديد الصفوف والعناصر
 * نظام إدارة الحضور والغياب
 */

class RowSelection {
    constructor(options = {}) {
        this.tableSelector = options.tableSelector || 'table';
        this.rowSelector = options.rowSelector || 'tbody tr';
        this.selectAllSelector = options.selectAllSelector || '#select-all';
        this.selectedClass = options.selectedClass || 'selected';
        
        this.selectedRows = new Set();
        this.isMultiSelectMode = false;
        
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.createSelectionToolbar();
    }
    
    bindEvents() {
        // تحديد الصفوف بالنقر
        document.addEventListener('click', (e) => {
            const row = e.target.closest(this.rowSelector);
            if (row && !this.isClickOnButton(e.target)) {
                this.handleRowClick(row, e);
            }
        });
        
        // تحديد الكل
        const selectAllCheckbox = document.querySelector(this.selectAllSelector);
        if (selectAllCheckbox) {
            selectAllCheckbox.addEventListener('change', (e) => {
                this.handleSelectAll(e.target.checked);
            });
        }
        
        // اختصارات لوحة المفاتيح للتحديد
        document.addEventListener('keydown', (e) => {
            if (e.target.tagName.toLowerCase() === 'input' || 
                e.target.tagName.toLowerCase() === 'textarea') {
                return;
            }
            
            switch (e.key) {
                case 'ArrowUp':
                    e.preventDefault();
                    this.selectPrevious();
                    break;
                case 'ArrowDown':
                    e.preventDefault();
                    this.selectNext();
                    break;
                case ' ':
                    e.preventDefault();
                    this.toggleCurrentSelection();
                    break;
            }
        });
    }
    
    isClickOnButton(element) {
        return element.closest('button, a, input, select, textarea') !== null;
    }
    
    handleRowClick(row, event) {
        if (event.ctrlKey || event.metaKey) {
            // تحديد متعدد
            this.toggleRowSelection(row);
            this.isMultiSelectMode = true;
        } else if (event.shiftKey && this.selectedRows.size > 0) {
            // تحديد نطاق
            this.selectRange(row);
        } else {
            // تحديد واحد
            this.selectSingle(row);
            this.isMultiSelectMode = false;
        }
        
        this.updateSelectionToolbar();
        this.updateSelectAllCheckbox();
    }
    
    toggleRowSelection(row) {
        if (this.selectedRows.has(row)) {
            this.deselectRow(row);
        } else {
            this.selectRow(row);
        }
    }
    
    selectRow(row) {
        row.classList.add(this.selectedClass);
        this.selectedRows.add(row);
        
        // تحديد checkbox إذا وجد
        const checkbox = row.querySelector('input[type="checkbox"]');
        if (checkbox) {
            checkbox.checked = true;
        }
    }
    
    deselectRow(row) {
        row.classList.remove(this.selectedClass);
        this.selectedRows.delete(row);
        
        // إلغاء تحديد checkbox إذا وجد
        const checkbox = row.querySelector('input[type="checkbox"]');
        if (checkbox) {
            checkbox.checked = false;
        }
    }
    
    selectSingle(row) {
        this.clearSelection();
        this.selectRow(row);
    }
    
    selectRange(endRow) {
        const rows = Array.from(document.querySelectorAll(this.rowSelector));
        const lastSelected = Array.from(this.selectedRows).pop();
        
        if (!lastSelected) {
            this.selectRow(endRow);
            return;
        }
        
        const startIndex = rows.indexOf(lastSelected);
        const endIndex = rows.indexOf(endRow);
        
        const start = Math.min(startIndex, endIndex);
        const end = Math.max(startIndex, endIndex);
        
        this.clearSelection();
        
        for (let i = start; i <= end; i++) {
            this.selectRow(rows[i]);
        }
    }
    
    selectPrevious() {
        const rows = Array.from(document.querySelectorAll(this.rowSelector));
        const currentSelected = Array.from(this.selectedRows).pop();
        
        if (!currentSelected) {
            if (rows.length > 0) {
                this.selectSingle(rows[0]);
            }
            return;
        }
        
        const currentIndex = rows.indexOf(currentSelected);
        if (currentIndex > 0) {
            this.selectSingle(rows[currentIndex - 1]);
        }
    }
    
    selectNext() {
        const rows = Array.from(document.querySelectorAll(this.rowSelector));
        const currentSelected = Array.from(this.selectedRows).pop();
        
        if (!currentSelected) {
            if (rows.length > 0) {
                this.selectSingle(rows[0]);
            }
            return;
        }
        
        const currentIndex = rows.indexOf(currentSelected);
        if (currentIndex < rows.length - 1) {
            this.selectSingle(rows[currentIndex + 1]);
        }
    }
    
    toggleCurrentSelection() {
        const currentSelected = Array.from(this.selectedRows).pop();
        if (currentSelected) {
            this.toggleRowSelection(currentSelected);
            this.updateSelectionToolbar();
            this.updateSelectAllCheckbox();
        }
    }
    
    handleSelectAll(checked) {
        if (checked) {
            this.selectAll();
        } else {
            this.clearSelection();
        }
        
        this.updateSelectionToolbar();
    }
    
    selectAll() {
        const rows = document.querySelectorAll(this.rowSelector);
        rows.forEach(row => this.selectRow(row));
    }
    
    clearSelection() {
        this.selectedRows.forEach(row => this.deselectRow(row));
        this.selectedRows.clear();
    }
    
    updateSelectAllCheckbox() {
        const selectAllCheckbox = document.querySelector(this.selectAllSelector);
        if (!selectAllCheckbox) return;
        
        const totalRows = document.querySelectorAll(this.rowSelector).length;
        const selectedCount = this.selectedRows.size;
        
        if (selectedCount === 0) {
            selectAllCheckbox.checked = false;
            selectAllCheckbox.indeterminate = false;
        } else if (selectedCount === totalRows) {
            selectAllCheckbox.checked = true;
            selectAllCheckbox.indeterminate = false;
        } else {
            selectAllCheckbox.checked = false;
            selectAllCheckbox.indeterminate = true;
        }
    }
    
    createSelectionToolbar() {
        const toolbar = document.createElement('div');
        toolbar.id = 'selection-toolbar';
        toolbar.className = 'selection-toolbar d-none';
        toolbar.innerHTML = `
            <div class="d-flex align-items-center justify-content-between">
                <div class="selection-info">
                    <span id="selection-count">0</span> عنصر محدد
                </div>
                <div class="selection-actions">
                    <button type="button" class="btn btn-sm btn-outline-danger" id="delete-selected">
                        <i class="fas fa-trash me-1"></i>حذف المحدد
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-info" id="export-selected">
                        <i class="fas fa-download me-1"></i>تصدير المحدد
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-secondary" id="clear-selection">
                        <i class="fas fa-times me-1"></i>إلغاء التحديد
                    </button>
                </div>
            </div>
        `;
        
        // إدراج الشريط في أعلى الجدول
        const table = document.querySelector(this.tableSelector);
        if (table) {
            table.parentNode.insertBefore(toolbar, table);
        }
        
        // ربط الأحداث
        document.getElementById('delete-selected').addEventListener('click', () => {
            this.deleteSelected();
        });
        
        document.getElementById('export-selected').addEventListener('click', () => {
            this.exportSelected();
        });
        
        document.getElementById('clear-selection').addEventListener('click', () => {
            this.clearSelection();
            this.updateSelectionToolbar();
            this.updateSelectAllCheckbox();
        });
    }
    
    updateSelectionToolbar() {
        const toolbar = document.getElementById('selection-toolbar');
        const countElement = document.getElementById('selection-count');
        
        if (!toolbar || !countElement) return;
        
        const selectedCount = this.selectedRows.size;
        
        if (selectedCount > 0) {
            toolbar.classList.remove('d-none');
            countElement.textContent = selectedCount;
        } else {
            toolbar.classList.add('d-none');
        }
    }
    
    deleteSelected() {
        if (this.selectedRows.size === 0) {
            showWarning('لا يوجد عناصر محددة', 'يرجى تحديد عنصر واحد على الأقل للحذف');
            return;
        }
        
        const selectedCount = this.selectedRows.size;
        confirmDelete(
            `حذف ${selectedCount} عنصر`,
            `هل أنت متأكد من حذف ${selectedCount} عنصر محدد؟ لن تتمكن من التراجع عن هذا الإجراء!`
        ).then((result) => {
            if (result.isConfirmed) {
                showLoading('جاري حذف العناصر المحددة...');
                
                // تنفيذ الحذف
                const deletePromises = Array.from(this.selectedRows).map(row => {
                    const deleteButton = row.querySelector('.btn-delete');
                    if (deleteButton) {
                        const deleteUrl = deleteButton.getAttribute('data-url');
                        if (deleteUrl) {
                            return fetch(deleteUrl, { method: 'POST' });
                        }
                    }
                    return Promise.resolve();
                });
                
                Promise.all(deletePromises).then(() => {
                    hideLoading();
                    showOperationSuccess('delete', `${selectedCount} عنصر`);
                    
                    // إعادة تحميل الصفحة أو تحديث البيانات
                    setTimeout(() => {
                        window.location.reload();
                    }, 1500);
                }).catch(error => {
                    hideLoading();
                    showError('خطأ في الحذف', 'حدث خطأ أثناء حذف بعض العناصر');
                });
            }
        });
    }
    
    exportSelected() {
        if (this.selectedRows.size === 0) {
            showWarning('لا يوجد عناصر محددة', 'يرجى تحديد عنصر واحد على الأقل للتصدير');
            return;
        }
        
        // جمع بيانات الصفوف المحددة
        const selectedData = Array.from(this.selectedRows).map(row => {
            const cells = row.querySelectorAll('td');
            return Array.from(cells).map(cell => cell.textContent.trim());
        });
        
        // تصدير البيانات كـ CSV
        this.exportToCSV(selectedData);
        
        showOperationSuccess('export', `${this.selectedRows.size} عنصر`);
    }
    
    exportToCSV(data) {
        // الحصول على رؤوس الأعمدة
        const headers = Array.from(document.querySelectorAll(`${this.tableSelector} thead th`))
            .map(th => th.textContent.trim());
        
        // إنشاء محتوى CSV
        const csvContent = [
            headers.join(','),
            ...data.map(row => row.join(','))
        ].join('\n');
        
        // تحميل الملف
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        
        link.setAttribute('href', url);
        link.setAttribute('download', `selected_data_${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    
    getSelectedRows() {
        return Array.from(this.selectedRows);
    }
    
    getSelectedCount() {
        return this.selectedRows.size;
    }
    
    hasSelection() {
        return this.selectedRows.size > 0;
    }
}

// تهيئة نظام تحديد الصفوف عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    window.rowSelection = new RowSelection();
});

// تصدير الكلاس للاستخدام العام
window.RowSelection = RowSelection;

