from django.urls import path
from . import views

urlpatterns = [
    # صفحة تسجيل الدخول والخروج
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    
    # لوحة التحكم الرئيسية
    path('', views.dashboard, name='dashboard'),
    
    # إدارة الطلاب
    path('students/', views.student_list, name='student_list'),
    path('students/import/', views.import_students_excel, name='import_students_excel'),
    path('students/export/', views.export_students_excel, name='export_students_excel'),
    
    # إدارة المعلمين
    path('teachers/', views.teacher_list, name='teacher_list'),
    path('teachers/add/', views.add_teacher, name='add_teacher'),
    path('teachers/edit/<int:teacher_id>/', views.teacher_edit, name='teacher_edit'),
    path('teachers/detail/<int:teacher_id>/', views.teacher_detail, name='teacher_detail'),
    path('teachers/delete/<int:teacher_id>/', views.delete_teacher, name='delete_teacher'),
    path('teachers/import/', views.import_teachers_excel, name='import_teachers_excel'),
    path('teachers/export/', views.export_teachers_excel, name='export_teachers_excel'),
    path('teachers/assign-subjects/<int:teacher_id>/', views.assign_teacher_subjects, name='assign_teacher_subjects'),
    path('teachers/assign-classrooms/<int:teacher_id>/', views.assign_teacher_classrooms, name='assign_teacher_classrooms'),
    
    # جلسات الحضور
    path('sessions/', views.attendance_session_list, name='attendance_sessions'),
    path('session/<int:session_id>/', views.attendance_session_detail, name='session_detail'),
    path('session/<int:session_id>/take-attendance/', views.take_attendance, name='take_attendance'),
    
    # التقارير والإحصائيات
    path('reports/', views.attendance_reports, name='attendance_reports'),
    path('reports/advanced/', views.advanced_reports, name='advanced_reports'),
    path('reports/generate/', views.generate_custom_report, name='generate_custom_report'),
    path('reports/export/<str:format>/', views.export_report, name='export_report'),
    path('statistics/', views.attendance_statistics, name='attendance_statistics'),
    path('analytics/', views.attendance_analytics, name='attendance_analytics'),
    
    # التقارير المتكاملة حسب الأدوار
    path('reports/admin/', views.admin_reports, name='admin_reports'),
    path('reports/teacher/', views.teacher_reports, name='teacher_reports'),
    path('reports/student/', views.student_reports, name='student_reports'),
    path('reports/parent/', views.parent_reports, name='parent_reports'),
    
    # إدارة قوالب التقارير
    path('reports/templates/', views.report_templates, name='report_templates'),
    path('reports/preferences/', views.report_preferences, name='report_preferences'),
    # path(
    #     "reports/templates/create/",
    #     views.create_report_template,
    #     name="create_report_template",
    # ),
    # path(
    #     "reports/templates/edit/<int:template_id>/",
    #     views.edit_report_template,
    #     name="edit_report_template",
    # ),
    # path(
    #     "reports/templates/delete/<int:template_id>/",
    #     views.delete_report_template,
    #     name="delete_report_template",
    # ),
    # path(
    #     "reports/scheduled/",
    #     views.scheduled_reports,
    #     name="scheduled_reports",
    # ),
    # path(
    #     "reports/scheduled/create/",
    #     views.create_scheduled_report,
    #     name="create_scheduled_report",
    # ),
    # path(
    #     "reports/scheduled/edit/<int:report_id>/",
    #     views.edit_scheduled_report,
    #     name="edit_scheduled_report",
    # ),
    # path(
    #     "reports/scheduled/delete/<int:report_id>/",
    #     views.delete_scheduled_report,
    #     name="delete_scheduled_report",
    # ),='execute_report'),
    path('reports/execution/<int:execution_id>/', views.view_report_execution, name='view_report_execution'),
    # path(
    #     "reports/execution/<int:execution_id>/download/",
    #     views.download_report,
    #     name="download_report",
    # ),  path('reports/preferences/', views.report_preferences, name='report_preferences'),
    
    # إدارة الجداول الدراسية
    path('schedules/', views.schedule_list, name='schedule_list'),
    path('schedules/export/', views.export_schedules, name='export_schedules'),
    path('schedules/create/', views.create_schedule, name='create_schedule'),
    path('schedules/<int:schedule_id>/', views.schedule_detail, name='schedule_detail'),
    path('schedules/<int:schedule_id>/edit/', views.edit_schedule, name='edit_schedule'),
    path('schedules/<int:schedule_id>/delete/', views.delete_schedule, name='delete_schedule'),
    path('schedules/<int:schedule_id>/copy/', views.copy_schedule, name='copy_schedule'),
    
    # مسارات الحصص الدراسية
    path('schedules/<int:schedule_id>/slots/', views.schedule_slots, name='schedule_slots'),
    path('schedules/<int:schedule_id>/slots/add/', views.add_schedule_slot, name='add_schedule_slot'),
    path('slots/<int:slot_id>/edit/', views.edit_schedule_slot, name='edit_schedule_slot'),
    path('slots/<int:slot_id>/delete/', views.delete_schedule_slot, name='delete_schedule_slot'),
    
    # مسارات الفترات الزمنية
    path('time-slots/', views.time_slot_list, name='time_slot_list'),
    path('time-slots/create/', views.create_time_slot, name='create_time_slot'),
    path('time-slots/<int:slot_id>/edit/', views.edit_time_slot, name='edit_time_slot'),
    path('time-slots/<int:slot_id>/delete/', views.delete_time_slot, name='delete_time_slot'),
    
    # مسارات الجداول الشخصية
    path('my-schedule/', views.my_schedule, name='my_schedule'),
    path('teacher-schedule/<int:teacher_id>/', views.teacher_schedule, name='teacher_schedule'),
    path('student-schedule/<int:student_id>/', views.student_schedule, name='student_schedule'),
    path('classroom-schedule/<int:classroom_id>/', views.classroom_schedule, name='classroom_schedule'),
    
    # AJAX endpoints للجداول
    path('ajax/schedule-conflicts/<int:schedule_id>/', views.get_schedule_conflicts, name='get_schedule_conflicts'),
    path('ajax/available-teachers/', views.get_available_teachers, name='get_available_teachers'),
    path('ajax/available-classrooms/', views.get_available_classrooms, name='get_available_classrooms'),
    path('ajax/schedule-data/<int:schedule_id>/', views.get_schedule_data, name='get_schedule_data'),
    path('ajax/update-slot/', views.update_schedule_slot_ajax, name='update_schedule_slot_ajax'),
    
    # تصدير الجداول
    path('schedules/<int:schedule_id>/export/pdf/', views.export_schedule_pdf, name='export_schedule_pdf'),
    path('schedules/<int:schedule_id>/export/excel/', views.export_schedule_excel, name='export_schedule_excel'),
    path('my-schedule/export/pdf/', views.export_my_schedule_pdf, name='export_my_schedule_pdf'),
    
    # قوالب الجداول
    path('schedule-templates/', views.schedule_template_list, name='schedule_template_list'),
    path('schedule-templates/create/', views.create_schedule_template, name='create_schedule_template'),
    path('schedule-templates/<int:template_id>/apply/', views.apply_schedule_template, name='apply_schedule_template'),
    
    # تفضيلات الجداول
    path('schedule-preferences/', views.schedule_preferences, name='schedule_preferences'),
    
    # نظام الإنذار المبكر
    path('early-warning/', views.early_warning_dashboard, name='early_warning_dashboard'),
    path('early-warning/student/<int:student_id>/', views.student_risk_analysis, name='student_risk_analysis'),
    path('early-warning/send/<int:student_id>/', views.send_warning_notification, name='send_warning_notification'),
    path('early-warning/run-check/', views.run_warning_check, name='run_warning_check'),
    path('api/early-warning/', views.early_warning_api, name='early_warning_api'),
    path('api/classroom-warning/<int:classroom_id>/', views.classroom_warning_stats, name='classroom_warning_stats'),
    
    # الملف الشخصي والإشعارات
    path('profile/', views.profile_view, name='profile'),
    path('notifications/', views.notifications_view, name='notifications'),
    
    # AJAX endpoints
    path('api/subjects-by-classroom/', views.get_subjects_by_classroom, name='get_subjects_by_classroom'),
    path('api/search-students/', views.search_students_ajax, name='search_students_ajax'),
    path('api/filter-students/', views.filter_students_ajax, name='filter_students_ajax'),
    path('students/delete/<int:student_id>/', views.delete_student, name='delete_student'),
    path('api/search-teachers/', views.search_teachers_ajax, name='search_teachers_ajax'),
    path('api/filter-teachers/', views.filter_teachers_ajax, name='filter_teachers_ajax'),
    path('api/get-teacher-subjects/<int:teacher_id>/', views.get_teacher_subjects, name='get_teacher_subjects'),
    path('api/get-teacher-classrooms/<int:teacher_id>/', views.get_teacher_classrooms, name='get_teacher_classrooms'),
    
    # إدارة الصلاحيات
    path('permissions/', views.permissions_dashboard, name='permissions_dashboard'),
    path('permissions/users/', views.users_permissions_list, name='users_permissions_list'),
    path('permissions/user/<int:user_id>/', views.user_permissions_detail, name='user_permissions_detail'),
]

