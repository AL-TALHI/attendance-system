"""
نظام الإنذار المبكر للطلاب ذوي الحضور المنخفض
Early Warning System for Students with Low Attendance
"""

from django.db.models import Count, Q, Avg
from django.utils import timezone
from datetime import datetime, timedelta
from .models import Student, AttendanceRecord, AttendanceSession, Notification, User
import logging

logger = logging.getLogger(__name__)


class EarlyWarningSystem:
    """نظام الإنذار المبكر للطلاب"""
    
    # مستويات التحذير
    WARNING_LEVELS = {
        'green': {'min_rate': 90, 'color': '#28a745', 'label': 'ممتاز'},
        'yellow': {'min_rate': 75, 'color': '#ffc107', 'label': 'تحذير'},
        'orange': {'min_rate': 60, 'color': '#fd7e14', 'label': 'خطر متوسط'},
        'red': {'min_rate': 0, 'color': '#dc3545', 'label': 'خطر عالي'}
    }
    
    def __init__(self):
        self.today = timezone.now().date()
        self.week_ago = self.today - timedelta(days=7)
        self.month_ago = self.today - timedelta(days=30)
    
    def calculate_attendance_rate(self, student, days=30):
        """حساب معدل الحضور للطالب خلال فترة محددة"""
        try:
            end_date = self.today
            start_date = end_date - timedelta(days=days)
            
            # جلب جلسات الحضور للطالب في الفترة المحددة
            sessions = AttendanceSession.objects.filter(
                classroom=student.classroom,
                date__range=[start_date, end_date],
                is_completed=True
            )
            
            total_sessions = sessions.count()
            if total_sessions == 0:
                return 100.0  # لا توجد جلسات، نعتبر المعدل 100%
            
            # حساب عدد الجلسات التي حضرها الطالب
            attended_sessions = AttendanceRecord.objects.filter(
                student=student,
                session__in=sessions,
                status='present'
            ).count()
            
            attendance_rate = (attended_sessions / total_sessions) * 100
            return round(attendance_rate, 2)
            
        except Exception as e:
            logger.error(f"خطأ في حساب معدل الحضور للطالب {student.id}: {e}")
            return 0.0
    
    def get_warning_level(self, attendance_rate):
        """تحديد مستوى التحذير بناءً على معدل الحضور"""
        for level, config in self.WARNING_LEVELS.items():
            if attendance_rate >= config['min_rate']:
                return level, config
        return 'red', self.WARNING_LEVELS['red']
    
    def analyze_student_risk(self, student):
        """تحليل مستوى الخطر للطالب"""
        try:
            # حساب معدلات الحضور لفترات مختلفة
            weekly_rate = self.calculate_attendance_rate(student, 7)
            monthly_rate = self.calculate_attendance_rate(student, 30)
            overall_rate = self.calculate_attendance_rate(student, 90)
            
            # تحديد مستوى التحذير
            current_level, level_config = self.get_warning_level(monthly_rate)
            
            # حساب الاتجاه (تحسن أم تراجع)
            trend = 'stable'
            if weekly_rate > monthly_rate + 5:
                trend = 'improving'
            elif weekly_rate < monthly_rate - 5:
                trend = 'declining'
            
            # حساب عدد أيام الغياب المتتالية
            consecutive_absences = self.get_consecutive_absences(student)
            
            # تحديد مستوى الأولوية
            priority = self.calculate_priority(monthly_rate, consecutive_absences, trend)
            
            return {
                'student': student,
                'weekly_rate': weekly_rate,
                'monthly_rate': monthly_rate,
                'overall_rate': overall_rate,
                'warning_level': current_level,
                'level_config': level_config,
                'trend': trend,
                'consecutive_absences': consecutive_absences,
                'priority': priority,
                'last_attendance': self.get_last_attendance_date(student),
                'total_absences': self.get_total_absences(student),
                'recommendations': self.generate_recommendations(monthly_rate, consecutive_absences, trend)
            }
            
        except Exception as e:
            logger.error(f"خطأ في تحليل الطالب {student.id}: {e}")
            return None
    
    def get_consecutive_absences(self, student):
        """حساب عدد أيام الغياب المتتالية"""
        try:
            recent_records = AttendanceRecord.objects.filter(
                student=student,
                session__date__gte=self.week_ago
            ).order_by('-session__date')
            
            consecutive = 0
            for record in recent_records:
                if record.status == 'absent':
                    consecutive += 1
                else:
                    break
            
            return consecutive
            
        except Exception as e:
            logger.error(f"خطأ في حساب الغياب المتتالي للطالب {student.id}: {e}")
            return 0
    
    def get_last_attendance_date(self, student):
        """تاريخ آخر حضور للطالب"""
        try:
            last_present = AttendanceRecord.objects.filter(
                student=student,
                status='present'
            ).order_by('-session__date').first()
            
            return last_present.session.date if last_present else None
            
        except Exception as e:
            logger.error(f"خطأ في جلب تاريخ آخر حضور للطالب {student.id}: {e}")
            return None
    
    def get_total_absences(self, student):
        """إجمالي أيام الغياب في الشهر الماضي"""
        try:
            return AttendanceRecord.objects.filter(
                student=student,
                session__date__gte=self.month_ago,
                status='absent'
            ).count()
            
        except Exception as e:
            logger.error(f"خطأ في حساب إجمالي الغياب للطالب {student.id}: {e}")
            return 0
    
    def calculate_priority(self, attendance_rate, consecutive_absences, trend):
        """حساب أولوية التدخل"""
        priority_score = 0
        
        # نقاط بناءً على معدل الحضور
        if attendance_rate < 50:
            priority_score += 10
        elif attendance_rate < 70:
            priority_score += 7
        elif attendance_rate < 85:
            priority_score += 4
        
        # نقاط بناءً على الغياب المتتالي
        if consecutive_absences >= 5:
            priority_score += 8
        elif consecutive_absences >= 3:
            priority_score += 5
        elif consecutive_absences >= 2:
            priority_score += 2
        
        # نقاط بناءً على الاتجاه
        if trend == 'declining':
            priority_score += 3
        elif trend == 'improving':
            priority_score -= 1
        
        # تحديد مستوى الأولوية
        if priority_score >= 15:
            return 'critical'
        elif priority_score >= 10:
            return 'high'
        elif priority_score >= 5:
            return 'medium'
        else:
            return 'low'
    
    def generate_recommendations(self, attendance_rate, consecutive_absences, trend):
        """توليد التوصيات للتدخل"""
        recommendations = []
        
        if attendance_rate < 60:
            recommendations.append("تواصل فوري مع ولي الأمر")
            recommendations.append("جدولة اجتماع مع المرشد الطلابي")
        elif attendance_rate < 75:
            recommendations.append("إرسال تنبيه لولي الأمر")
            recommendations.append("متابعة أسبوعية مع المعلم")
        
        if consecutive_absences >= 3:
            recommendations.append("التحقق من الأسباب الصحية أو الشخصية")
        
        if trend == 'declining':
            recommendations.append("تحليل العوامل المؤثرة على تراجع الحضور")
        
        if not recommendations:
            recommendations.append("متابعة دورية للحفاظ على المستوى الجيد")
        
        return recommendations
    
    def get_at_risk_students(self, classroom=None, limit=None):
        """جلب قائمة الطلاب المعرضين للخطر"""
        try:
            students_query = Student.objects.filter(is_active=True)
            
            if classroom:
                students_query = students_query.filter(classroom=classroom)
            
            at_risk_students = []
            
            for student in students_query:
                analysis = self.analyze_student_risk(student)
                if analysis and analysis['warning_level'] in ['orange', 'red']:
                    at_risk_students.append(analysis)
            
            # ترتيب حسب الأولوية ومعدل الحضور
            priority_order = {'critical': 4, 'high': 3, 'medium': 2, 'low': 1}
            at_risk_students.sort(
                key=lambda x: (priority_order.get(x['priority'], 0), -x['monthly_rate']),
                reverse=True
            )
            
            if limit:
                at_risk_students = at_risk_students[:limit]
            
            return at_risk_students
            
        except Exception as e:
            logger.error(f"خطأ في جلب الطلاب المعرضين للخطر: {e}")
            return []
    
    def send_warning_notifications(self, student_analysis):
        """إرسال تنبيهات للمعنيين"""
        try:
            student = student_analysis['student']
            warning_level = student_analysis['warning_level']
            monthly_rate = student_analysis['monthly_rate']
            
            # تحديد المستلمين
            recipients = []
            
            # إضافة المعلمين
            teachers = User.objects.filter(
                role='teacher',
                teacher_profile__classrooms=student.classroom
            )
            recipients.extend(teachers)
            
            # إضافة ولي الأمر
            if student.parent:
                recipients.append(student.parent)
            
            # إضافة المديرين
            admins = User.objects.filter(role__in=['admin', 'manager'])
            recipients.extend(admins)
            
            # إنشاء الإشعارات
            for recipient in recipients:
                notification_type = 'urgent' if warning_level == 'red' else 'attendance'
                
                title = f"تحذير: انخفاض حضور الطالب {student.user.get_full_name()}"
                message = f"""
                الطالب: {student.user.get_full_name()}
                رقم الطالب: {student.student_id}
                الفصل: {student.classroom.name}
                معدل الحضور الشهري: {monthly_rate}%
                مستوى التحذير: {student_analysis['level_config']['label']}
                
                التوصيات:
                {chr(10).join(f"• {rec}" for rec in student_analysis['recommendations'])}
                """
                
                Notification.objects.create(
                    title=title,
                    message=message,
                    recipient=recipient,
                    sender=User.objects.filter(role='admin').first(),
                    notification_type=notification_type
                )
            
            logger.info(f"تم إرسال تنبيهات للطالب {student.id}")
            return True
            
        except Exception as e:
            logger.error(f"خطأ في إرسال التنبيهات: {e}")
            return False
    
    def generate_daily_report(self):
        """توليد تقرير يومي للطلاب المعرضين للخطر"""
        try:
            at_risk_students = self.get_at_risk_students()
            
            report_data = {
                'date': self.today,
                'total_at_risk': len(at_risk_students),
                'critical_count': len([s for s in at_risk_students if s['priority'] == 'critical']),
                'high_count': len([s for s in at_risk_students if s['priority'] == 'high']),
                'medium_count': len([s for s in at_risk_students if s['priority'] == 'medium']),
                'students': at_risk_students
            }
            
            return report_data
            
        except Exception as e:
            logger.error(f"خطأ في توليد التقرير اليومي: {e}")
            return None


def run_daily_warning_check():
    """تشغيل فحص التحذيرات اليومي"""
    try:
        ews = EarlyWarningSystem()
        at_risk_students = ews.get_at_risk_students()
        
        notifications_sent = 0
        for student_analysis in at_risk_students:
            if student_analysis['priority'] in ['critical', 'high']:
                if ews.send_warning_notifications(student_analysis):
                    notifications_sent += 1
        
        logger.info(f"تم إرسال {notifications_sent} تنبيه للطلاب المعرضين للخطر")
        return notifications_sent
        
    except Exception as e:
        logger.error(f"خطأ في تشغيل فحص التحذيرات اليومي: {e}")
        return 0

