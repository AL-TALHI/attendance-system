from django.db import models
from django.contrib.auth.models import User
from .models import User as CustomUser


class Permission(models.Model):
    """نموذج الصلاحيات"""
    name = models.CharField(max_length=100, unique=True, verbose_name="اسم الصلاحية")
    codename = models.CharField(max_length=100, unique=True, verbose_name="الرمز")
    description = models.TextField(blank=True, verbose_name="الوصف")
    category = models.CharField(max_length=50, verbose_name="الفئة")
    is_active = models.BooleanField(default=True, verbose_name="نشط")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "صلاحية"
        verbose_name_plural = "الصلاحيات"
        ordering = ['category', 'name']

    def __str__(self):
        return f"{self.name} ({self.category})"


class Role(models.Model):
    """نموذج الأدوار"""
    name = models.CharField(max_length=100, unique=True, verbose_name="اسم الدور")
    description = models.TextField(blank=True, verbose_name="الوصف")
    permissions = models.ManyToManyField(Permission, blank=True, verbose_name="الصلاحيات")
    is_active = models.BooleanField(default=True, verbose_name="نشط")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "دور"
        verbose_name_plural = "الأدوار"
        ordering = ['name']

    def __str__(self):
        return self.name


class UserPermission(models.Model):
    """نموذج صلاحيات المستخدم"""
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, verbose_name="المستخدم")
    permission = models.ForeignKey(Permission, on_delete=models.CASCADE, verbose_name="الصلاحية")
    granted_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, related_name='granted_permissions', verbose_name="منح بواسطة")
    granted_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ المنح")
    expires_at = models.DateTimeField(null=True, blank=True, verbose_name="تاريخ الانتهاء")
    is_active = models.BooleanField(default=True, verbose_name="نشط")

    class Meta:
        verbose_name = "صلاحية المستخدم"
        verbose_name_plural = "صلاحيات المستخدمين"
        unique_together = ['user', 'permission']

    def __str__(self):
        return f"{self.user} - {self.permission}"


class UserRole(models.Model):
    """نموذج أدوار المستخدم"""
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, verbose_name="المستخدم")
    role = models.ForeignKey(Role, on_delete=models.CASCADE, verbose_name="الدور")
    assigned_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, related_name='assigned_roles', verbose_name="تم التعيين بواسطة")
    assigned_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ التعيين")
    expires_at = models.DateTimeField(null=True, blank=True, verbose_name="تاريخ الانتهاء")
    is_active = models.BooleanField(default=True, verbose_name="نشط")

    class Meta:
        verbose_name = "دور المستخدم"
        verbose_name_plural = "أدوار المستخدمين"
        unique_together = ['user', 'role']

    def __str__(self):
        return f"{self.user} - {self.role}"


class PermissionLog(models.Model):
    """سجل تغييرات الصلاحيات"""
    ACTION_CHOICES = [
        ('grant', 'منح'),
        ('revoke', 'إلغاء'),
        ('modify', 'تعديل'),
    ]
    
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='permission_logs', verbose_name="المستخدم")
    permission = models.ForeignKey(Permission, on_delete=models.CASCADE, verbose_name="الصلاحية")
    action = models.CharField(max_length=20, choices=ACTION_CHOICES, verbose_name="الإجراء")
    performed_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, related_name='performed_permission_changes', verbose_name="تم بواسطة")
    reason = models.TextField(blank=True, verbose_name="السبب")
    timestamp = models.DateTimeField(auto_now_add=True, verbose_name="الوقت")
    ip_address = models.GenericIPAddressField(null=True, blank=True, verbose_name="عنوان IP")

    class Meta:
        verbose_name = "سجل الصلاحيات"
        verbose_name_plural = "سجلات الصلاحيات"
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.get_action_display()} {self.permission} لـ {self.user} في {self.timestamp}"

