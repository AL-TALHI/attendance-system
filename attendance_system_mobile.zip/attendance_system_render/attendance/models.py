from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone


class User(AbstractUser):
    """نموذج المستخدم المخصص"""
    ROLE_CHOICES = [
        ('admin', 'مدير النظام'),
        ('manager', 'مدير'),
        ('teacher', 'معلم'),
        ('student', 'طالب'),
        ('parent', 'ولي أمر'),
    ]
    
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='student')
    phone = models.CharField(max_length=15, blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    date_of_birth = models.DateField(blank=True, null=True)
    profile_picture = models.ImageField(upload_to='profiles/', blank=True, null=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "مستخدم"
        verbose_name_plural = "المستخدمون"

    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.get_role_display()})"


class School(models.Model):
    """نموذج المدرسة"""
    name = models.CharField(max_length=200)
    address = models.TextField()
    phone = models.CharField(max_length=15)
    email = models.EmailField()
    principal = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='schools_as_principal')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "مدرسة"
        verbose_name_plural = "المدارس"

    def __str__(self):
        return self.name


class Grade(models.Model):
    """نموذج الصف الدراسي"""
    name = models.CharField(max_length=50)  # مثل: الصف الأول، الصف الثاني
    level = models.IntegerField()  # 1, 2, 3, ...
    school = models.ForeignKey(School, on_delete=models.CASCADE, related_name='grades')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['name', 'school']
        ordering = ['level']
        verbose_name = "صف دراسي"
        verbose_name_plural = "الصفوف الدراسية"

    def __str__(self):
        return f"{self.name} - {self.school.name}"


class Subject(models.Model):
    """نموذج المادة الدراسية"""
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=10, unique=True)
    description = models.TextField(blank=True, null=True)
    credit_hours = models.IntegerField(default=1)
    school = models.ForeignKey(School, on_delete=models.CASCADE, related_name='subjects')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "مادة دراسية"
        verbose_name_plural = "المواد الدراسية"

    def __str__(self):
        return f"{self.name} ({self.code})"


class Classroom(models.Model):
    """نموذج الفصل الدراسي"""
    name = models.CharField(max_length=50)  # مثل: فصل 1أ، فصل 2ب
    grade = models.ForeignKey(Grade, on_delete=models.CASCADE, related_name='classrooms')
    capacity = models.IntegerField(default=30)
    room_number = models.CharField(max_length=20, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['name', 'grade']
        verbose_name = "فصل دراسي"
        verbose_name_plural = "الفصول الدراسية"

    def __str__(self):
        return f"{self.name} - {self.grade.name}"


class Teacher(models.Model):
    """نموذج المعلم"""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='teacher_profile')
    employee_id = models.CharField(max_length=20, unique=True)
    subjects = models.ManyToManyField(Subject, related_name='teachers')
    classrooms = models.ManyToManyField(Classroom, through='TeacherClassroom', related_name='teachers')
    hire_date = models.DateField()
    salary = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    qualification = models.CharField(max_length=100, blank=True, null=True)
    
    def __str__(self):
        return f"المعلم {self.user.first_name} {self.user.last_name}"


class TeacherClassroom(models.Model):
    """نموذج ربط المعلم بالفصل والمادة"""
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE)
    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    academic_year = models.CharField(max_length=9)  # مثل: 2024-2025
    is_primary = models.BooleanField(default=False)  # معلم أساسي أم مساعد
    
    class Meta:
        unique_together = ['teacher', 'classroom', 'subject', 'academic_year']

    def __str__(self):
        return f"{self.teacher} - {self.classroom} - {self.subject}"


class Student(models.Model):
    """نموذج الطالب"""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='student_profile')
    student_id = models.CharField(max_length=20, unique=True)
    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE, related_name='students')
    parent = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='children')
    enrollment_date = models.DateField()
    graduation_date = models.DateField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return f"الطالب {self.user.first_name} {self.user.last_name} - {self.student_id}"


class AttendanceSession(models.Model):
    """نموذج جلسة الحضور"""
    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE, related_name='attendance_sessions')
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='attendance_sessions')
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE, related_name='attendance_sessions')
    date = models.DateField()
    start_time = models.TimeField()
    end_time = models.TimeField()
    session_type = models.CharField(max_length=20, choices=[
        ('regular', 'حصة عادية'),
        ('exam', 'امتحان'),
        ('activity', 'نشاط'),
        ('makeup', 'حصة تعويضية'),
    ], default='regular')
    notes = models.TextField(blank=True, null=True)
    is_completed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ['classroom', 'subject', 'date', 'start_time']
        ordering = ['-date', '-start_time']

    def __str__(self):
        return f"{self.classroom} - {self.subject} - {self.date}"


class AttendanceRecord(models.Model):
    """نموذج سجل الحضور"""
    ATTENDANCE_CHOICES = [
        ('present', 'حاضر'),
        ('absent', 'غائب'),
        ('late', 'متأخر'),
        ('excused', 'غائب بعذر'),
    ]
    
    session = models.ForeignKey(AttendanceSession, on_delete=models.CASCADE, related_name='attendance_records')
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='attendance_records')
    status = models.CharField(max_length=10, choices=ATTENDANCE_CHOICES, default='present')
    arrival_time = models.TimeField(blank=True, null=True)
    notes = models.TextField(blank=True, null=True)
    recorded_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='recorded_attendances')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ['session', 'student']
        ordering = ['-session__date', 'student__user__first_name']

    def __str__(self):
        return f"{self.student} - {self.session} - {self.get_status_display()}"


class AttendanceReport(models.Model):
    """نموذج تقرير الحضور"""
    title = models.CharField(max_length=200)
    report_type = models.CharField(max_length=20, choices=[
        ('daily', 'يومي'),
        ('weekly', 'أسبوعي'),
        ('monthly', 'شهري'),
        ('custom', 'مخصص'),
    ])
    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE, blank=True, null=True)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, blank=True, null=True)
    student = models.ForeignKey(Student, on_delete=models.CASCADE, blank=True, null=True)
    start_date = models.DateField()
    end_date = models.DateField()
    generated_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='generated_reports')
    file_path = models.FileField(upload_to='reports/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.title} - {self.get_report_type_display()}"


class Notification(models.Model):
    """نموذج الإشعارات"""
    title = models.CharField(max_length=200)
    message = models.TextField()
    recipient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_notifications')
    notification_type = models.CharField(max_length=20, choices=[
        ('attendance', 'حضور وغياب'),
        ('grade', 'درجات'),
        ('general', 'عام'),
        ('urgent', 'عاجل'),
    ])
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.title} - {self.recipient}"



class ReportTemplate(models.Model):
    """قوالب التقارير المخصصة"""
    name = models.CharField(max_length=200, verbose_name="اسم القالب")
    description = models.TextField(blank=True, verbose_name="الوصف")
    report_type = models.CharField(max_length=30, choices=[
        ('admin_general', 'تقرير إداري عام'),
        ('admin_attendance', 'تقرير حضور شامل'),
        ('admin_performance', 'تقرير أداء'),
        ('teacher_class', 'تقرير فصل المعلم'),
        ('teacher_subject', 'تقرير مادة المعلم'),
        ('teacher_student', 'تقرير طالب للمعلم'),
        ('student_personal', 'تقرير شخصي للطالب'),
        ('student_grades', 'تقرير درجات الطالب'),
        ('parent_child', 'تقرير ولي الأمر'),
        ('parent_summary', 'ملخص ولي الأمر'),
    ], verbose_name="نوع التقرير")
    
    target_roles = models.JSONField(default=list, verbose_name="الأدوار المستهدفة")
    fields_config = models.JSONField(default=dict, verbose_name="إعدادات الحقول")
    chart_config = models.JSONField(default=dict, verbose_name="إعدادات الرسوم البيانية")
    
    is_active = models.BooleanField(default=True, verbose_name="نشط")
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="منشئ القالب")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ الإنشاء")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="تاريخ التحديث")

    class Meta:
        verbose_name = "قالب تقرير"
        verbose_name_plural = "قوالب التقارير"
        ordering = ['-created_at']

    def __str__(self):
        return self.name


class ScheduledReport(models.Model):
    """التقارير المجدولة"""
    name = models.CharField(max_length=200, verbose_name="اسم التقرير")
    template = models.ForeignKey(ReportTemplate, on_delete=models.CASCADE, verbose_name="قالب التقرير")
    
    # إعدادات الجدولة
    schedule_type = models.CharField(max_length=20, choices=[
        ('daily', 'يومي'),
        ('weekly', 'أسبوعي'),
        ('monthly', 'شهري'),
        ('custom', 'مخصص'),
    ], verbose_name="نوع الجدولة")
    
    schedule_time = models.TimeField(verbose_name="وقت التنفيذ")
    schedule_days = models.JSONField(default=list, verbose_name="أيام التنفيذ")  # للجدولة الأسبوعية
    schedule_date = models.IntegerField(null=True, blank=True, verbose_name="تاريخ الشهر")  # للجدولة الشهرية
    
    # المستلمون
    recipients = models.ManyToManyField(User, verbose_name="المستلمون")
    email_recipients = models.JSONField(default=list, verbose_name="مستلمو البريد الإلكتروني")
    
    # إعدادات التقرير
    filters = models.JSONField(default=dict, verbose_name="فلاتر التقرير")
    export_formats = models.JSONField(default=list, verbose_name="صيغ التصدير")  # ['pdf', 'excel', 'csv']
    
    is_active = models.BooleanField(default=True, verbose_name="نشط")
    last_run = models.DateTimeField(null=True, blank=True, verbose_name="آخر تشغيل")
    next_run = models.DateTimeField(null=True, blank=True, verbose_name="التشغيل التالي")
    
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_scheduled_reports', verbose_name="منشئ الجدولة")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ الإنشاء")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="تاريخ التحديث")

    class Meta:
        verbose_name = "تقرير مجدول"
        verbose_name_plural = "التقارير المجدولة"
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.name} - {self.get_schedule_type_display()}"


class ReportExecution(models.Model):
    """سجل تنفيذ التقارير"""
    scheduled_report = models.ForeignKey(ScheduledReport, on_delete=models.CASCADE, null=True, blank=True, verbose_name="التقرير المجدول")
    template = models.ForeignKey(ReportTemplate, on_delete=models.CASCADE, verbose_name="قالب التقرير")
    
    executed_by = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="منفذ التقرير")
    execution_time = models.DateTimeField(auto_now_add=True, verbose_name="وقت التنفيذ")
    
    # معايير التقرير
    filters_used = models.JSONField(default=dict, verbose_name="الفلاتر المستخدمة")
    date_range = models.JSONField(default=dict, verbose_name="النطاق الزمني")
    
    # النتائج
    status = models.CharField(max_length=20, choices=[
        ('pending', 'قيد الانتظار'),
        ('running', 'قيد التنفيذ'),
        ('completed', 'مكتمل'),
        ('failed', 'فشل'),
    ], default='pending', verbose_name="الحالة")
    
    file_path = models.FileField(upload_to='reports/executions/', null=True, blank=True, verbose_name="مسار الملف")
    file_size = models.IntegerField(null=True, blank=True, verbose_name="حجم الملف")
    records_count = models.IntegerField(null=True, blank=True, verbose_name="عدد السجلات")
    
    error_message = models.TextField(blank=True, verbose_name="رسالة الخطأ")
    execution_duration = models.DurationField(null=True, blank=True, verbose_name="مدة التنفيذ")

    class Meta:
        verbose_name = "تنفيذ تقرير"
        verbose_name_plural = "سجل تنفيذ التقارير"
        ordering = ['-execution_time']

    def __str__(self):
        return f"{self.template.name} - {self.execution_time.strftime('%Y-%m-%d %H:%M')}"


class UserReportPreference(models.Model):
    """تفضيلات المستخدم للتقارير"""
    user = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name="المستخدم")
    
    # تفضيلات العرض
    default_date_range = models.CharField(max_length=20, choices=[
        ('week', 'أسبوع'),
        ('month', 'شهر'),
        ('quarter', 'ربع سنة'),
        ('year', 'سنة'),
        ('custom', 'مخصص'),
    ], default='month', verbose_name="النطاق الزمني الافتراضي")
    
    preferred_export_format = models.CharField(max_length=10, choices=[
        ('pdf', 'PDF'),
        ('excel', 'Excel'),
        ('csv', 'CSV'),
    ], default='pdf', verbose_name="صيغة التصدير المفضلة")
    
    # إعدادات الإشعارات
    email_reports = models.BooleanField(default=False, verbose_name="إرسال التقارير بالبريد")
    notification_frequency = models.CharField(max_length=20, choices=[
        ('immediate', 'فوري'),
        ('daily', 'يومي'),
        ('weekly', 'أسبوعي'),
        ('monthly', 'شهري'),
    ], default='weekly', verbose_name="تكرار الإشعارات")
    
    # تفضيلات الرسوم البيانية
    chart_preferences = models.JSONField(default=dict, verbose_name="تفضيلات الرسوم البيانية")
    
    # التقارير المفضلة
    favorite_reports = models.ManyToManyField(ReportTemplate, blank=True, verbose_name="التقارير المفضلة")
    
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ الإنشاء")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="تاريخ التحديث")

    class Meta:
        verbose_name = "تفضيلات التقارير"
        verbose_name_plural = "تفضيلات التقارير"

    def __str__(self):
        return f"تفضيلات {self.user.get_full_name()}"


class ReportComment(models.Model):
    """تعليقات على التقارير"""
    execution = models.ForeignKey(ReportExecution, on_delete=models.CASCADE, related_name='comments', verbose_name="تنفيذ التقرير")
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="المستخدم")
    
    comment = models.TextField(verbose_name="التعليق")
    is_private = models.BooleanField(default=False, verbose_name="تعليق خاص")
    
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ الإنشاء")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="تاريخ التحديث")

    class Meta:
        verbose_name = "تعليق تقرير"
        verbose_name_plural = "تعليقات التقارير"
        ordering = ['-created_at']

    def __str__(self):
        return f"تعليق {self.user.get_full_name()} على {self.execution.template.name}"



# نماذج الجداول الدراسية
class TimeSlot(models.Model):
    """فترة زمنية للحصص الدراسية"""
    name = models.CharField(max_length=100, verbose_name="اسم الفترة")
    start_time = models.TimeField(verbose_name="وقت البداية")
    end_time = models.TimeField(verbose_name="وقت النهاية")
    duration_minutes = models.PositiveIntegerField(verbose_name="المدة بالدقائق")
    is_break = models.BooleanField(default=False, verbose_name="فترة استراحة")
    order = models.PositiveIntegerField(default=1, verbose_name="الترتيب")
    is_active = models.BooleanField(default=True, verbose_name="نشط")
    
    class Meta:
        verbose_name = "فترة زمنية"
        verbose_name_plural = "الفترات الزمنية"
        ordering = ['order', 'start_time']
    
    def __str__(self):
        return f"{self.name} ({self.start_time.strftime('%H:%M')} - {self.end_time.strftime('%H:%M')})"

class Schedule(models.Model):
    """الجدول الدراسي"""
    SCHEDULE_TYPES = [
        ('weekly', 'أسبوعي'),
        ('daily', 'يومي'),
        ('custom', 'مخصص'),
    ]
    
    name = models.CharField(max_length=200, verbose_name="اسم الجدول")
    description = models.TextField(blank=True, verbose_name="الوصف")
    schedule_type = models.CharField(max_length=20, choices=SCHEDULE_TYPES, default='weekly', verbose_name="نوع الجدول")
    academic_year = models.CharField(max_length=20, verbose_name="العام الدراسي")
    semester = models.CharField(max_length=50, verbose_name="الفصل الدراسي")
    start_date = models.DateField(verbose_name="تاريخ البداية")
    end_date = models.DateField(verbose_name="تاريخ النهاية")
    is_active = models.BooleanField(default=True, verbose_name="نشط")
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="أنشأ بواسطة")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ الإنشاء")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="تاريخ التحديث")
    
    class Meta:
        verbose_name = "جدول دراسي"
        verbose_name_plural = "الجداول الدراسية"
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.name} - {self.academic_year}"

class ScheduleSlot(models.Model):
    """حصة في الجدول الدراسي"""
    DAYS_OF_WEEK = [
        (1, 'الأحد'),
        (2, 'الاثنين'),
        (3, 'الثلاثاء'),
        (4, 'الأربعاء'),
        (5, 'الخميس'),
        (6, 'الجمعة'),
        (7, 'السبت'),
    ]
    
    schedule = models.ForeignKey(Schedule, on_delete=models.CASCADE, related_name='slots', verbose_name="الجدول")
    day_of_week = models.IntegerField(choices=DAYS_OF_WEEK, verbose_name="يوم الأسبوع")
    time_slot = models.ForeignKey(TimeSlot, on_delete=models.CASCADE, verbose_name="الفترة الزمنية")
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, verbose_name="المادة")
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE, verbose_name="المعلم")
    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE, verbose_name="الفصل")
    room_number = models.CharField(max_length=50, blank=True, verbose_name="رقم القاعة")
    notes = models.TextField(blank=True, verbose_name="ملاحظات")
    is_active = models.BooleanField(default=True, verbose_name="نشط")
    
    class Meta:
        verbose_name = "حصة دراسية"
        verbose_name_plural = "الحصص الدراسية"
        unique_together = [
            ['schedule', 'day_of_week', 'time_slot', 'classroom'],  # منع التضارب في الفصل
            ['schedule', 'day_of_week', 'time_slot', 'teacher'],    # منع التضارب للمعلم
        ]
        ordering = ['day_of_week', 'time_slot__order']
    
    def __str__(self):
        return f"{self.get_day_of_week_display()} - {self.time_slot.name} - {self.subject.name}"
    
    def get_day_name(self):
        return self.get_day_of_week_display()
    
    def get_time_range(self):
        return f"{self.time_slot.start_time.strftime('%H:%M')} - {self.time_slot.end_time.strftime('%H:%M')}"

class ScheduleTemplate(models.Model):
    """قالب الجدول الدراسي"""
    name = models.CharField(max_length=200, verbose_name="اسم القالب")
    description = models.TextField(blank=True, verbose_name="الوصف")
    grade = models.ForeignKey(Grade, on_delete=models.CASCADE, blank=True, null=True, verbose_name="الصف")
    is_default = models.BooleanField(default=False, verbose_name="قالب افتراضي")
    is_active = models.BooleanField(default=True, verbose_name="نشط")
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="أنشأ بواسطة")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ الإنشاء")
    
    class Meta:
        verbose_name = "قالب جدول"
        verbose_name_plural = "قوالب الجداول"
        ordering = ['-created_at']
    
    def __str__(self):
        return self.name

class ScheduleConflict(models.Model):
    """تضارب في الجداول الدراسية"""
    CONFLICT_TYPES = [
        ('teacher_double_booking', 'المعلم محجوز في نفس الوقت'),
        ('classroom_double_booking', 'الفصل محجوز في نفس الوقت'),
        ('student_overload', 'الطلاب محملون بحصص كثيرة'),
        ('time_overlap', 'تداخل في الأوقات'),
    ]
    
    schedule = models.ForeignKey(Schedule, on_delete=models.CASCADE, verbose_name="الجدول")
    conflict_type = models.CharField(max_length=50, choices=CONFLICT_TYPES, verbose_name="نوع التضارب")
    description = models.TextField(verbose_name="وصف التضارب")
    slot1 = models.ForeignKey(ScheduleSlot, on_delete=models.CASCADE, related_name='conflicts_as_slot1', verbose_name="الحصة الأولى")
    slot2 = models.ForeignKey(ScheduleSlot, on_delete=models.CASCADE, related_name='conflicts_as_slot2', blank=True, null=True, verbose_name="الحصة الثانية")
    is_resolved = models.BooleanField(default=False, verbose_name="تم الحل")
    resolution_notes = models.TextField(blank=True, verbose_name="ملاحظات الحل")
    detected_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ الاكتشاف")
    resolved_at = models.DateTimeField(blank=True, null=True, verbose_name="تاريخ الحل")
    
    class Meta:
        verbose_name = "تضارب في الجدول"
        verbose_name_plural = "التضاربات في الجداول"
        ordering = ['-detected_at']
    
    def __str__(self):
        return f"{self.get_conflict_type_display()} - {self.schedule.name}"

class UserSchedulePreference(models.Model):
    """تفضيلات المستخدم للجداول"""
    user = models.OneToOneField(User, on_delete=models.CASCADE, verbose_name="المستخدم")
    default_view = models.CharField(max_length=20, choices=[
        ('weekly', 'أسبوعي'),
        ('daily', 'يومي'),
        ('monthly', 'شهري'),
    ], default='weekly', verbose_name="العرض الافتراضي")
    show_room_numbers = models.BooleanField(default=True, verbose_name="عرض أرقام القاعات")
    show_teacher_names = models.BooleanField(default=True, verbose_name="عرض أسماء المعلمين")
    show_break_times = models.BooleanField(default=True, verbose_name="عرض أوقات الاستراحة")
    email_notifications = models.BooleanField(default=True, verbose_name="إشعارات البريد الإلكتروني")
    schedule_reminders = models.BooleanField(default=True, verbose_name="تذكيرات الجدول")
    reminder_minutes = models.PositiveIntegerField(default=15, verbose_name="دقائق التذكير")
    
    class Meta:
        verbose_name = "تفضيلات الجدول"
        verbose_name_plural = "تفضيلات الجداول"
    
    def __str__(self):
        return f"تفضيلات {self.user.get_full_name()}"




class Parent(models.Model):
    """نموذج ولي الأمر"""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='parent_profile')
    children = models.ManyToManyField(Student, related_name='parents')
    phone_number = models.CharField(max_length=15, blank=True, null=True)
    
    def __str__(self):
        return f"ولي الأمر {self.user.first_name} {self.user.last_name}"




# نماذج الصلاحيات
class Permission(models.Model):
    """نموذج الصلاحيات"""
    name = models.CharField(max_length=100, unique=True, verbose_name="اسم الصلاحية")
    codename = models.CharField(max_length=100, unique=True, verbose_name="الرمز")
    description = models.TextField(blank=True, verbose_name="الوصف")
    category = models.CharField(max_length=50, verbose_name="الفئة")
    is_active = models.BooleanField(default=True, verbose_name="نشط")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "صلاحية"
        verbose_name_plural = "الصلاحيات"
        ordering = ['category', 'name']

    def __str__(self):
        return f"{self.name} ({self.category})"


class Role(models.Model):
    """نموذج الأدوار"""
    name = models.CharField(max_length=100, unique=True, verbose_name="اسم الدور")
    description = models.TextField(blank=True, verbose_name="الوصف")
    permissions = models.ManyToManyField(Permission, blank=True, verbose_name="الصلاحيات")
    is_active = models.BooleanField(default=True, verbose_name="نشط")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "دور"
        verbose_name_plural = "الأدوار"
        ordering = ['name']

    def __str__(self):
        return self.name


class UserPermission(models.Model):
    """نموذج صلاحيات المستخدم"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="المستخدم")
    permission = models.ForeignKey(Permission, on_delete=models.CASCADE, verbose_name="الصلاحية")
    granted_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='granted_permissions', verbose_name="منح بواسطة")
    granted_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ المنح")
    expires_at = models.DateTimeField(null=True, blank=True, verbose_name="تاريخ الانتهاء")
    is_active = models.BooleanField(default=True, verbose_name="نشط")

    class Meta:
        verbose_name = "صلاحية المستخدم"
        verbose_name_plural = "صلاحيات المستخدمين"
        unique_together = ['user', 'permission']

    def __str__(self):
        return f"{self.user} - {self.permission}"


class UserRole(models.Model):
    """نموذج أدوار المستخدم"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="المستخدم")
    role = models.ForeignKey(Role, on_delete=models.CASCADE, verbose_name="الدور")
    assigned_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='assigned_roles', verbose_name="تم التعيين بواسطة")
    assigned_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ التعيين")
    expires_at = models.DateTimeField(null=True, blank=True, verbose_name="تاريخ الانتهاء")
    is_active = models.BooleanField(default=True, verbose_name="نشط")

    class Meta:
        verbose_name = "دور المستخدم"
        verbose_name_plural = "أدوار المستخدمين"
        unique_together = ['user', 'role']

    def __str__(self):
        return f"{self.user} - {self.role}"


class PermissionLog(models.Model):
    """سجل تغييرات الصلاحيات"""
    ACTION_CHOICES = [
        ('grant', 'منح'),
        ('revoke', 'إلغاء'),
        ('modify', 'تعديل'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='permission_logs', verbose_name="المستخدم")
    permission = models.ForeignKey(Permission, on_delete=models.CASCADE, verbose_name="الصلاحية")
    action = models.CharField(max_length=20, choices=ACTION_CHOICES, verbose_name="الإجراء")
    performed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='performed_permission_changes', verbose_name="تم بواسطة")
    reason = models.TextField(blank=True, verbose_name="السبب")
    timestamp = models.DateTimeField(auto_now_add=True, verbose_name="الوقت")
    ip_address = models.GenericIPAddressField(null=True, blank=True, verbose_name="عنوان IP")

    class Meta:
        verbose_name = "سجل الصلاحيات"
        verbose_name_plural = "سجلات الصلاحيات"
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.get_action_display()} {self.permission} لـ {self.user} في {self.timestamp}"

