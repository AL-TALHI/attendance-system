from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.utils.translation import gettext_lazy as _
from .models import (
    User, School, Grade, Subject, Classroom, Teacher, TeacherClassroom,
    Student, AttendanceSession, AttendanceRecord, AttendanceReport, Notification
)


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    """إدارة المستخدمين في لوحة الإدارة"""
    list_display = ('username', 'first_name', 'last_name', 'email', 'role', 'is_active', 'date_joined')
    list_filter = ('role', 'is_active', 'is_staff', 'is_superuser', 'date_joined')
    search_fields = ('username', 'first_name', 'last_name', 'email', 'phone')
    ordering = ('-date_joined',)
    
    fieldsets = BaseUserAdmin.fieldsets + (
        (_('معلومات إضافية'), {
            'fields': ('role', 'phone', 'address', 'date_of_birth', 'profile_picture')
        }),
    )
    
    add_fieldsets = BaseUserAdmin.add_fieldsets + (
        (_('معلومات إضافية'), {
            'fields': ('role', 'phone', 'address', 'date_of_birth', 'profile_picture')
        }),
    )


@admin.register(School)
class SchoolAdmin(admin.ModelAdmin):
    """إدارة المدارس"""
    list_display = ('name', 'principal', 'phone', 'email', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('name', 'phone', 'email')
    ordering = ('name',)


@admin.register(Grade)
class GradeAdmin(admin.ModelAdmin):
    """إدارة الصفوف الدراسية"""
    list_display = ('name', 'level', 'school', 'created_at')
    list_filter = ('level', 'school', 'created_at')
    search_fields = ('name', 'school__name')
    ordering = ('school', 'level')


@admin.register(Subject)
class SubjectAdmin(admin.ModelAdmin):
    """إدارة المواد الدراسية"""
    list_display = ('name', 'code', 'credit_hours', 'school', 'created_at')
    list_filter = ('credit_hours', 'school', 'created_at')
    search_fields = ('name', 'code', 'school__name')
    ordering = ('school', 'name')


@admin.register(Classroom)
class ClassroomAdmin(admin.ModelAdmin):
    """إدارة الفصول الدراسية"""
    list_display = ('name', 'grade', 'capacity', 'room_number', 'created_at')
    list_filter = ('grade__level', 'grade__school', 'created_at')
    search_fields = ('name', 'room_number', 'grade__name')
    ordering = ('grade__school', 'grade__level', 'name')


class TeacherClassroomInline(admin.TabularInline):
    """إدراج فصول المعلم في صفحة تحرير المعلم"""
    model = TeacherClassroom
    extra = 1


@admin.register(Teacher)
class TeacherAdmin(admin.ModelAdmin):
    """إدارة المعلمين"""
    list_display = ('user', 'employee_id', 'hire_date', 'qualification')
    list_filter = ('hire_date', 'qualification')
    search_fields = ('user__first_name', 'user__last_name', 'employee_id')
    ordering = ('user__first_name', 'user__last_name')
    inlines = [TeacherClassroomInline]
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user')


@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    """إدارة الطلاب"""
    list_display = ('user', 'student_id', 'classroom', 'parent', 'enrollment_date', 'is_active')
    list_filter = ('classroom__grade__level', 'classroom__grade__school', 'enrollment_date', 'is_active')
    search_fields = ('user__first_name', 'user__last_name', 'student_id', 'parent__first_name', 'parent__last_name')
    ordering = ('classroom__grade__level', 'classroom__name', 'user__first_name')
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user', 'classroom', 'parent')


class AttendanceRecordInline(admin.TabularInline):
    """إدراج سجلات الحضور في صفحة جلسة الحضور"""
    model = AttendanceRecord
    extra = 0
    readonly_fields = ('created_at', 'updated_at')


@admin.register(AttendanceSession)
class AttendanceSessionAdmin(admin.ModelAdmin):
    """إدارة جلسات الحضور"""
    list_display = ('classroom', 'subject', 'teacher', 'date', 'start_time', 'end_time', 'session_type', 'is_completed')
    list_filter = ('date', 'session_type', 'is_completed', 'classroom__grade__level')
    search_fields = ('classroom__name', 'subject__name', 'teacher__user__first_name', 'teacher__user__last_name')
    ordering = ('-date', '-start_time')
    inlines = [AttendanceRecordInline]
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('classroom', 'subject', 'teacher__user')


@admin.register(AttendanceRecord)
class AttendanceRecordAdmin(admin.ModelAdmin):
    """إدارة سجلات الحضور"""
    list_display = ('student', 'session', 'status', 'arrival_time', 'recorded_by', 'created_at')
    list_filter = ('status', 'session__date', 'session__classroom__grade__level')
    search_fields = ('student__user__first_name', 'student__user__last_name', 'student__student_id')
    ordering = ('-session__date', 'student__user__first_name')
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('student__user', 'session', 'recorded_by')


@admin.register(AttendanceReport)
class AttendanceReportAdmin(admin.ModelAdmin):
    """إدارة تقارير الحضور"""
    list_display = ('title', 'report_type', 'classroom', 'subject', 'student', 'start_date', 'end_date', 'generated_by', 'created_at')
    list_filter = ('report_type', 'start_date', 'end_date', 'created_at')
    search_fields = ('title', 'generated_by__first_name', 'generated_by__last_name')
    ordering = ('-created_at',)
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('classroom', 'subject', 'student', 'generated_by')


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    """إدارة الإشعارات"""
    list_display = ('title', 'recipient', 'sender', 'notification_type', 'is_read', 'created_at')
    list_filter = ('notification_type', 'is_read', 'created_at')
    search_fields = ('title', 'recipient__first_name', 'recipient__last_name', 'sender__first_name', 'sender__last_name')
    ordering = ('-created_at',)
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('recipient', 'sender')


# تخصيص عنوان لوحة الإدارة
admin.site.site_header = "نظام إدارة الحضور والغياب"
admin.site.site_title = "نظام الحضور والغياب"
admin.site.index_title = "لوحة التحكم الرئيسية"

# تعريب أسماء النماذج في لوحة الإدارة
User._meta.verbose_name = "مستخدم"
User._meta.verbose_name_plural = "المستخدمون"

School._meta.verbose_name = "مدرسة"
School._meta.verbose_name_plural = "المدارس"

Grade._meta.verbose_name = "صف دراسي"
Grade._meta.verbose_name_plural = "الصفوف الدراسية"

Subject._meta.verbose_name = "مادة دراسية"
Subject._meta.verbose_name_plural = "المواد الدراسية"

Classroom._meta.verbose_name = "فصل دراسي"
Classroom._meta.verbose_name_plural = "الفصول الدراسية"

Teacher._meta.verbose_name = "معلم"
Teacher._meta.verbose_name_plural = "المعلمون"

Student._meta.verbose_name = "طالب"
Student._meta.verbose_name_plural = "الطلاب"

AttendanceSession._meta.verbose_name = "جلسة حضور"
AttendanceSession._meta.verbose_name_plural = "جلسات الحضور"

AttendanceRecord._meta.verbose_name = "سجل حضور"
AttendanceRecord._meta.verbose_name_plural = "سجلات الحضور"

AttendanceReport._meta.verbose_name = "تقرير حضور"
AttendanceReport._meta.verbose_name_plural = "تقارير الحضور"

Notification._meta.verbose_name = "إشعار"
Notification._meta.verbose_name_plural = "الإشعارات"
