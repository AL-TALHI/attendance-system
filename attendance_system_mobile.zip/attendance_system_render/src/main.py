#!/usr/bin/env python3
"""
نظام إدارة الحضور والغياب - صفحة العرض
"""

from flask import Flask, render_template_string

app = Flask(__name__)

@app.route('/')
def home():
    """الصفحة الرئيسية"""
    return render_template_string('''
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>نظام إدارة الحضور والغياب</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
        <style>
            body { 
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
                min-height: 100vh;
            }
            .hero { 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                color: white; 
                padding: 4rem 0; 
                border-radius: 0 0 50px 50px;
                margin-bottom: 3rem;
            }
            .feature-card { 
                transition: all 0.3s ease;
                border: none;
                box-shadow: 0 5px 15px rgba(0,0,0,0.1);
                border-radius: 15px;
            }
            .feature-card:hover { 
                transform: translateY(-10px);
                box-shadow: 0 15px 30px rgba(0,0,0,0.2);
            }
            .demo-btn {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                border: none;
                padding: 15px 30px;
                border-radius: 50px;
                color: white;
                font-weight: bold;
                text-decoration: none;
                display: inline-block;
                transition: all 0.3s ease;
                box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
            }
            .demo-btn:hover {
                transform: translateY(-3px);
                box-shadow: 0 10px 25px rgba(102, 126, 234, 0.6);
                color: white;
            }
            .stats-card {
                background: white;
                border-radius: 15px;
                padding: 2rem;
                text-align: center;
                box-shadow: 0 5px 15px rgba(0,0,0,0.1);
                margin-bottom: 2rem;
            }
            .stats-number {
                font-size: 3rem;
                font-weight: bold;
                color: #667eea;
            }
            .feature-icon {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                width: 80px;
                height: 80px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                margin: 0 auto 1rem;
                font-size: 2rem;
            }
        </style>
    </head>
    <body>
        <div class="hero text-center">
            <div class="container">
                <h1 class="display-3 mb-4">
                    <i class="fas fa-graduation-cap me-3"></i>
                    نظام إدارة الحضور والغياب
                </h1>
                <p class="lead mb-4">نظام متطور وشامل لإدارة الحضور والغياب في المؤسسات التعليمية مع ميزات الذكاء الاصطناعي</p>
                <a href="/login/" 
                   class="demo-btn">
                    <i class="fas fa-rocket me-2"></i>
                    تجربة النظام المباشر
                </a>
            </div>
        </div>
        
        <div class="container">
            <!-- إحصائيات النظام -->
            <div class="row mb-5">
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-number">259</div>
                        <h6>طالب مسجل</h6>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-number">15</div>
                        <h6>معلم</h6>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-number">12</div>
                        <h6>فصل دراسي</h6>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-number">100%</div>
                        <h6>معدل الأداء</h6>
                    </div>
                </div>
            </div>

            <!-- الميزات الرئيسية -->
            <div class="row mb-5">
                <div class="col-md-4 mb-4">
                    <div class="card feature-card h-100">
                        <div class="card-body text-center">
                            <div class="feature-icon">
                                <i class="fas fa-users"></i>
                            </div>
                            <h5 class="card-title">إدارة شاملة</h5>
                            <p class="card-text">إدارة متكاملة للطلاب والمعلمين وأولياء الأمور مع واجهات مخصصة لكل دور</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card feature-card h-100">
                        <div class="card-body text-center">
                            <div class="feature-icon">
                                <i class="fas fa-chart-line"></i>
                            </div>
                            <h5 class="card-title">تقارير تفاعلية</h5>
                            <p class="card-text">رسوم بيانية متقدمة وتقارير تفصيلية مع إمكانية التصدير لـ Excel و PDF</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card feature-card h-100">
                        <div class="card-body text-center">
                            <div class="feature-icon">
                                <i class="fas fa-exclamation-triangle"></i>
                            </div>
                            <h5 class="card-title">إنذار مبكر ذكي</h5>
                            <p class="card-text">نظام ذكي لمتابعة الطلاب المعرضين للخطر مع تحليل أنماط الحضور</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- الميزات المتقدمة -->
            <div class="row mb-5">
                <div class="col-md-6 mb-4">
                    <div class="card feature-card h-100">
                        <div class="card-body">
                            <h5 class="card-title">
                                <i class="fas fa-mobile-alt text-primary me-2"></i>
                                تطبيق موبايل (قيد التطوير)
                            </h5>
                            <p class="card-text">تطبيق موبايل للطلاب وأولياء الأمور والمعلمين مع إشعارات فورية</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="card feature-card h-100">
                        <div class="card-body">
                            <h5 class="card-title">
                                <i class="fas fa-calendar-alt text-success me-2"></i>
                                جدولة ذكية
                            </h5>
                            <p class="card-text">نظام جدولة متطور يمنع التضارب ويحسن استغلال الموارد</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- بيانات تسجيل الدخول -->
            <div class="row mb-5">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0">
                                <i class="fas fa-key me-2"></i>
                                بيانات تسجيل الدخول للتجربة
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3 text-center mb-3">
                                    <h6 class="text-primary">المدير</h6>
                                    <p class="mb-1"><strong>المستخدم:</strong> admin</p>
                                    <p><strong>كلمة المرور:</strong> admin123</p>
                                </div>
                                <div class="col-md-3 text-center mb-3">
                                    <h6 class="text-success">المعلم</h6>
                                    <p class="mb-1"><strong>المستخدم:</strong> teacher1</p>
                                    <p><strong>كلمة المرور:</strong> teacher123</p>
                                </div>
                                <div class="col-md-3 text-center mb-3">
                                    <h6 class="text-info">الطالب</h6>
                                    <p class="mb-1"><strong>المستخدم:</strong> student1</p>
                                    <p><strong>كلمة المرور:</strong> student123</p>
                                </div>
                                <div class="col-md-3 text-center mb-3">
                                    <h6 class="text-warning">ولي الأمر</h6>
                                    <p class="mb-1"><strong>المستخدم:</strong> parent1</p>
                                    <p><strong>كلمة المرور:</strong> parent123</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <footer class="bg-dark text-white text-center py-4">
            <div class="container">
                <p class="mb-2">&copy; 2025 نظام إدارة الحضور والغياب - جميع الحقوق محفوظة</p>
                <p class="mb-0">
                    <small>
                        <i class="fas fa-code me-1"></i>
                        تم التطوير باستخدام Django + Bootstrap + ApexCharts
                    </small>
                </p>
            </div>
        </footer>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    ''')

@app.route('/health')
def health():
    """فحص حالة النظام"""
    return {
        "status": "healthy", 
        "message": "نظام الحضور والغياب يعمل بشكل طبيعي",
        "version": "1.0.0",
        "features": [
            "إدارة شاملة للمستخدمين",
            "نظام الإنذار المبكر",
            "تقارير تفاعلية",
            "واجهات مخصصة",
            "دعم اللغة العربية"
        ]
    }

@app.route('/login/')
def login_redirect():
    """إعادة توجيه إلى صفحة تسجيل الدخول"""
    from flask import redirect
    return redirect('https://8000-i2vn4sf7gyawg07woyh6x-cbf69d51.manusvm.computer/login/')

@app.route('/demo')
def demo_info():
    """معلومات النسخة التجريبية"""
    return {
        "demo_url": "https://8000-iyoc45vhk7hxll5jq1u1l-2e10de93.manusvm.computer/",
        "credentials": {
            "admin": {"username": "admin", "password": "admin123"},
            "teacher": {"username": "teacher1", "password": "teacher123"},
            "student": {"username": "student1", "password": "student123"},
            "parent": {"username": "parent1", "password": "parent123"}
        },
        "features": {
            "students": 259,
            "teachers": 15,
            "classrooms": 12,
            "early_warning": True,
            "interactive_reports": True,
            "arabic_support": True
        }
    }

if __name__ == '__main__':
    import os
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)

