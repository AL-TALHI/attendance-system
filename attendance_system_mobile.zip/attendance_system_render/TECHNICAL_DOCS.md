# الوثائق الفنية - نظام إدارة الحضور والغياب

## 📋 جدول المحتويات

1. [بنية المشروع](#بنية-المشروع)
2. [نماذج قاعدة البيانات](#نماذج-قاعدة-البيانات)
3. [العروض (Views)](#العروض-views)
4. [القوالب (Templates)](#القوالب-templates)
5. [الملفات الثابتة](#الملفات-الثابتة)
6. [APIs](#apis)
7. [الأمان](#الأمان)
8. [الأداء](#الأداء)
9. [النشر](#النشر)
10. [التطوير](#التطوير)

## 🏗️ بنية المشروع

```
attendance_system/
├── attendance_project/          # إعدادات المشروع الرئيسية
│   ├── __init__.py
│   ├── settings.py             # إعدادات Django
│   ├── urls.py                 # URLs الرئيسية
│   ├── wsgi.py                 # إعدادات WSGI
│   └── asgi.py                 # إعدادات ASGI
├── attendance/                  # التطبيق الرئيسي
│   ├── migrations/             # ملفات الهجرة
│   ├── static/                 # الملفات الثابتة
│   │   └── attendance/
│   │       ├── css/
│   │       ├── js/
│   │       └── images/
│   ├── templates/              # القوالب
│   │   └── attendance/
│   ├── __init__.py
│   ├── admin.py               # إعدادات لوحة الإدارة
│   ├── apps.py                # إعدادات التطبيق
│   ├── models.py              # نماذج قاعدة البيانات
│   ├── views.py               # العروض
│   ├── urls.py                # URLs التطبيق
│   ├── forms.py               # النماذج (Forms)
│   └── utils.py               # وظائف مساعدة
├── media/                      # ملفات المستخدمين
├── static/                     # الملفات الثابتة المجمعة
├── venv/                       # البيئة الافتراضية
├── manage.py                   # أداة إدارة Django
├── requirements.txt            # التبعيات
├── README.md                   # دليل المشروع
├── USER_GUIDE.md              # دليل المستخدم
└── TECHNICAL_DOCS.md          # هذا الملف
```

## 🗄️ نماذج قاعدة البيانات

### User (المستخدم المخصص)
```python
class User(AbstractUser):
    ROLE_CHOICES = [
        ('admin', 'مدير'),
        ('teacher', 'معلم'),
        ('student', 'طالب'),
        ('parent', 'ولي أمر'),
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='student')
    phone = models.CharField(max_length=15, blank=True, null=True)
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
```

### School (المدرسة)
```python
class School(models.Model):
    name = models.CharField(max_length=200)
    address = models.TextField()
    phone = models.CharField(max_length=15)
    email = models.EmailField()
    website = models.URLField(blank=True, null=True)
    logo = models.ImageField(upload_to='school_logos/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
```

### Grade (الصف الدراسي)
```python
class Grade(models.Model):
    LEVEL_CHOICES = [
        ('elementary', 'ابتدائي'),
        ('middle', 'متوسط'),
        ('high', 'ثانوي'),
    ]
    name = models.CharField(max_length=50)
    level = models.CharField(max_length=20, choices=LEVEL_CHOICES)
    school = models.ForeignKey(School, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
```

### Subject (المادة الدراسية)
```python
class Subject(models.Model):
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=10, unique=True)
    grade = models.ForeignKey(Grade, on_delete=models.CASCADE)
    weekly_hours = models.IntegerField(default=1)
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
```

### Classroom (الفصل الدراسي)
```python
class Classroom(models.Model):
    name = models.CharField(max_length=50)
    grade = models.ForeignKey(Grade, on_delete=models.CASCADE)
    capacity = models.IntegerField(default=30)
    room_number = models.CharField(max_length=20, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
```

### Teacher (المعلم)
```python
class Teacher(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    employee_id = models.CharField(max_length=20, unique=True)
    hire_date = models.DateField()
    qualification = models.CharField(max_length=200)
    subjects = models.ManyToManyField(Subject, through='TeacherSubject')
    created_at = models.DateTimeField(auto_now_add=True)
```

### Student (الطالب)
```python
class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    student_id = models.CharField(max_length=20, unique=True)
    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE)
    parent = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    enrollment_date = models.DateField()
    graduation_date = models.DateField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
```

### AttendanceSession (جلسة الحضور)
```python
class AttendanceSession(models.Model):
    SESSION_TYPES = [
        ('regular', 'حصة عادية'),
        ('exam', 'امتحان'),
        ('activity', 'نشاط'),
        ('makeup', 'حصة تعويضية'),
    ]
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE)
    classroom = models.ForeignKey(Classroom, on_delete=models.CASCADE)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    date = models.DateField()
    start_time = models.TimeField()
    end_time = models.TimeField()
    session_type = models.CharField(max_length=20, choices=SESSION_TYPES)
    notes = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
```

### AttendanceRecord (سجل الحضور)
```python
class AttendanceRecord(models.Model):
    STATUS_CHOICES = [
        ('present', 'حاضر'),
        ('absent', 'غائب'),
        ('late', 'متأخر'),
        ('excused', 'بعذر'),
    ]
    session = models.ForeignKey(AttendanceSession, on_delete=models.CASCADE)
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES)
    arrival_time = models.TimeField(blank=True, null=True)
    notes = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
```

## 🎯 العروض (Views)

### العروض الأساسية

#### LoginView
```python
class LoginView(View):
    def get(self, request):
        if request.user.is_authenticated:
            return redirect('dashboard')
        return render(request, 'attendance/login.html')
    
    def post(self, request):
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('dashboard')
        return render(request, 'attendance/login.html', {'error': 'بيانات غير صحيحة'})
```

#### DashboardView
```python
@method_decorator(login_required, name='dispatch')
class DashboardView(View):
    def get(self, request):
        context = self.get_context_data(request.user)
        return render(request, 'attendance/dashboard.html', context)
    
    def get_context_data(self, user):
        if user.role == 'admin':
            return self.get_admin_context()
        elif user.role == 'teacher':
            return self.get_teacher_context(user)
        elif user.role == 'student':
            return self.get_student_context(user)
        elif user.role == 'parent':
            return self.get_parent_context(user)
```

### عروض إدارة البيانات

#### StudentListView
```python
@method_decorator(login_required, name='dispatch')
class StudentListView(View):
    def get(self, request):
        students = Student.objects.select_related('user', 'classroom__grade').all()
        classrooms = Classroom.objects.all()
        
        # تطبيق الفلاتر
        classroom_filter = request.GET.get('classroom')
        search_query = request.GET.get('search')
        
        if classroom_filter:
            students = students.filter(classroom_id=classroom_filter)
        
        if search_query:
            students = students.filter(
                Q(user__first_name__icontains=search_query) |
                Q(user__last_name__icontains=search_query) |
                Q(student_id__icontains=search_query)
            )
        
        context = {
            'students': students,
            'classrooms': classrooms,
            'current_classroom': classroom_filter,
            'search_query': search_query,
        }
        return render(request, 'attendance/student_list.html', context)
```

#### AttendanceSessionCreateView
```python
@method_decorator(login_required, name='dispatch')
class AttendanceSessionCreateView(View):
    def post(self, request):
        try:
            teacher = request.user.teacher_profile
            classroom_id = request.POST.get('classroom')
            subject_id = request.POST.get('subject')
            date = request.POST.get('date')
            start_time = request.POST.get('start_time')
            end_time = request.POST.get('end_time')
            session_type = request.POST.get('session_type', 'regular')
            notes = request.POST.get('notes', '')
            
            # التحقق من صحة البيانات
            if not all([classroom_id, subject_id, date, start_time, end_time]):
                return JsonResponse({'success': False, 'error': 'جميع الحقول مطلوبة'})
            
            # إنشاء الجلسة
            session = AttendanceSession.objects.create(
                teacher=teacher,
                classroom_id=classroom_id,
                subject_id=subject_id,
                date=date,
                start_time=start_time,
                end_time=end_time,
                session_type=session_type,
                notes=notes
            )
            
            return JsonResponse({'success': True, 'session_id': session.id})
            
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
```

## 🎨 القوالب (Templates)

### القالب الأساسي (base.html)
```html
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}نظام إدارة الحضور والغياب{% endblock %}</title>
    
    <!-- Bootstrap RTL CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="{% static 'attendance/css/custom.css' %}">
    
    {% block extra_css %}{% endblock %}
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="{% url 'dashboard' %}">
                <i class="fas fa-graduation-cap me-2"></i>
                نظام الحضور والغياب
            </a>
            
            <!-- User Info -->
            <div class="navbar-nav ms-auto">
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle me-1"></i>
                        {{ user.get_full_name|default:user.username }}
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="{% url 'profile' %}">الملف الشخصي</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="{% url 'logout' %}">تسجيل الخروج</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                {% include 'attendance/partials/sidebar.html' %}
            </nav>
            
            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                {% if messages %}
                    {% for message in messages %}
                        <div class="alert alert-{{ message.tags }} alert-dismissible fade show mt-3" role="alert">
                            {{ message }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    {% endfor %}
                {% endif %}
                
                {% block content %}{% endblock %}
            </main>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    
    {% block extra_js %}{% endblock %}
</body>
</html>
```

### قالب لوحة التحكم
```html
{% extends 'attendance/base.html' %}
{% load static %}

{% block title %}لوحة التحكم - {{ block.super }}{% endblock %}

{% block content %}
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">لوحة التحكم</h1>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    {% if user.role == 'admin' %}
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-right-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">الطلاب</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ stats.students_count }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-users fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-right-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">المعلمين</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">{{ stats.teachers_count }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-chalkboard-teacher fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    {% endif %}
</div>

<!-- Recent Activities -->
<div class="row">
    <div class="col-lg-8">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">النشاطات الأخيرة</h6>
            </div>
            <div class="card-body">
                {% for activity in recent_activities %}
                    <div class="d-flex align-items-center mb-3">
                        <div class="me-3">
                            <i class="fas fa-{{ activity.icon }} text-{{ activity.color }}"></i>
                        </div>
                        <div>
                            <div class="small text-gray-500">{{ activity.timestamp|date:"Y/m/d H:i" }}</div>
                            <div>{{ activity.description }}</div>
                        </div>
                    </div>
                {% empty %}
                    <p class="text-muted">لا توجد نشاطات حديثة</p>
                {% endfor %}
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">الإجراءات السريعة</h6>
            </div>
            <div class="card-body">
                {% if user.role == 'admin' %}
                    <a href="{% url 'student_list' %}" class="btn btn-primary btn-sm mb-2 w-100">
                        <i class="fas fa-plus me-1"></i> إضافة طالب
                    </a>
                    <a href="{% url 'session_list' %}" class="btn btn-success btn-sm mb-2 w-100">
                        <i class="fas fa-calendar-plus me-1"></i> جلسة جديدة
                    </a>
                {% elif user.role == 'teacher' %}
                    <a href="{% url 'session_list' %}" class="btn btn-primary btn-sm mb-2 w-100">
                        <i class="fas fa-calendar-plus me-1"></i> جلسة جديدة
                    </a>
                    <a href="{% url 'student_list' %}" class="btn btn-info btn-sm mb-2 w-100">
                        <i class="fas fa-list me-1"></i> قائمة الطلاب
                    </a>
                {% endif %}
                
                <a href="{% url 'reports' %}" class="btn btn-warning btn-sm mb-2 w-100">
                    <i class="fas fa-chart-bar me-1"></i> التقارير
                </a>
            </div>
        </div>
    </div>
</div>
{% endblock %}
```

## 💾 الملفات الثابتة

### CSS المخصص (custom.css)
```css
:root {
    --primary-color: #4e73df;
    --secondary-color: #858796;
    --success-color: #1cc88a;
    --info-color: #36b9cc;
    --warning-color: #f6c23e;
    --danger-color: #e74a3b;
    --light-color: #f8f9fc;
    --dark-color: #5a5c69;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: var(--light-color);
}

.sidebar {
    position: fixed;
    top: 56px;
    bottom: 0;
    right: 0;
    z-index: 100;
    padding: 48px 0 0;
    box-shadow: inset 1px 0 0 rgba(0, 0, 0, .1);
}

.sidebar-sticky {
    position: relative;
    top: 0;
    height: calc(100vh - 48px);
    padding-top: .5rem;
    overflow-x: hidden;
    overflow-y: auto;
}

.card {
    border: none;
    border-radius: 10px;
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
    transition: all 0.3s;
}

.card:hover {
    transform: translateY(-2px);
    box-shadow: 0 0.25rem 2rem 0 rgba(58, 59, 69, 0.2);
}

.btn {
    border-radius: 8px;
    font-weight: 600;
    transition: all 0.3s;
}

.btn:hover {
    transform: translateY(-1px);
}

.table {
    border-radius: 10px;
    overflow: hidden;
}

.table th {
    background-color: var(--primary-color);
    color: white;
    font-weight: 600;
    border: none;
}

.badge {
    font-size: 0.8em;
    padding: 0.5em 0.8em;
    border-radius: 20px;
}

.attendance-status-present {
    background-color: var(--success-color);
    color: white;
}

.attendance-status-absent {
    background-color: var(--danger-color);
    color: white;
}

.attendance-status-late {
    background-color: var(--warning-color);
    color: white;
}

.attendance-status-excused {
    background-color: var(--info-color);
    color: white;
}

/* Responsive Design */
@media (max-width: 768px) {
    .sidebar {
        position: static;
        height: auto;
    }
    
    .card {
        margin-bottom: 1rem;
    }
    
    .table-responsive {
        font-size: 0.9em;
    }
}

/* Print Styles */
@media print {
    .sidebar,
    .navbar,
    .btn,
    .no-print {
        display: none !important;
    }
    
    .main-content {
        margin: 0 !important;
        padding: 0 !important;
    }
}

/* Animation Classes */
.fade-in {
    animation: fadeIn 0.5s ease-in;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

.slide-in {
    animation: slideIn 0.3s ease-out;
}

@keyframes slideIn {
    from { transform: translateX(-100%); }
    to { transform: translateX(0); }
}
```

### JavaScript المخصص
```javascript
// Global JavaScript functions
$(document).ready(function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Auto-hide alerts
    $('.alert').delay(5000).slideUp(300);
    
    // Confirm delete actions
    $('.delete-btn').click(function(e) {
        if (!confirm('هل أنت متأكد من الحذف؟')) {
            e.preventDefault();
        }
    });
    
    // AJAX form submissions
    $('.ajax-form').submit(function(e) {
        e.preventDefault();
        var form = $(this);
        var url = form.attr('action');
        var data = form.serialize();
        
        $.post(url, data)
            .done(function(response) {
                if (response.success) {
                    showAlert('success', response.message || 'تم الحفظ بنجاح');
                    if (response.redirect) {
                        window.location.href = response.redirect;
                    }
                } else {
                    showAlert('danger', response.error || 'حدث خطأ');
                }
            })
            .fail(function() {
                showAlert('danger', 'حدث خطأ في الاتصال');
            });
    });
});

// Utility functions
function showAlert(type, message) {
    var alert = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    $('#alerts-container').append(alert);
    
    // Auto-hide after 5 seconds
    setTimeout(function() {
        $('.alert').last().fadeOut();
    }, 5000);
}

function formatDate(date) {
    return new Date(date).toLocaleDateString('ar-SA');
}

function formatTime(time) {
    return new Date('2000-01-01 ' + time).toLocaleTimeString('ar-SA', {
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Attendance specific functions
function markAllPresent() {
    $('.attendance-status').val('present');
    updateAttendanceCount();
}

function markAllAbsent() {
    $('.attendance-status').val('absent');
    updateAttendanceCount();
}

function markAllLate() {
    $('.attendance-status').val('late');
    updateAttendanceCount();
}

function resetAttendance() {
    $('.attendance-status').val('');
    updateAttendanceCount();
}

function updateAttendanceCount() {
    var present = $('.attendance-status[value="present"]').length;
    var absent = $('.attendance-status[value="absent"]').length;
    var late = $('.attendance-status[value="late"]').length;
    var excused = $('.attendance-status[value="excused"]').length;
    
    $('#present-count').text(present);
    $('#absent-count').text(absent);
    $('#late-count').text(late);
    $('#excused-count').text(excused);
}

// Export functions
function exportToExcel() {
    window.location.href = window.location.href + '?export=excel';
}

function exportToPDF() {
    window.location.href = window.location.href + '?export=pdf';
}

function printPage() {
    window.print();
}
```

## 🔒 الأمان

### المصادقة والترخيص
```python
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin

def admin_required(user):
    return user.is_authenticated and user.role == 'admin'

def teacher_required(user):
    return user.is_authenticated and user.role in ['admin', 'teacher']

class AdminRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        return self.request.user.is_authenticated and self.request.user.role == 'admin'

class TeacherRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        return self.request.user.is_authenticated and self.request.user.role in ['admin', 'teacher']
```

### حماية CSRF
```python
# في settings.py
CSRF_COOKIE_SECURE = True  # في الإنتاج
CSRF_COOKIE_HTTPONLY = True
CSRF_COOKIE_SAMESITE = 'Strict'

# في القوالب
{% csrf_token %}
```

### تشفير كلمات المرور
```python
from django.contrib.auth.hashers import make_password, check_password

# تشفير كلمة المرور
password = make_password('user_password')

# التحقق من كلمة المرور
is_valid = check_password('user_password', hashed_password)
```

## ⚡ الأداء

### تحسين استعلامات قاعدة البيانات
```python
# استخدام select_related للعلاقات الفردية
students = Student.objects.select_related('user', 'classroom__grade').all()

# استخدام prefetch_related للعلاقات المتعددة
teachers = Teacher.objects.prefetch_related('subjects').all()

# تحديد الحقول المطلوبة فقط
students = Student.objects.values('id', 'student_id', 'user__first_name', 'user__last_name')

# استخدام التجميع
from django.db.models import Count, Avg
stats = AttendanceRecord.objects.aggregate(
    total_present=Count('id', filter=Q(status='present')),
    total_absent=Count('id', filter=Q(status='absent')),
    attendance_rate=Avg('status')
)
```

### التخزين المؤقت
```python
# في settings.py
CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.redis.RedisCache',
        'LOCATION': 'redis://127.0.0.1:6379/1',
    }
}

# في العروض
from django.core.cache import cache
from django.views.decorators.cache import cache_page

@cache_page(60 * 15)  # 15 دقيقة
def dashboard_view(request):
    # ...
    pass

# تخزين مؤقت يدوي
def get_student_stats(student_id):
    cache_key = f'student_stats_{student_id}'
    stats = cache.get(cache_key)
    
    if stats is None:
        stats = calculate_student_stats(student_id)
        cache.set(cache_key, stats, 60 * 30)  # 30 دقيقة
    
    return stats
```

## 🚀 النشر

### إعدادات الإنتاج
```python
# settings/production.py
import os
from .base import *

DEBUG = False
ALLOWED_HOSTS = ['yourdomain.com', 'www.yourdomain.com']

# قاعدة البيانات
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': os.environ.get('DB_NAME'),
        'USER': os.environ.get('DB_USER'),
        'PASSWORD': os.environ.get('DB_PASSWORD'),
        'HOST': os.environ.get('DB_HOST', 'localhost'),
        'PORT': os.environ.get('DB_PORT', '5432'),
    }
}

# الأمان
SECURE_BROWSER_XSS_FILTER = True
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_HSTS_SECONDS = 31536000
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True
SECURE_SSL_REDIRECT = True
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True

# الملفات الثابتة
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')
STATICFILES_STORAGE = 'django.contrib.staticfiles.storage.StaticFilesStorage'

# البريد الإلكتروني
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = os.environ.get('EMAIL_HOST')
EMAIL_PORT = int(os.environ.get('EMAIL_PORT', 587))
EMAIL_USE_TLS = True
EMAIL_HOST_USER = os.environ.get('EMAIL_HOST_USER')
EMAIL_HOST_PASSWORD = os.environ.get('EMAIL_HOST_PASSWORD')
```

### Docker
```dockerfile
# Dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

RUN python manage.py collectstatic --noinput

EXPOSE 8000

CMD ["gunicorn", "--bind", "0.0.0.0:8000", "attendance_project.wsgi:application"]
```

```yaml
# docker-compose.yml
version: '3.8'

services:
  web:
    build: .
    ports:
      - "8000:8000"
    environment:
      - DEBUG=False
      - DB_NAME=attendance_db
      - DB_USER=attendance_user
      - DB_PASSWORD=your_password
      - DB_HOST=db
    depends_on:
      - db
    volumes:
      - ./media:/app/media

  db:
    image: postgres:13
    environment:
      - POSTGRES_DB=attendance_db
      - POSTGRES_USER=attendance_user
      - POSTGRES_PASSWORD=your_password
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
```

## 🛠️ التطوير

### إعداد بيئة التطوير
```bash
# إنشاء البيئة الافتراضية
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows

# تثبيت التبعيات
pip install -r requirements.txt

# إعداد قاعدة البيانات
python manage.py makemigrations
python manage.py migrate

# إنشاء مستخدم مدير
python manage.py createsuperuser

# تشغيل الخادم
python manage.py runserver
```

### أدوات التطوير
```python
# settings/development.py
from .base import *

DEBUG = True
ALLOWED_HOSTS = ['localhost', '127.0.0.1']

# Django Debug Toolbar
if DEBUG:
    INSTALLED_APPS += ['debug_toolbar']
    MIDDLEWARE += ['debug_toolbar.middleware.DebugToolbarMiddleware']
    INTERNAL_IPS = ['127.0.0.1']

# تسجيل مفصل
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
        },
    },
    'loggers': {
        'django': {
            'handlers': ['console'],
            'level': 'INFO',
        },
        'attendance': {
            'handlers': ['console'],
            'level': 'DEBUG',
        },
    },
}
```

### الاختبارات
```python
# tests.py
from django.test import TestCase, Client
from django.contrib.auth import get_user_model
from .models import Student, Teacher, AttendanceSession

User = get_user_model()

class AttendanceSystemTestCase(TestCase):
    def setUp(self):
        self.client = Client()
        self.admin_user = User.objects.create_user(
            username='admin',
            password='testpass',
            role='admin'
        )
        self.teacher_user = User.objects.create_user(
            username='teacher',
            password='testpass',
            role='teacher'
        )
    
    def test_admin_dashboard_access(self):
        self.client.login(username='admin', password='testpass')
        response = self.client.get('/dashboard/')
        self.assertEqual(response.status_code, 200)
    
    def test_teacher_can_create_session(self):
        self.client.login(username='teacher', password='testpass')
        # إنشاء البيانات المطلوبة
        # اختبار إنشاء الجلسة
        pass
    
    def test_student_attendance_recording(self):
        # اختبار تسجيل الحضور
        pass

# تشغيل الاختبارات
# python manage.py test
```

### أوامر إدارية مخصصة
```python
# management/commands/import_students.py
from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from attendance.models import Student, Classroom
import csv

User = get_user_model()

class Command(BaseCommand):
    help = 'Import students from CSV file'
    
    def add_arguments(self, parser):
        parser.add_argument('csv_file', type=str, help='Path to CSV file')
    
    def handle(self, *args, **options):
        csv_file = options['csv_file']
        
        with open(csv_file, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            
            for row in reader:
                user = User.objects.create_user(
                    username=row['student_id'],
                    first_name=row['first_name'],
                    last_name=row['last_name'],
                    email=row['email'],
                    role='student'
                )
                
                Student.objects.create(
                    user=user,
                    student_id=row['student_id'],
                    classroom_id=row['classroom_id'],
                    enrollment_date=row['enrollment_date']
                )
                
                self.stdout.write(
                    self.style.SUCCESS(f'Successfully imported {user.get_full_name()}')
                )

# الاستخدام: python manage.py import_students students.csv
```

---

**هذه الوثائق الفنية توفر دليلاً شاملاً للمطورين للعمل مع نظام إدارة الحضور والغياب وتطويره وصيانته.** 🔧💻

