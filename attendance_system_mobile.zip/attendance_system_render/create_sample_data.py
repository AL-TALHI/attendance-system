#!/usr/bin/env python
"""
ملف لإنشاء بيانات تجريبية شاملة لنظام الحضور والغياب
"""

import os
import sys
import django
import random
from datetime import date, datetime, time, timedelta
from django.contrib.auth.hashers import make_password

# إعداد Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'attendance_project.settings')
django.setup()

from attendance.models import (
    User, School, Grade, Subject, Classroom, Teacher, Student, Parent,
    AttendanceSession, AttendanceRecord, Notification,
    TimeSlot, Schedule, ScheduleSlot
)

# --- إعدادات البيانات التجريبية ---
NUM_TEACHERS = 15
NUM_STUDENTS_PER_CLASS = 20
NUM_PARENTS = 30
START_DATE = date.today() - timedelta(days=90)
END_DATE = date.today()

# --- دوال مساعدة ---

def random_date(start, end):
    return start + timedelta(days=random.randint(0, (end - start).days))

def get_or_create_user(username, first_name, last_name, email, role, password='password123'):
    user, created = User.objects.get_or_create(
        username=username,
        defaults={
            'first_name': first_name,
            'last_name': last_name,
            'email': email,
            'role': role,
            'password': make_password(password)
        }
    )
    return user, created

# --- إنشاء البيانات ---

def create_base_data():
    """إنشاء البيانات الأساسية (مدرسة، صفوف، مواد)"""
    print("--- 1. إنشاء البيانات الأساسية ---")
    school, _ = School.objects.get_or_create(
        name="مدرسة المستقبل النموذجية",
        defaults={'address': 'الرياض، حي الملز', 'phone': '011-2233445', 'email': 'contact@future-school.edu.sa'}
    )
    
    grades_data = [f"الصف {i} الابتدائي" for i in range(1, 7)]
    grades = [Grade.objects.get_or_create(name=name, defaults={'level': i+1, 'school': school})[0] for i, name in enumerate(grades_data)]
    
    print(f"✓ تم إنشاء {len(grades)} صف دراسي.")
    
    subjects_data = ['اللغة العربية', 'الرياضيات', 'العلوم', 'التربية الإسلامية', 'اللغة الإنجليزية', 'التربية البدنية', 'التربية الفنية', 'المهارات الرقمية']
    subjects = [Subject.objects.get_or_create(name=name, defaults={'code': f'SUB{i+1:03}', 'school': school})[0] for i, name in enumerate(subjects_data)]
    print(f"✓ تم إنشاء {len(subjects)} مادة دراسية.")
    
    print("✓ البيانات الأساسية جاهزة.")
    return school, grades, subjects

def create_users_and_profiles(school, grades, subjects):
    """إنشاء المستخدمين (معلمين، طلاب، أولياء أمور)"""
    print("--- 2. إنشاء المستخدمين والملفات الشخصية ---")
    
    # المعلمون
    teachers = []
    teacher_first_names = ['أحمد', 'محمد', 'علي', 'خالد', 'عبدالله', 'سلطان', 'فهد', 'سارة', 'فاطمة', 'نورة', 'مريم', 'عائشة', 'هند', 'جمانة', 'ليلى']
    teacher_last_names = ['الغامدي', 'الشهري', 'القحطاني', 'العتيبي', 'المطيري', 'الشمري', 'العنزي']
    for i in range(NUM_TEACHERS):
        print(f"--- Creating teacher {i+1}/{NUM_TEACHERS} ---")
        first_name = random.choice(teacher_first_names)
        last_name = random.choice(teacher_last_names)
        username = f"t{i+1:03}"
        user, created = get_or_create_user(username, first_name, last_name, f"{username}@future-school.edu.sa", 'teacher')
        print(f"--- User {username} created: {created} ---")
        
        # التحقق من وجود ملف المعلم
        teacher, teacher_created = Teacher.objects.get_or_create(
            user=user,
            defaults={
                'employee_id': f"T{1001+i}",
                'hire_date': random_date(date(2018,1,1), date(2022,1,1)),
                'qualification': 'بكالوريوس'
            }
        )
        if teacher_created:
            teacher.subjects.set(random.sample(subjects, k=random.randint(1, 3)))
        teachers.append(teacher)
    print(f"✓ تم إنشاء {len(teachers)} معلم.")

    # الفصول والطلاب
    classrooms = []
    students = []
    student_first_names = ['سالم', 'غانم', 'راشد', 'ماجد', 'يوسف', 'حسن', 'حسين', 'جواهر', 'لطيفة', 'شيخة', 'حصة', 'دانة', 'ريم', 'شهد', 'أمل']
    student_last_names = ['المالكي', 'الجهني', 'الحربي', 'الزهراني', 'الدوسري']
    student_id_counter = 1
    for grade in grades:
        for section in ['أ', 'ب']:
            classroom_name = f"{grade.name.split(' ')[1]} {section}"
            classroom, created = Classroom.objects.get_or_create(name=classroom_name, grade=grade, defaults={'capacity': 25, 'room_number': f"{grade.level}{1 if section=='أ' else 2}"})
            classrooms.append(classroom)
            for _ in range(NUM_STUDENTS_PER_CLASS):
                first_name = random.choice(student_first_names)
                last_name = random.choice(student_last_names)
                username = f"s{student_id_counter:04}"
                user, created = get_or_create_user(username, first_name, last_name, f"{username}@student.future-school.edu.sa", 'student')
                
                # التحقق من وجود ملف الطالب
                student, student_created = Student.objects.get_or_create(
                    user=user,
                    defaults={
                        'student_id': f"S{2000+student_id_counter}",
                        'classroom': classroom,
                        'enrollment_date': random_date(date(2022,9,1), date(2023,9,1))
                    }
                )
                students.append(student)
                student_id_counter += 1
    print(f"✓ تم إنشاء {len(classrooms)} فصل و {len(students)} طالب.")

    # أولياء الأمور
    parents = []
    for i in range(NUM_PARENTS):
        first_name = random.choice(student_first_names)
        last_name = random.choice(student_last_names)
        username = f"p{i+1:03}"
        user, created = get_or_create_user(username, first_name, last_name, f"{username}@parent.future-school.edu.sa", 'parent')
        
        # التحقق من وجود ملف ولي الأمر
        parent, parent_created = Parent.objects.get_or_create(
            user=user,
            defaults={
                'phone_number': f"05{random.randint(10000000, 99999999)}"
            }
        )
        if parent_created and students:  # التأكد من وجود طلاب
            parent.children.set(random.sample(students, k=min(random.randint(1, 3), len(students))))
        parents.append(parent)
    print(f"✓ تم إنشاء {len(parents)} ولي أمر.")
    
    return teachers, students, classrooms, parents

def create_schedules(teachers, classrooms, subjects):
    """إنشاء الجداول الدراسية"""
    print("--- 3. إنشاء الجداول الدراسية ---")
    
    # الفترات الزمنية
    time_slots_data = [
        (time(8, 0), time(8, 45)), (time(8, 45), time(9, 30)), (time(9, 30), time(10, 15)),
        (time(10, 30), time(11, 15)), (time(11, 15), time(12, 0)),
        (time(12, 45), time(13, 30)), (time(13, 30), time(14, 15))
    ]
    time_slots = [TimeSlot.objects.get_or_create(start_time=s, end_time=e, defaults={'name': f"الحصة {i+1}", 'duration_minutes': 45})[0] for i, (s, e) in enumerate(time_slots_data)]
    TimeSlot.objects.get_or_create(name='استراحة', start_time=time(10,15), end_time=time(10,30), defaults={'is_break':True, 'duration_minutes': 15})
    TimeSlot.objects.get_or_create(name='صلاة و غداء', start_time=time(12,0), end_time=time(12,45), defaults={'is_break':True, 'duration_minutes': 45})
    print(f"✓ تم إنشاء {len(time_slots)} فترة زمنية.")

    # إنشاء الجداول والحصص
    for classroom in classrooms:
        admin_user = User.objects.get(username='admin')
        schedule, created = Schedule.objects.get_or_create(name=f"جدول {classroom.name}", defaults={'schedule_type':'weekly', 'academic_year': '2024-2025', 'start_date': date(2024, 9, 1), 'end_date': date(2025, 6, 30), 'created_by': admin_user})
        if created:
            for day in range(5): # 5 أيام في الأسبوع
                available_teachers = teachers[:]
                for time_slot in time_slots:
                    if not available_teachers:
                        break
                    teacher = random.choice(available_teachers)
                    subject = random.choice(list(teacher.subjects.all()))
                    
                    # تحقق من عدم وجود تضارب للمعلم في نفس الوقت
                    is_busy = ScheduleSlot.objects.filter(teacher=teacher, day_of_week=day, time_slot=time_slot).exists()
                    if not is_busy:
                        ScheduleSlot.objects.create(schedule=schedule, day_of_week=day, time_slot=time_slot, subject=subject, teacher=teacher, classroom=classroom)
                        available_teachers.remove(teacher)
    print(f"✓ تم إنشاء الجداول الدراسية للفصول.")

def create_attendance_records(students, classrooms, subjects, teachers):
    """إنشاء سجلات الحضور والغياب"""
    print("--- 4. إنشاء سجلات الحضور والغياب ---")
    total_records = 0
    for day in range((END_DATE - START_DATE).days + 1):
        current_date = START_DATE + timedelta(days=day)
        if current_date.weekday() >= 5: # تخطي الجمعة والسبت
            continue
        
        day_slots = ScheduleSlot.objects.filter(day_of_week=current_date.weekday())
        for slot in day_slots:
            session, created = AttendanceSession.objects.get_or_create(
                classroom=slot.classroom,
                subject=slot.subject,
                teacher=slot.teacher,
                date=current_date,
                defaults={
                    'start_time': slot.time_slot.start_time,
                    'end_time': slot.time_slot.end_time,
                    'session_type': 'regular',
                    'is_completed': True,
                    'created_by': slot.teacher.user
                }
            )
            if created:
                session_students = Student.objects.filter(classroom=slot.classroom)
                for student in session_students:
                    rand = random.random()
                    if rand < 0.85: status = 'present'
                    elif rand < 0.95: status = 'late'
                    else: status = 'absent'
                    
                    arrival = None
                    if status == 'present': arrival = slot.time_slot.start_time
                    if status == 'late': arrival = (datetime.combine(date.today(), slot.time_slot.start_time) + timedelta(minutes=random.randint(5,15))).time()
                    
                    AttendanceRecord.objects.create(session=session, student=student, status=status, arrival_time=arrival, recorded_by=slot.teacher.user)
                    total_records += 1
    print(f"✓ تم إنشاء {total_records} سجل حضور.")

# --- الدالة الرئيسية ---

def main():
    """الدالة الرئيسية لتشغيل كل شيء"""
    print("="*50)
    print("بدء إنشاء البيانات التجريبية الشاملة...")
    print("="*50)
    
    school, grades, subjects = create_base_data()
    teachers, students, classrooms, parents = create_users_and_profiles(school, grades, subjects)
    create_schedules(teachers, classrooms, subjects)
    create_attendance_records(students, classrooms, subjects, teachers)
    
    print("\n" + "="*50)
    print("🎉 تم إنشاء جميع البيانات التجريبية بنجاح! 🎉")
    print("="*50)
    print("معلومات تسجيل الدخول:")
    print("المدير: admin / admin123")
    print("المعلمين والطلاب وأولياء الأمور: كلمة المرور الافتراضية هي 'password123'")
    print("مثال معلم: t001, مثال طالب: s0001, مثال ولي أمر: p001")
    print("="*50)

if __name__ == '__main__':
    main()



